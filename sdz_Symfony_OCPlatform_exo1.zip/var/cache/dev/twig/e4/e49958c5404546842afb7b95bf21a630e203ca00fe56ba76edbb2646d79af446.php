<?php

/* @OCPlatform/Advert/oldindex.html.twig */
class __TwigTemplate_2467ab27322237ab64f6b41c3008a619932ba2e675a40646935265cecabc536c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("OCPlatformBundle::layout.html.twig", "@OCPlatform/Advert/oldindex.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "OCPlatformBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bd3a67fd6dee55dab1fcbb9ba847702b3a18f069b83525682d97fa2fd928e010 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bd3a67fd6dee55dab1fcbb9ba847702b3a18f069b83525682d97fa2fd928e010->enter($__internal_bd3a67fd6dee55dab1fcbb9ba847702b3a18f069b83525682d97fa2fd928e010_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@OCPlatform/Advert/oldindex.html.twig"));

        $__internal_3131e2aaac4a1a9b0cc4fa8462abb40178fea72eebe12c9be1873542c81c3eea = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3131e2aaac4a1a9b0cc4fa8462abb40178fea72eebe12c9be1873542c81c3eea->enter($__internal_3131e2aaac4a1a9b0cc4fa8462abb40178fea72eebe12c9be1873542c81c3eea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@OCPlatform/Advert/oldindex.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_bd3a67fd6dee55dab1fcbb9ba847702b3a18f069b83525682d97fa2fd928e010->leave($__internal_bd3a67fd6dee55dab1fcbb9ba847702b3a18f069b83525682d97fa2fd928e010_prof);

        
        $__internal_3131e2aaac4a1a9b0cc4fa8462abb40178fea72eebe12c9be1873542c81c3eea->leave($__internal_3131e2aaac4a1a9b0cc4fa8462abb40178fea72eebe12c9be1873542c81c3eea_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_a2ba372a00a85a40eb9ae55e2ab4be038b7932f441b690b7685482eb7ec23d15 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a2ba372a00a85a40eb9ae55e2ab4be038b7932f441b690b7685482eb7ec23d15->enter($__internal_a2ba372a00a85a40eb9ae55e2ab4be038b7932f441b690b7685482eb7ec23d15_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_764518cfee39a68e6c69c1e8a0f34aefc78a39dbad758bee3aa50e08028f0f24 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_764518cfee39a68e6c69c1e8a0f34aefc78a39dbad758bee3aa50e08028f0f24->enter($__internal_764518cfee39a68e6c69c1e8a0f34aefc78a39dbad758bee3aa50e08028f0f24_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $this->displayParentBlock("title", $context, $blocks);
        echo " - OldIndex";
        
        $__internal_764518cfee39a68e6c69c1e8a0f34aefc78a39dbad758bee3aa50e08028f0f24->leave($__internal_764518cfee39a68e6c69c1e8a0f34aefc78a39dbad758bee3aa50e08028f0f24_prof);

        
        $__internal_a2ba372a00a85a40eb9ae55e2ab4be038b7932f441b690b7685482eb7ec23d15->leave($__internal_a2ba372a00a85a40eb9ae55e2ab4be038b7932f441b690b7685482eb7ec23d15_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_b129b1d0a0a0962000a64c5cc04d859681d25947a589fb1908a2666927730b8e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b129b1d0a0a0962000a64c5cc04d859681d25947a589fb1908a2666927730b8e->enter($__internal_b129b1d0a0a0962000a64c5cc04d859681d25947a589fb1908a2666927730b8e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_14a02bb32ef7788e1b7bcd1e1f496a707830e5736a36677f0f365f546936a4cc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_14a02bb32ef7788e1b7bcd1e1f496a707830e5736a36677f0f365f546936a4cc->enter($__internal_14a02bb32ef7788e1b7bcd1e1f496a707830e5736a36677f0f365f546936a4cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <h1>Hello ";
        echo twig_escape_filter($this->env, (isset($context["nom"]) || array_key_exists("nom", $context) ? $context["nom"] : (function () { throw new Twig_Error_Runtime('Variable "nom" does not exist.', 6, $this->getSourceContext()); })()), "html", null, true);
        echo " !</h1>

    <p>
        Le Hello World est un grand classique en programmation.
        Il signifie énormément, car cela veut dire que vous avez
        réussi à exécuter le programme pour accomplir une tâche simple :
        afficher ce hello world !
    </p>
    <br />
    ";
        // line 15
        if (array_key_exists("advert_id", $context)) {
            // line 16
            echo "        <a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("oc_platform_view", array("id" => (isset($context["advert_id"]) || array_key_exists("advert_id", $context) ? $context["advert_id"] : (function () { throw new Twig_Error_Runtime('Variable "advert_id" does not exist.', 16, $this->getSourceContext()); })()))), "html", null, true);
            echo "\">
            Lien vers l'annonce d'id ";
            // line 17
            echo twig_escape_filter($this->env, (isset($context["advert_id"]) || array_key_exists("advert_id", $context) ? $context["advert_id"] : (function () { throw new Twig_Error_Runtime('Variable "advert_id" does not exist.', 17, $this->getSourceContext()); })()), "html", null, true);
            echo "
        </a>
    ";
        }
        
        $__internal_14a02bb32ef7788e1b7bcd1e1f496a707830e5736a36677f0f365f546936a4cc->leave($__internal_14a02bb32ef7788e1b7bcd1e1f496a707830e5736a36677f0f365f546936a4cc_prof);

        
        $__internal_b129b1d0a0a0962000a64c5cc04d859681d25947a589fb1908a2666927730b8e->leave($__internal_b129b1d0a0a0962000a64c5cc04d859681d25947a589fb1908a2666927730b8e_prof);

    }

    public function getTemplateName()
    {
        return "@OCPlatform/Advert/oldindex.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  89 => 17,  84 => 16,  82 => 15,  69 => 6,  60 => 5,  41 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"OCPlatformBundle::layout.html.twig\" %}

{% block title %}{{ parent() }} - OldIndex{% endblock %}

{% block body %}
    <h1>Hello {{ nom }} !</h1>

    <p>
        Le Hello World est un grand classique en programmation.
        Il signifie énormément, car cela veut dire que vous avez
        réussi à exécuter le programme pour accomplir une tâche simple :
        afficher ce hello world !
    </p>
    <br />
    {% if advert_id is defined %}
        <a href=\"{{ path('oc_platform_view', { 'id': advert_id }) }}\">
            Lien vers l'annonce d'id {{ advert_id }}
        </a>
    {% endif %}
{% endblock %}", "@OCPlatform/Advert/oldindex.html.twig", "C:\\wamp64\\www\\Symfony\\src\\OC\\PlatformBundle\\Resources\\views\\Advert\\oldindex.html.twig");
    }
}
