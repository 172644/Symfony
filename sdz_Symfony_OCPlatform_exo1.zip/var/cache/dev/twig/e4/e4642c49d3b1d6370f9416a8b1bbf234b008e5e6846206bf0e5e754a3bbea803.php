<?php

/* @Framework/Form/number_widget.html.php */
class __TwigTemplate_ef994476515f73c4994f1b80467c30e0196ab9594785b76e74a74e7057769d58 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1698c42346cf2b5d84487be623e87e64377b0e850fcf556f58fe883f4729daff = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1698c42346cf2b5d84487be623e87e64377b0e850fcf556f58fe883f4729daff->enter($__internal_1698c42346cf2b5d84487be623e87e64377b0e850fcf556f58fe883f4729daff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        $__internal_aed5029af1a16338bc3f032d1043b8441267cd6e85d826be70abfd8787de0636 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aed5029af1a16338bc3f032d1043b8441267cd6e85d826be70abfd8787de0636->enter($__internal_aed5029af1a16338bc3f032d1043b8441267cd6e85d826be70abfd8787de0636_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?>
";
        
        $__internal_1698c42346cf2b5d84487be623e87e64377b0e850fcf556f58fe883f4729daff->leave($__internal_1698c42346cf2b5d84487be623e87e64377b0e850fcf556f58fe883f4729daff_prof);

        
        $__internal_aed5029af1a16338bc3f032d1043b8441267cd6e85d826be70abfd8787de0636->leave($__internal_aed5029af1a16338bc3f032d1043b8441267cd6e85d826be70abfd8787de0636_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/number_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?>
", "@Framework/Form/number_widget.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\number_widget.html.php");
    }
}
