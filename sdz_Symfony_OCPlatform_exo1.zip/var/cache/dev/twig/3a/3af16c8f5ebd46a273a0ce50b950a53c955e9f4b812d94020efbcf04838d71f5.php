<?php

/* OCCoreBundle::layout.html.twig */
class __TwigTemplate_c639be08ff952ba60b47ca1cc423b954187aa0d0e7a44c6f5956a9c968e8c391 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_65d99b214c6b261db640c62509fc76c971b7b491950db0e5b0d59535687168e8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_65d99b214c6b261db640c62509fc76c971b7b491950db0e5b0d59535687168e8->enter($__internal_65d99b214c6b261db640c62509fc76c971b7b491950db0e5b0d59535687168e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCCoreBundle::layout.html.twig"));

        $__internal_9cb659e57e255a5d1092aae83f16b221847f97a81d805cdb1f8c61c4fdfbb682 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9cb659e57e255a5d1092aae83f16b221847f97a81d805cdb1f8c61c4fdfbb682->enter($__internal_9cb659e57e255a5d1092aae83f16b221847f97a81d805cdb1f8c61c4fdfbb682_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCCoreBundle::layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">

    <title>";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

    ";
        // line 9
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 13
        echo "</head>

<body>
<div class=\"container\">
    <div id=\"header\" class=\"jumbotron\">
        <h1>Ma plateforme d'annonces</h1>
        <p>
            Ce projet est propulsé par Symfony,
            et construit grâce au MOOC OpenClassrooms et SensioLabs.
        </p>
        <p>
            <a class=\"btn btn-primary btn-lg\" href=\"https://openclassrooms.com/courses/developpez-votre-site-web-avec-le-framework-symfony2\">
                Participer au MOOC »
            </a>
        </p>
    </div>

    <div class=\"row\">
        <div id=\"menu\" class=\"col-md-3\">
            <h3>Menu</h3>
            <ul class=\"nav nav-pills nav-stacked\">
                <li><a href=\"";
        // line 34
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("oc_platform_home");
        echo "\">Accueil</a></li>
                <li><a href=\"";
        // line 35
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("oc_platform_add");
        echo "\">Ajouter une annonce</a></li>
            </ul>

            <h4>Dernières annonces</h4>
            ";
        // line 39
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("OCPlatformBundle:Advert:menu", array("limit" => 3)));
        echo "
        </div>
        <div id=\"content\" class=\"col-md-9\">
            ";
        // line 42
        $this->displayBlock('body', $context, $blocks);
        // line 44
        echo "        </div>
    </div>

    <hr>

    <footer>
        <p>The sky's the limit © ";
        // line 50
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y"), "html", null, true);
        echo " and beyond.</p>
    </footer>
</div>

";
        // line 54
        $this->displayBlock('javascripts', $context, $blocks);
        // line 59
        echo "
</body>
</html>";
        
        $__internal_65d99b214c6b261db640c62509fc76c971b7b491950db0e5b0d59535687168e8->leave($__internal_65d99b214c6b261db640c62509fc76c971b7b491950db0e5b0d59535687168e8_prof);

        
        $__internal_9cb659e57e255a5d1092aae83f16b221847f97a81d805cdb1f8c61c4fdfbb682->leave($__internal_9cb659e57e255a5d1092aae83f16b221847f97a81d805cdb1f8c61c4fdfbb682_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_2ef0a42853a0e8872902c9c6e338e63280627d7fc3900af429337d0d0ce391c4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2ef0a42853a0e8872902c9c6e338e63280627d7fc3900af429337d0d0ce391c4->enter($__internal_2ef0a42853a0e8872902c9c6e338e63280627d7fc3900af429337d0d0ce391c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_e9a2cdda118600e8a21e7551e09b32a06a50664d9306508c887f64ccb213a7fb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e9a2cdda118600e8a21e7551e09b32a06a50664d9306508c887f64ccb213a7fb->enter($__internal_e9a2cdda118600e8a21e7551e09b32a06a50664d9306508c887f64ccb213a7fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "OC Plateforme";
        
        $__internal_e9a2cdda118600e8a21e7551e09b32a06a50664d9306508c887f64ccb213a7fb->leave($__internal_e9a2cdda118600e8a21e7551e09b32a06a50664d9306508c887f64ccb213a7fb_prof);

        
        $__internal_2ef0a42853a0e8872902c9c6e338e63280627d7fc3900af429337d0d0ce391c4->leave($__internal_2ef0a42853a0e8872902c9c6e338e63280627d7fc3900af429337d0d0ce391c4_prof);

    }

    // line 9
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_5c6f1a7efb98815dc78e3d297ba7981ce180e35bfdeb12335ce03de6351543fb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5c6f1a7efb98815dc78e3d297ba7981ce180e35bfdeb12335ce03de6351543fb->enter($__internal_5c6f1a7efb98815dc78e3d297ba7981ce180e35bfdeb12335ce03de6351543fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_890550607cfad4df7ab317dc2b964c0d00c8f535b792ff87775e51ca5dfa8ee0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_890550607cfad4df7ab317dc2b964c0d00c8f535b792ff87775e51ca5dfa8ee0->enter($__internal_890550607cfad4df7ab317dc2b964c0d00c8f535b792ff87775e51ca5dfa8ee0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 10
        echo "        ";
        // line 11
        echo "        <link rel=\"stylesheet\" href=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css\">
    ";
        
        $__internal_890550607cfad4df7ab317dc2b964c0d00c8f535b792ff87775e51ca5dfa8ee0->leave($__internal_890550607cfad4df7ab317dc2b964c0d00c8f535b792ff87775e51ca5dfa8ee0_prof);

        
        $__internal_5c6f1a7efb98815dc78e3d297ba7981ce180e35bfdeb12335ce03de6351543fb->leave($__internal_5c6f1a7efb98815dc78e3d297ba7981ce180e35bfdeb12335ce03de6351543fb_prof);

    }

    // line 42
    public function block_body($context, array $blocks = array())
    {
        $__internal_6b25b2869a224a1db5e07dcdfc102b8462d3d2d0fd6ff2a6f2e90805c1dc5f71 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6b25b2869a224a1db5e07dcdfc102b8462d3d2d0fd6ff2a6f2e90805c1dc5f71->enter($__internal_6b25b2869a224a1db5e07dcdfc102b8462d3d2d0fd6ff2a6f2e90805c1dc5f71_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_05384a124cce6c61b779ca69da6e5acf07accc56b938afce28289988d6d77907 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_05384a124cce6c61b779ca69da6e5acf07accc56b938afce28289988d6d77907->enter($__internal_05384a124cce6c61b779ca69da6e5acf07accc56b938afce28289988d6d77907_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 43
        echo "            ";
        
        $__internal_05384a124cce6c61b779ca69da6e5acf07accc56b938afce28289988d6d77907->leave($__internal_05384a124cce6c61b779ca69da6e5acf07accc56b938afce28289988d6d77907_prof);

        
        $__internal_6b25b2869a224a1db5e07dcdfc102b8462d3d2d0fd6ff2a6f2e90805c1dc5f71->leave($__internal_6b25b2869a224a1db5e07dcdfc102b8462d3d2d0fd6ff2a6f2e90805c1dc5f71_prof);

    }

    // line 54
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_5c6eebff38a9032fde00fa6f4034f866ee4db749cb72592c2fc907ace49cd934 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5c6eebff38a9032fde00fa6f4034f866ee4db749cb72592c2fc907ace49cd934->enter($__internal_5c6eebff38a9032fde00fa6f4034f866ee4db749cb72592c2fc907ace49cd934_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_7fe74aa5f9e1cc7840a056dd8bec66e6c630dd5ba02769f8554cddf714d0ccd1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7fe74aa5f9e1cc7840a056dd8bec66e6c630dd5ba02769f8554cddf714d0ccd1->enter($__internal_7fe74aa5f9e1cc7840a056dd8bec66e6c630dd5ba02769f8554cddf714d0ccd1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 55
        echo "    ";
        // line 56
        echo "    <script src=\"//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js\"></script>
    <script src=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js\"></script>
";
        
        $__internal_7fe74aa5f9e1cc7840a056dd8bec66e6c630dd5ba02769f8554cddf714d0ccd1->leave($__internal_7fe74aa5f9e1cc7840a056dd8bec66e6c630dd5ba02769f8554cddf714d0ccd1_prof);

        
        $__internal_5c6eebff38a9032fde00fa6f4034f866ee4db749cb72592c2fc907ace49cd934->leave($__internal_5c6eebff38a9032fde00fa6f4034f866ee4db749cb72592c2fc907ace49cd934_prof);

    }

    public function getTemplateName()
    {
        return "OCCoreBundle::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  185 => 56,  183 => 55,  174 => 54,  164 => 43,  155 => 42,  144 => 11,  142 => 10,  133 => 9,  115 => 7,  103 => 59,  101 => 54,  94 => 50,  86 => 44,  84 => 42,  78 => 39,  71 => 35,  67 => 34,  44 => 13,  42 => 9,  37 => 7,  29 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
<head>
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">

    <title>{% block title %}OC Plateforme{% endblock %}</title>

    {% block stylesheets %}
        {# On charge le CSS de bootstrap depuis le site directement #}
        <link rel=\"stylesheet\" href=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css\">
    {% endblock %}
</head>

<body>
<div class=\"container\">
    <div id=\"header\" class=\"jumbotron\">
        <h1>Ma plateforme d'annonces</h1>
        <p>
            Ce projet est propulsé par Symfony,
            et construit grâce au MOOC OpenClassrooms et SensioLabs.
        </p>
        <p>
            <a class=\"btn btn-primary btn-lg\" href=\"https://openclassrooms.com/courses/developpez-votre-site-web-avec-le-framework-symfony2\">
                Participer au MOOC »
            </a>
        </p>
    </div>

    <div class=\"row\">
        <div id=\"menu\" class=\"col-md-3\">
            <h3>Menu</h3>
            <ul class=\"nav nav-pills nav-stacked\">
                <li><a href=\"{{ path('oc_platform_home') }}\">Accueil</a></li>
                <li><a href=\"{{ path('oc_platform_add') }}\">Ajouter une annonce</a></li>
            </ul>

            <h4>Dernières annonces</h4>
            {{ render(controller(\"OCPlatformBundle:Advert:menu\", {'limit': 3})) }}
        </div>
        <div id=\"content\" class=\"col-md-9\">
            {% block body %}
            {% endblock %}
        </div>
    </div>

    <hr>

    <footer>
        <p>The sky's the limit © {{ 'now'|date('Y') }} and beyond.</p>
    </footer>
</div>

{% block javascripts %}
    {# Ajoutez ces lignes JavaScript si vous comptez vous servir des fonctionnalités du bootstrap Twitter #}
    <script src=\"//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js\"></script>
    <script src=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js\"></script>
{% endblock %}

</body>
</html>", "OCCoreBundle::layout.html.twig", "C:\\wamp64\\www\\Symfony\\src\\OC\\CoreBundle/Resources/views/layout.html.twig");
    }
}
