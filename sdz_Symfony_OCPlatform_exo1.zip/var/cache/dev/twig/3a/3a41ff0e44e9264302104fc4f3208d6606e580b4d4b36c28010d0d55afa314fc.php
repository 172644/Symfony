<?php

/* @Framework/Form/form_widget.html.php */
class __TwigTemplate_2f789ef995e575d7d0af4f63eb97835944f4aacb0ffc6ccf90e92e23df8f8f1d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0a3d0624251ed03e87707b1f1d5dad2e30f6c2a0f03c1a97ec6288a587e9d054 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0a3d0624251ed03e87707b1f1d5dad2e30f6c2a0f03c1a97ec6288a587e9d054->enter($__internal_0a3d0624251ed03e87707b1f1d5dad2e30f6c2a0f03c1a97ec6288a587e9d054_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        $__internal_7f95b3d0efbfcc9c1a5cd4cc214a8810790ef1df3d02537411563f167cf078f0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7f95b3d0efbfcc9c1a5cd4cc214a8810790ef1df3d02537411563f167cf078f0->enter($__internal_7f95b3d0efbfcc9c1a5cd4cc214a8810790ef1df3d02537411563f167cf078f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        // line 1
        echo "<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
";
        
        $__internal_0a3d0624251ed03e87707b1f1d5dad2e30f6c2a0f03c1a97ec6288a587e9d054->leave($__internal_0a3d0624251ed03e87707b1f1d5dad2e30f6c2a0f03c1a97ec6288a587e9d054_prof);

        
        $__internal_7f95b3d0efbfcc9c1a5cd4cc214a8810790ef1df3d02537411563f167cf078f0->leave($__internal_7f95b3d0efbfcc9c1a5cd4cc214a8810790ef1df3d02537411563f167cf078f0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
", "@Framework/Form/form_widget.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_widget.html.php");
    }
}
