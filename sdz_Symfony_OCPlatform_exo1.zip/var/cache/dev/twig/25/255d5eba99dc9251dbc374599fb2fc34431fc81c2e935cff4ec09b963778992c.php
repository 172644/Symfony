<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_e995520f6ca92866f5cbf4a66e6306f691dbbf9662537736efc0bad866a52432 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_df5dee4e31f83968cbccd7420b772479de501a6c285866086412d64800603f2a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_df5dee4e31f83968cbccd7420b772479de501a6c285866086412d64800603f2a->enter($__internal_df5dee4e31f83968cbccd7420b772479de501a6c285866086412d64800603f2a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_5dddc59907bdabd58e35f31dd0533e61c0e6cfefd592409f16b35c5531853e63 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5dddc59907bdabd58e35f31dd0533e61c0e6cfefd592409f16b35c5531853e63->enter($__internal_5dddc59907bdabd58e35f31dd0533e61c0e6cfefd592409f16b35c5531853e63_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_df5dee4e31f83968cbccd7420b772479de501a6c285866086412d64800603f2a->leave($__internal_df5dee4e31f83968cbccd7420b772479de501a6c285866086412d64800603f2a_prof);

        
        $__internal_5dddc59907bdabd58e35f31dd0533e61c0e6cfefd592409f16b35c5531853e63->leave($__internal_5dddc59907bdabd58e35f31dd0533e61c0e6cfefd592409f16b35c5531853e63_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_331d30e68d140bb797f62420c4e5573cf8e31a3f37fa04f07fc2218570544ab1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_331d30e68d140bb797f62420c4e5573cf8e31a3f37fa04f07fc2218570544ab1->enter($__internal_331d30e68d140bb797f62420c4e5573cf8e31a3f37fa04f07fc2218570544ab1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_8ba14ee7e9f40d1c0b347b099c3175950b211ef73614c61e67f9addf3f908d15 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8ba14ee7e9f40d1c0b347b099c3175950b211ef73614c61e67f9addf3f908d15->enter($__internal_8ba14ee7e9f40d1c0b347b099c3175950b211ef73614c61e67f9addf3f908d15_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if (twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 4, $this->getSourceContext()); })()), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new Twig_Error_Runtime('Variable "token" does not exist.', 6, $this->getSourceContext()); })()))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_8ba14ee7e9f40d1c0b347b099c3175950b211ef73614c61e67f9addf3f908d15->leave($__internal_8ba14ee7e9f40d1c0b347b099c3175950b211ef73614c61e67f9addf3f908d15_prof);

        
        $__internal_331d30e68d140bb797f62420c4e5573cf8e31a3f37fa04f07fc2218570544ab1->leave($__internal_331d30e68d140bb797f62420c4e5573cf8e31a3f37fa04f07fc2218570544ab1_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_c7ea3665a4de8ac1e0eb08b9328d1ec63ae9ba705bf67d77fae7267b523ae5b2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c7ea3665a4de8ac1e0eb08b9328d1ec63ae9ba705bf67d77fae7267b523ae5b2->enter($__internal_c7ea3665a4de8ac1e0eb08b9328d1ec63ae9ba705bf67d77fae7267b523ae5b2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_b661d7f16037c369dd5f2d8eb2fac1f2f7eaf7af0585941e62612dc419a14b0e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b661d7f16037c369dd5f2d8eb2fac1f2f7eaf7af0585941e62612dc419a14b0e->enter($__internal_b661d7f16037c369dd5f2d8eb2fac1f2f7eaf7af0585941e62612dc419a14b0e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo ((twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 13, $this->getSourceContext()); })()), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if (twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 16, $this->getSourceContext()); })()), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_b661d7f16037c369dd5f2d8eb2fac1f2f7eaf7af0585941e62612dc419a14b0e->leave($__internal_b661d7f16037c369dd5f2d8eb2fac1f2f7eaf7af0585941e62612dc419a14b0e_prof);

        
        $__internal_c7ea3665a4de8ac1e0eb08b9328d1ec63ae9ba705bf67d77fae7267b523ae5b2->leave($__internal_c7ea3665a4de8ac1e0eb08b9328d1ec63ae9ba705bf67d77fae7267b523ae5b2_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_ce30a98ed318e83fa25fae2144e80aec5172ad08da5314b22bf4119e9c59e0b9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ce30a98ed318e83fa25fae2144e80aec5172ad08da5314b22bf4119e9c59e0b9->enter($__internal_ce30a98ed318e83fa25fae2144e80aec5172ad08da5314b22bf4119e9c59e0b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_f391df9b4d67fefc40ce799e92e5d51cb020246b4404ebf3e044662d1892eb71 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f391df9b4d67fefc40ce799e92e5d51cb020246b4404ebf3e044662d1892eb71->enter($__internal_f391df9b4d67fefc40ce799e92e5d51cb020246b4404ebf3e044662d1892eb71_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 27, $this->getSourceContext()); })()), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new Twig_Error_Runtime('Variable "token" does not exist.', 33, $this->getSourceContext()); })()))));
            echo "
        </div>
    ";
        }
        
        $__internal_f391df9b4d67fefc40ce799e92e5d51cb020246b4404ebf3e044662d1892eb71->leave($__internal_f391df9b4d67fefc40ce799e92e5d51cb020246b4404ebf3e044662d1892eb71_prof);

        
        $__internal_ce30a98ed318e83fa25fae2144e80aec5172ad08da5314b22bf4119e9c59e0b9->leave($__internal_ce30a98ed318e83fa25fae2144e80aec5172ad08da5314b22bf4119e9c59e0b9_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\exception.html.twig");
    }
}
