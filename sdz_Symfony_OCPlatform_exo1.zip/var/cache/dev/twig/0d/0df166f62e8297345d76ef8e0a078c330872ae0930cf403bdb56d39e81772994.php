<?php

/* @WebProfiler/Profiler/ajax_layout.html.twig */
class __TwigTemplate_231a6202bafe67b581ad89785127b9db77d81281716173452354d091b78d7e1f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5e88f0c597dad915f2eb6ea5d08a1ee4a4bfd050deaf970d72cd3d6cb3791280 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5e88f0c597dad915f2eb6ea5d08a1ee4a4bfd050deaf970d72cd3d6cb3791280->enter($__internal_5e88f0c597dad915f2eb6ea5d08a1ee4a4bfd050deaf970d72cd3d6cb3791280_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        $__internal_f4b50ef549827850c273d935b6e79febff687074b6b79fd0f691a77fb158574f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f4b50ef549827850c273d935b6e79febff687074b6b79fd0f691a77fb158574f->enter($__internal_f4b50ef549827850c273d935b6e79febff687074b6b79fd0f691a77fb158574f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_5e88f0c597dad915f2eb6ea5d08a1ee4a4bfd050deaf970d72cd3d6cb3791280->leave($__internal_5e88f0c597dad915f2eb6ea5d08a1ee4a4bfd050deaf970d72cd3d6cb3791280_prof);

        
        $__internal_f4b50ef549827850c273d935b6e79febff687074b6b79fd0f691a77fb158574f->leave($__internal_f4b50ef549827850c273d935b6e79febff687074b6b79fd0f691a77fb158574f_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_7bb3fe3702b8707250bd9c557cc9414ed1c108e38e118808b567f0249a214b4a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7bb3fe3702b8707250bd9c557cc9414ed1c108e38e118808b567f0249a214b4a->enter($__internal_7bb3fe3702b8707250bd9c557cc9414ed1c108e38e118808b567f0249a214b4a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_9df6e0d88b9bac4a21d4f197bf95cfe3485824bedc93c2df7176a16616eee4d7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9df6e0d88b9bac4a21d4f197bf95cfe3485824bedc93c2df7176a16616eee4d7->enter($__internal_9df6e0d88b9bac4a21d4f197bf95cfe3485824bedc93c2df7176a16616eee4d7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_9df6e0d88b9bac4a21d4f197bf95cfe3485824bedc93c2df7176a16616eee4d7->leave($__internal_9df6e0d88b9bac4a21d4f197bf95cfe3485824bedc93c2df7176a16616eee4d7_prof);

        
        $__internal_7bb3fe3702b8707250bd9c557cc9414ed1c108e38e118808b567f0249a214b4a->leave($__internal_7bb3fe3702b8707250bd9c557cc9414ed1c108e38e118808b567f0249a214b4a_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "@WebProfiler/Profiler/ajax_layout.html.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\ajax_layout.html.twig");
    }
}
