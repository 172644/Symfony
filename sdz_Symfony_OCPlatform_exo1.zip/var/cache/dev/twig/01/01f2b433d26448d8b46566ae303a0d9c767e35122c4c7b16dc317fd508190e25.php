<?php

/* TwigBundle:Exception:error.txt.twig */
class __TwigTemplate_935e3da299029b0a8f1b26971affa5767b493ce9fef094f4363f4f4bbba343f0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8bf66f205a94009ac5ff14f39dc5acdb925bddb223b20de1199c2aaa1a974781 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8bf66f205a94009ac5ff14f39dc5acdb925bddb223b20de1199c2aaa1a974781->enter($__internal_8bf66f205a94009ac5ff14f39dc5acdb925bddb223b20de1199c2aaa1a974781_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.txt.twig"));

        $__internal_2c0f4cf40c77df2611059e5eed869df1c48bb333adabaf89481551c1fc953100 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2c0f4cf40c77df2611059e5eed869df1c48bb333adabaf89481551c1fc953100->enter($__internal_2c0f4cf40c77df2611059e5eed869df1c48bb333adabaf89481551c1fc953100_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.txt.twig"));

        // line 1
        echo "Oops! An Error Occurred
=======================

The server returned a \"";
        // line 4
        echo (isset($context["status_code"]) || array_key_exists("status_code", $context) ? $context["status_code"] : (function () { throw new Twig_Error_Runtime('Variable "status_code" does not exist.', 4, $this->getSourceContext()); })());
        echo " ";
        echo (isset($context["status_text"]) || array_key_exists("status_text", $context) ? $context["status_text"] : (function () { throw new Twig_Error_Runtime('Variable "status_text" does not exist.', 4, $this->getSourceContext()); })());
        echo "\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
";
        
        $__internal_8bf66f205a94009ac5ff14f39dc5acdb925bddb223b20de1199c2aaa1a974781->leave($__internal_8bf66f205a94009ac5ff14f39dc5acdb925bddb223b20de1199c2aaa1a974781_prof);

        
        $__internal_2c0f4cf40c77df2611059e5eed869df1c48bb333adabaf89481551c1fc953100->leave($__internal_2c0f4cf40c77df2611059e5eed869df1c48bb333adabaf89481551c1fc953100_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.txt.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 4,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("Oops! An Error Occurred
=======================

The server returned a \"{{ status_code }} {{ status_text }}\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
", "TwigBundle:Exception:error.txt.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.txt.twig");
    }
}
