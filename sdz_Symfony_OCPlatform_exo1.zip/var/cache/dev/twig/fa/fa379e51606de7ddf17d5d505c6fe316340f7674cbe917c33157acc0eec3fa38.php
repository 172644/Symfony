<?php

/* @Framework/Form/form.html.php */
class __TwigTemplate_151a6fca3706e4da176f21c576777c41628d02fbff7cc16fdb1cf00db2b4aa37 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_af74149e92775aa8af4e8fbf724d830517e2e45aaa5dbdd4b94a1bd24aa0c3be = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_af74149e92775aa8af4e8fbf724d830517e2e45aaa5dbdd4b94a1bd24aa0c3be->enter($__internal_af74149e92775aa8af4e8fbf724d830517e2e45aaa5dbdd4b94a1bd24aa0c3be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        $__internal_631f458fdbf0a33e599cd68ea9dad7749a6deb815f7cf0feacd2af848e98a6e5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_631f458fdbf0a33e599cd68ea9dad7749a6deb815f7cf0feacd2af848e98a6e5->enter($__internal_631f458fdbf0a33e599cd68ea9dad7749a6deb815f7cf0feacd2af848e98a6e5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        // line 1
        echo "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
        
        $__internal_af74149e92775aa8af4e8fbf724d830517e2e45aaa5dbdd4b94a1bd24aa0c3be->leave($__internal_af74149e92775aa8af4e8fbf724d830517e2e45aaa5dbdd4b94a1bd24aa0c3be_prof);

        
        $__internal_631f458fdbf0a33e599cd68ea9dad7749a6deb815f7cf0feacd2af848e98a6e5->leave($__internal_631f458fdbf0a33e599cd68ea9dad7749a6deb815f7cf0feacd2af848e98a6e5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
", "@Framework/Form/form.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form.html.php");
    }
}
