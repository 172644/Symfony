<?php

/* @OCPlatform/Advert/form.html.twig */
class __TwigTemplate_c9d8b3619abcdd1eb7c6d96517fa171340c05016f48d7996707a04fc334945bd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_50d9bcdaa0d0e420863a43e6d40912cab320fe2db4d9ac7b7be73d555fbe020e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_50d9bcdaa0d0e420863a43e6d40912cab320fe2db4d9ac7b7be73d555fbe020e->enter($__internal_50d9bcdaa0d0e420863a43e6d40912cab320fe2db4d9ac7b7be73d555fbe020e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@OCPlatform/Advert/form.html.twig"));

        $__internal_eb584fee21efe81c7d00c5fd5865e36e8d850671eca0dd6bfa9e4467ae26b879 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eb584fee21efe81c7d00c5fd5865e36e8d850671eca0dd6bfa9e4467ae26b879->enter($__internal_eb584fee21efe81c7d00c5fd5865e36e8d850671eca0dd6bfa9e4467ae26b879_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@OCPlatform/Advert/form.html.twig"));

        // line 1
        echo "<h3>Formulaire d'annonce</h3>

";
        // line 5
        echo "<div class=\"well\">
    Ici se trouvera le formulaire.
</div>";
        
        $__internal_50d9bcdaa0d0e420863a43e6d40912cab320fe2db4d9ac7b7be73d555fbe020e->leave($__internal_50d9bcdaa0d0e420863a43e6d40912cab320fe2db4d9ac7b7be73d555fbe020e_prof);

        
        $__internal_eb584fee21efe81c7d00c5fd5865e36e8d850671eca0dd6bfa9e4467ae26b879->leave($__internal_eb584fee21efe81c7d00c5fd5865e36e8d850671eca0dd6bfa9e4467ae26b879_prof);

    }

    public function getTemplateName()
    {
        return "@OCPlatform/Advert/form.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  29 => 5,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<h3>Formulaire d'annonce</h3>

{# On laisse vide la vue pour l'instant, on la comblera plus tard
   lorsqu'on saura afficher un formulaire. #}
<div class=\"well\">
    Ici se trouvera le formulaire.
</div>", "@OCPlatform/Advert/form.html.twig", "C:\\wamp64\\www\\Symfony\\src\\OC\\PlatformBundle\\Resources\\views\\Advert\\form.html.twig");
    }
}
