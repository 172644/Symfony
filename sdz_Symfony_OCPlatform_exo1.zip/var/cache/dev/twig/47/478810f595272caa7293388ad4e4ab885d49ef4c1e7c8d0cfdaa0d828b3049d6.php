<?php

/* @Framework/Form/percent_widget.html.php */
class __TwigTemplate_770eaee18c019bfdde520585199809a6347331af35ef940edfdb462b0ef52635 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_519e19ed8fb53494ffefa11a00597ba206c03325640cd612cb69b94eebd829bb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_519e19ed8fb53494ffefa11a00597ba206c03325640cd612cb69b94eebd829bb->enter($__internal_519e19ed8fb53494ffefa11a00597ba206c03325640cd612cb69b94eebd829bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        $__internal_88f224f46fdf4707fe5b247645af5278d3e7ce6902afd2e9e048746a8fe3de80 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_88f224f46fdf4707fe5b247645af5278d3e7ce6902afd2e9e048746a8fe3de80->enter($__internal_88f224f46fdf4707fe5b247645af5278d3e7ce6902afd2e9e048746a8fe3de80_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?> %
";
        
        $__internal_519e19ed8fb53494ffefa11a00597ba206c03325640cd612cb69b94eebd829bb->leave($__internal_519e19ed8fb53494ffefa11a00597ba206c03325640cd612cb69b94eebd829bb_prof);

        
        $__internal_88f224f46fdf4707fe5b247645af5278d3e7ce6902afd2e9e048746a8fe3de80->leave($__internal_88f224f46fdf4707fe5b247645af5278d3e7ce6902afd2e9e048746a8fe3de80_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/percent_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?> %
", "@Framework/Form/percent_widget.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\percent_widget.html.php");
    }
}
