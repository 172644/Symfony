<?php

/* WebProfilerBundle:Profiler:open.html.twig */
class __TwigTemplate_721de2e0fe684aac9284f1d1c47e54d246918676febe1f636fc59626f3fe592f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/base.html.twig", "WebProfilerBundle:Profiler:open.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_13e011f9825ce49343b74a826ee14c56897ec93bd1adfb6ab1d73d86aaf184fe = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_13e011f9825ce49343b74a826ee14c56897ec93bd1adfb6ab1d73d86aaf184fe->enter($__internal_13e011f9825ce49343b74a826ee14c56897ec93bd1adfb6ab1d73d86aaf184fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $__internal_13c6fc9e4b61a7d576e94f889ec2fe081ac221541ac6a9304a6e2c117bff855c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_13c6fc9e4b61a7d576e94f889ec2fe081ac221541ac6a9304a6e2c117bff855c->enter($__internal_13c6fc9e4b61a7d576e94f889ec2fe081ac221541ac6a9304a6e2c117bff855c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_13e011f9825ce49343b74a826ee14c56897ec93bd1adfb6ab1d73d86aaf184fe->leave($__internal_13e011f9825ce49343b74a826ee14c56897ec93bd1adfb6ab1d73d86aaf184fe_prof);

        
        $__internal_13c6fc9e4b61a7d576e94f889ec2fe081ac221541ac6a9304a6e2c117bff855c->leave($__internal_13c6fc9e4b61a7d576e94f889ec2fe081ac221541ac6a9304a6e2c117bff855c_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_cc2c454d5ee00bfb11496e4403582b6c3933f201e06e40d75ac16186e481a67c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cc2c454d5ee00bfb11496e4403582b6c3933f201e06e40d75ac16186e481a67c->enter($__internal_cc2c454d5ee00bfb11496e4403582b6c3933f201e06e40d75ac16186e481a67c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_1428d67bc07e4121f9df28d031c588564781392a0b2dd0a853de34ba7ac6fa08 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1428d67bc07e4121f9df28d031c588564781392a0b2dd0a853de34ba7ac6fa08->enter($__internal_1428d67bc07e4121f9df28d031c588564781392a0b2dd0a853de34ba7ac6fa08_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        ";
        // line 5
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/open.css.twig");
        echo "
    </style>
";
        
        $__internal_1428d67bc07e4121f9df28d031c588564781392a0b2dd0a853de34ba7ac6fa08->leave($__internal_1428d67bc07e4121f9df28d031c588564781392a0b2dd0a853de34ba7ac6fa08_prof);

        
        $__internal_cc2c454d5ee00bfb11496e4403582b6c3933f201e06e40d75ac16186e481a67c->leave($__internal_cc2c454d5ee00bfb11496e4403582b6c3933f201e06e40d75ac16186e481a67c_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_569fdc4af13c027c3516048f5d98299df49a5fa942e99e5134564a04d0280ad0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_569fdc4af13c027c3516048f5d98299df49a5fa942e99e5134564a04d0280ad0->enter($__internal_569fdc4af13c027c3516048f5d98299df49a5fa942e99e5134564a04d0280ad0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_5586ab4c7ed141cbc73b75fa05b37a10083625298ed0e01a7b18f9b6b20d12bb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5586ab4c7ed141cbc73b75fa05b37a10083625298ed0e01a7b18f9b6b20d12bb->enter($__internal_5586ab4c7ed141cbc73b75fa05b37a10083625298ed0e01a7b18f9b6b20d12bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"header\">
    <h1>";
        // line 11
        echo twig_escape_filter($this->env, (isset($context["file"]) || array_key_exists("file", $context) ? $context["file"] : (function () { throw new Twig_Error_Runtime('Variable "file" does not exist.', 11, $this->getSourceContext()); })()), "html", null, true);
        echo " <small>line ";
        echo twig_escape_filter($this->env, (isset($context["line"]) || array_key_exists("line", $context) ? $context["line"] : (function () { throw new Twig_Error_Runtime('Variable "line" does not exist.', 11, $this->getSourceContext()); })()), "html", null, true);
        echo "</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/";
        // line 12
        echo twig_escape_filter($this->env, twig_constant("Symfony\\Component\\HttpKernel\\Kernel::VERSION"), "html", null, true);
        echo "/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt((isset($context["filename"]) || array_key_exists("filename", $context) ? $context["filename"] : (function () { throw new Twig_Error_Runtime('Variable "filename" does not exist.', 15, $this->getSourceContext()); })()), (isset($context["line"]) || array_key_exists("line", $context) ? $context["line"] : (function () { throw new Twig_Error_Runtime('Variable "line" does not exist.', 15, $this->getSourceContext()); })()),  -1);
        echo "
</div>
";
        
        $__internal_5586ab4c7ed141cbc73b75fa05b37a10083625298ed0e01a7b18f9b6b20d12bb->leave($__internal_5586ab4c7ed141cbc73b75fa05b37a10083625298ed0e01a7b18f9b6b20d12bb_prof);

        
        $__internal_569fdc4af13c027c3516048f5d98299df49a5fa942e99e5134564a04d0280ad0->leave($__internal_569fdc4af13c027c3516048f5d98299df49a5fa942e99e5134564a04d0280ad0_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:open.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  84 => 12,  78 => 11,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/base.html.twig' %}

{% block head %}
    <style>
        {{ include('@WebProfiler/Profiler/open.css.twig') }}
    </style>
{% endblock %}

{% block body %}
<div class=\"header\">
    <h1>{{ file }} <small>line {{ line }}</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/{{ constant('Symfony\\\\Component\\\\HttpKernel\\\\Kernel::VERSION') }}/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    {{ filename|file_excerpt(line, -1) }}
</div>
{% endblock %}
", "WebProfilerBundle:Profiler:open.html.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/open.html.twig");
    }
}
