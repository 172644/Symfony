<?php

/* @Twig/Exception/error.txt.twig */
class __TwigTemplate_879300fc6f9c7c2a73ab06ce6b61fc40b0d6ffd9ca8d832b6d93edd210848160 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_aefec0b2919be018f58588eecae3d57a64b13101a52f131dd31f7acf9aa7b06f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_aefec0b2919be018f58588eecae3d57a64b13101a52f131dd31f7acf9aa7b06f->enter($__internal_aefec0b2919be018f58588eecae3d57a64b13101a52f131dd31f7acf9aa7b06f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.txt.twig"));

        $__internal_3b471b5b380451f7b40fc7f7cad996843e7299683b08b96956ae924c1ec0244d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3b471b5b380451f7b40fc7f7cad996843e7299683b08b96956ae924c1ec0244d->enter($__internal_3b471b5b380451f7b40fc7f7cad996843e7299683b08b96956ae924c1ec0244d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.txt.twig"));

        // line 1
        echo "Oops! An Error Occurred
=======================

The server returned a \"";
        // line 4
        echo (isset($context["status_code"]) || array_key_exists("status_code", $context) ? $context["status_code"] : (function () { throw new Twig_Error_Runtime('Variable "status_code" does not exist.', 4, $this->getSourceContext()); })());
        echo " ";
        echo (isset($context["status_text"]) || array_key_exists("status_text", $context) ? $context["status_text"] : (function () { throw new Twig_Error_Runtime('Variable "status_text" does not exist.', 4, $this->getSourceContext()); })());
        echo "\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
";
        
        $__internal_aefec0b2919be018f58588eecae3d57a64b13101a52f131dd31f7acf9aa7b06f->leave($__internal_aefec0b2919be018f58588eecae3d57a64b13101a52f131dd31f7acf9aa7b06f_prof);

        
        $__internal_3b471b5b380451f7b40fc7f7cad996843e7299683b08b96956ae924c1ec0244d->leave($__internal_3b471b5b380451f7b40fc7f7cad996843e7299683b08b96956ae924c1ec0244d_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.txt.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 4,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("Oops! An Error Occurred
=======================

The server returned a \"{{ status_code }} {{ status_text }}\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
", "@Twig/Exception/error.txt.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.txt.twig");
    }
}
