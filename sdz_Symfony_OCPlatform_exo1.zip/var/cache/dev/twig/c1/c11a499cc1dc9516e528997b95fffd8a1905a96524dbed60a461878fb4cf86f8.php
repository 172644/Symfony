<?php

/* TwigBundle:Exception:error.js.twig */
class __TwigTemplate_ab74f708969e0db98059ba793cd76aa0855cea465ca9c291b37bb2bf5efc4134 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_21aa5ea2ea58ec59e72e05631d21d2cdf448ce80c6dfe9239f6adf92bcedcd18 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_21aa5ea2ea58ec59e72e05631d21d2cdf448ce80c6dfe9239f6adf92bcedcd18->enter($__internal_21aa5ea2ea58ec59e72e05631d21d2cdf448ce80c6dfe9239f6adf92bcedcd18_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        $__internal_0b65413f2a472778794b9ad40aafde442a3970abe4caa4be377e7fd8941cf5f9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0b65413f2a472778794b9ad40aafde442a3970abe4caa4be377e7fd8941cf5f9->enter($__internal_0b65413f2a472778794b9ad40aafde442a3970abe4caa4be377e7fd8941cf5f9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) || array_key_exists("status_code", $context) ? $context["status_code"] : (function () { throw new Twig_Error_Runtime('Variable "status_code" does not exist.', 2, $this->getSourceContext()); })()), "js", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) || array_key_exists("status_text", $context) ? $context["status_text"] : (function () { throw new Twig_Error_Runtime('Variable "status_text" does not exist.', 2, $this->getSourceContext()); })()), "js", null, true);
        echo "

*/
";
        
        $__internal_21aa5ea2ea58ec59e72e05631d21d2cdf448ce80c6dfe9239f6adf92bcedcd18->leave($__internal_21aa5ea2ea58ec59e72e05631d21d2cdf448ce80c6dfe9239f6adf92bcedcd18_prof);

        
        $__internal_0b65413f2a472778794b9ad40aafde442a3970abe4caa4be377e7fd8941cf5f9->leave($__internal_0b65413f2a472778794b9ad40aafde442a3970abe4caa4be377e7fd8941cf5f9_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "TwigBundle:Exception:error.js.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.js.twig");
    }
}
