<?php

/* OCPlatformBundle:Advert:edit.html.twig */
class __TwigTemplate_4a6c8a78307b3d2cf00f353aae0872eb6990eecc9cd708c247a9a1374d8b77c7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("OCPlatformBundle::layout.html.twig", "OCPlatformBundle:Advert:edit.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'ocplatform_body' => array($this, 'block_ocplatform_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "OCPlatformBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2c87926e82443fc1ac9ad017f7a91ff1f0047daeb26698d2adf27a39df1d6d0f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2c87926e82443fc1ac9ad017f7a91ff1f0047daeb26698d2adf27a39df1d6d0f->enter($__internal_2c87926e82443fc1ac9ad017f7a91ff1f0047daeb26698d2adf27a39df1d6d0f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:edit.html.twig"));

        $__internal_313874642cca0d32833ed2b931f99f529dc4906540f9959eb228ce327b7fd899 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_313874642cca0d32833ed2b931f99f529dc4906540f9959eb228ce327b7fd899->enter($__internal_313874642cca0d32833ed2b931f99f529dc4906540f9959eb228ce327b7fd899_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2c87926e82443fc1ac9ad017f7a91ff1f0047daeb26698d2adf27a39df1d6d0f->leave($__internal_2c87926e82443fc1ac9ad017f7a91ff1f0047daeb26698d2adf27a39df1d6d0f_prof);

        
        $__internal_313874642cca0d32833ed2b931f99f529dc4906540f9959eb228ce327b7fd899->leave($__internal_313874642cca0d32833ed2b931f99f529dc4906540f9959eb228ce327b7fd899_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_89acfe9eeabbde37c8b44f8c0aec3eaa0da373ad28022448146c174e464108bd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_89acfe9eeabbde37c8b44f8c0aec3eaa0da373ad28022448146c174e464108bd->enter($__internal_89acfe9eeabbde37c8b44f8c0aec3eaa0da373ad28022448146c174e464108bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_e0e305f2a3747813c7762d68fcbb7fbaa860686a3996267f0a8487b5fe08b3e7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e0e305f2a3747813c7762d68fcbb7fbaa860686a3996267f0a8487b5fe08b3e7->enter($__internal_e0e305f2a3747813c7762d68fcbb7fbaa860686a3996267f0a8487b5fe08b3e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "    Modifier une annonce - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
        
        $__internal_e0e305f2a3747813c7762d68fcbb7fbaa860686a3996267f0a8487b5fe08b3e7->leave($__internal_e0e305f2a3747813c7762d68fcbb7fbaa860686a3996267f0a8487b5fe08b3e7_prof);

        
        $__internal_89acfe9eeabbde37c8b44f8c0aec3eaa0da373ad28022448146c174e464108bd->leave($__internal_89acfe9eeabbde37c8b44f8c0aec3eaa0da373ad28022448146c174e464108bd_prof);

    }

    // line 7
    public function block_ocplatform_body($context, array $blocks = array())
    {
        $__internal_8f542d1ec82a0b24225b7d0902a9463e14733792aa87fb38f2c822cac015ee4d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8f542d1ec82a0b24225b7d0902a9463e14733792aa87fb38f2c822cac015ee4d->enter($__internal_8f542d1ec82a0b24225b7d0902a9463e14733792aa87fb38f2c822cac015ee4d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        $__internal_2a0b27d3b5b1349b171e9a5d0393d8510de81cb951cb973d2552945cc7e32aea = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2a0b27d3b5b1349b171e9a5d0393d8510de81cb951cb973d2552945cc7e32aea->enter($__internal_2a0b27d3b5b1349b171e9a5d0393d8510de81cb951cb973d2552945cc7e32aea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        // line 8
        echo "
    <h2>Modifier une annonce</h2>

    ";
        // line 11
        echo twig_include($this->env, $context, "OCPlatformBundle:Advert:form.html.twig");
        echo "

    <p>
        Vous éditez une annonce déjà existante, merci de ne pas changer
        l'esprit général de l'annonce déjà publiée.
    </p>

    <p>
        <a href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("oc_platform_view", array("id" => twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["advert"]) || array_key_exists("advert", $context) ? $context["advert"] : (function () { throw new Twig_Error_Runtime('Variable "advert" does not exist.', 19, $this->getSourceContext()); })()), "id", array()))), "html", null, true);
        echo "\" class=\"btn btn-default\">
            <i class=\"glyphicon glyphicon-chevron-left\"></i>
            Retour à l'annonce
        </a>
    </p>

";
        
        $__internal_2a0b27d3b5b1349b171e9a5d0393d8510de81cb951cb973d2552945cc7e32aea->leave($__internal_2a0b27d3b5b1349b171e9a5d0393d8510de81cb951cb973d2552945cc7e32aea_prof);

        
        $__internal_8f542d1ec82a0b24225b7d0902a9463e14733792aa87fb38f2c822cac015ee4d->leave($__internal_8f542d1ec82a0b24225b7d0902a9463e14733792aa87fb38f2c822cac015ee4d_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Advert:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 19,  77 => 11,  72 => 8,  63 => 7,  50 => 4,  41 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"OCPlatformBundle::layout.html.twig\" %}

{% block title %}
    Modifier une annonce - {{ parent() }}
{% endblock %}

{% block ocplatform_body %}

    <h2>Modifier une annonce</h2>

    {{ include(\"OCPlatformBundle:Advert:form.html.twig\") }}

    <p>
        Vous éditez une annonce déjà existante, merci de ne pas changer
        l'esprit général de l'annonce déjà publiée.
    </p>

    <p>
        <a href=\"{{ path('oc_platform_view', {'id': advert.id}) }}\" class=\"btn btn-default\">
            <i class=\"glyphicon glyphicon-chevron-left\"></i>
            Retour à l'annonce
        </a>
    </p>

{% endblock %}", "OCPlatformBundle:Advert:edit.html.twig", "C:\\wamp64\\www\\Symfony\\src\\OC\\PlatformBundle/Resources/views/Advert/edit.html.twig");
    }
}
