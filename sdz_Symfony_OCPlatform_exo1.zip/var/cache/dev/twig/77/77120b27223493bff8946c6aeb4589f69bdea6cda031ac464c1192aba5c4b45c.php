<?php

/* TwigBundle:Exception:error.json.twig */
class __TwigTemplate_26dd463389af6b38933d8baf8359ca70d51c170591cfe34193295082f8d97fd3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_054475d4f5c763fa8100b0f80dcdbeba50b9e4224222df4ae9ca81afb0fa7220 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_054475d4f5c763fa8100b0f80dcdbeba50b9e4224222df4ae9ca81afb0fa7220->enter($__internal_054475d4f5c763fa8100b0f80dcdbeba50b9e4224222df4ae9ca81afb0fa7220_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        $__internal_5897aed9d3315335b31576753ed0468ca827444bd6fe54713063ab318fc7282b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5897aed9d3315335b31576753ed0468ca827444bd6fe54713063ab318fc7282b->enter($__internal_5897aed9d3315335b31576753ed0468ca827444bd6fe54713063ab318fc7282b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        // line 1
        echo json_encode(array("error" => array("code" => (isset($context["status_code"]) || array_key_exists("status_code", $context) ? $context["status_code"] : (function () { throw new Twig_Error_Runtime('Variable "status_code" does not exist.', 1, $this->getSourceContext()); })()), "message" => (isset($context["status_text"]) || array_key_exists("status_text", $context) ? $context["status_text"] : (function () { throw new Twig_Error_Runtime('Variable "status_text" does not exist.', 1, $this->getSourceContext()); })()))));
        echo "
";
        
        $__internal_054475d4f5c763fa8100b0f80dcdbeba50b9e4224222df4ae9ca81afb0fa7220->leave($__internal_054475d4f5c763fa8100b0f80dcdbeba50b9e4224222df4ae9ca81afb0fa7220_prof);

        
        $__internal_5897aed9d3315335b31576753ed0468ca827444bd6fe54713063ab318fc7282b->leave($__internal_5897aed9d3315335b31576753ed0468ca827444bd6fe54713063ab318fc7282b_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}
", "TwigBundle:Exception:error.json.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.json.twig");
    }
}
