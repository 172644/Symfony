<?php

/* TwigBundle::layout.html.twig */
class __TwigTemplate_ba09863c74c372799ef543318c4660f33e0eb6dde62ac9e58f1f89b20fe593c6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7df3a668b49e0b503989a66275281d0d5e2286ea6aa030196deb3fb4a9e0a03c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7df3a668b49e0b503989a66275281d0d5e2286ea6aa030196deb3fb4a9e0a03c->enter($__internal_7df3a668b49e0b503989a66275281d0d5e2286ea6aa030196deb3fb4a9e0a03c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle::layout.html.twig"));

        $__internal_b96313cac9b38ac5447e58e5106362be0d2c63188ddd107fd1ea29feff395536 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b96313cac9b38ac5447e58e5106362be0d2c63188ddd107fd1ea29feff395536->enter($__internal_b96313cac9b38ac5447e58e5106362be0d2c63188ddd107fd1ea29feff395536_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle::layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getCharset(), "html", null, true);
        echo "\" />
        <meta name=\"robots\" content=\"noindex,nofollow\" />
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\" />
        <title>";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        <link rel=\"icon\" type=\"image/png\" href=\"";
        // line 8
        echo twig_include($this->env, $context, "@Twig/images/favicon.png.base64");
        echo "\">
        <style>";
        // line 9
        echo twig_include($this->env, $context, "@Twig/exception.css.twig");
        echo "</style>
        ";
        // line 10
        $this->displayBlock('head', $context, $blocks);
        // line 11
        echo "    </head>
    <body>
        <header>
            <div class=\"container\">
                <h1 class=\"logo\">";
        // line 15
        echo twig_include($this->env, $context, "@Twig/images/symfony-logo.svg");
        echo " Symfony Exception</h1>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/doc\">
                        <span class=\"icon\">";
        // line 19
        echo twig_include($this->env, $context, "@Twig/images/icon-book.svg");
        echo "</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Docs
                    </a>
                </div>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/support\">
                        <span class=\"icon\">";
        // line 26
        echo twig_include($this->env, $context, "@Twig/images/icon-support.svg");
        echo "</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Support
                    </a>
                </div>
            </div>
        </header>

        ";
        // line 33
        $this->displayBlock('body', $context, $blocks);
        // line 34
        echo "        ";
        echo twig_include($this->env, $context, "@Twig/base_js.html.twig");
        echo "
    </body>
</html>
";
        
        $__internal_7df3a668b49e0b503989a66275281d0d5e2286ea6aa030196deb3fb4a9e0a03c->leave($__internal_7df3a668b49e0b503989a66275281d0d5e2286ea6aa030196deb3fb4a9e0a03c_prof);

        
        $__internal_b96313cac9b38ac5447e58e5106362be0d2c63188ddd107fd1ea29feff395536->leave($__internal_b96313cac9b38ac5447e58e5106362be0d2c63188ddd107fd1ea29feff395536_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_a53c1770bba716544f20e83fbbed9e04a37b91566823f062b7df796d51beb937 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a53c1770bba716544f20e83fbbed9e04a37b91566823f062b7df796d51beb937->enter($__internal_a53c1770bba716544f20e83fbbed9e04a37b91566823f062b7df796d51beb937_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_f1c6cdd3051d363e155f19e492df18ffa8253ed900bf82e33a34adf89014ed20 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f1c6cdd3051d363e155f19e492df18ffa8253ed900bf82e33a34adf89014ed20->enter($__internal_f1c6cdd3051d363e155f19e492df18ffa8253ed900bf82e33a34adf89014ed20_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_f1c6cdd3051d363e155f19e492df18ffa8253ed900bf82e33a34adf89014ed20->leave($__internal_f1c6cdd3051d363e155f19e492df18ffa8253ed900bf82e33a34adf89014ed20_prof);

        
        $__internal_a53c1770bba716544f20e83fbbed9e04a37b91566823f062b7df796d51beb937->leave($__internal_a53c1770bba716544f20e83fbbed9e04a37b91566823f062b7df796d51beb937_prof);

    }

    // line 10
    public function block_head($context, array $blocks = array())
    {
        $__internal_30c667ea109ebe50167ee0da8731e48e99d2b0ffcdc5bda84a49ec2d14aa0b0f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_30c667ea109ebe50167ee0da8731e48e99d2b0ffcdc5bda84a49ec2d14aa0b0f->enter($__internal_30c667ea109ebe50167ee0da8731e48e99d2b0ffcdc5bda84a49ec2d14aa0b0f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_1f4e5a1623c0d1be13d622450defa29aca7984f1a5bbe263bc03c4e13a978001 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1f4e5a1623c0d1be13d622450defa29aca7984f1a5bbe263bc03c4e13a978001->enter($__internal_1f4e5a1623c0d1be13d622450defa29aca7984f1a5bbe263bc03c4e13a978001_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        
        $__internal_1f4e5a1623c0d1be13d622450defa29aca7984f1a5bbe263bc03c4e13a978001->leave($__internal_1f4e5a1623c0d1be13d622450defa29aca7984f1a5bbe263bc03c4e13a978001_prof);

        
        $__internal_30c667ea109ebe50167ee0da8731e48e99d2b0ffcdc5bda84a49ec2d14aa0b0f->leave($__internal_30c667ea109ebe50167ee0da8731e48e99d2b0ffcdc5bda84a49ec2d14aa0b0f_prof);

    }

    // line 33
    public function block_body($context, array $blocks = array())
    {
        $__internal_40ac322b5eabc210e24c45a5a55b5ca1788b02acc97c0f114bdc3c791fa16514 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_40ac322b5eabc210e24c45a5a55b5ca1788b02acc97c0f114bdc3c791fa16514->enter($__internal_40ac322b5eabc210e24c45a5a55b5ca1788b02acc97c0f114bdc3c791fa16514_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_bd61048d11f16a2494760b5825a2e93ae344a51db7014b8d379332806c7bf13c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bd61048d11f16a2494760b5825a2e93ae344a51db7014b8d379332806c7bf13c->enter($__internal_bd61048d11f16a2494760b5825a2e93ae344a51db7014b8d379332806c7bf13c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_bd61048d11f16a2494760b5825a2e93ae344a51db7014b8d379332806c7bf13c->leave($__internal_bd61048d11f16a2494760b5825a2e93ae344a51db7014b8d379332806c7bf13c_prof);

        
        $__internal_40ac322b5eabc210e24c45a5a55b5ca1788b02acc97c0f114bdc3c791fa16514->leave($__internal_40ac322b5eabc210e24c45a5a55b5ca1788b02acc97c0f114bdc3c791fa16514_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  137 => 33,  120 => 10,  103 => 7,  88 => 34,  86 => 33,  76 => 26,  66 => 19,  59 => 15,  53 => 11,  51 => 10,  47 => 9,  43 => 8,  39 => 7,  33 => 4,  28 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"{{ _charset }}\" />
        <meta name=\"robots\" content=\"noindex,nofollow\" />
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\" />
        <title>{% block title %}{% endblock %}</title>
        <link rel=\"icon\" type=\"image/png\" href=\"{{ include('@Twig/images/favicon.png.base64') }}\">
        <style>{{ include('@Twig/exception.css.twig') }}</style>
        {% block head %}{% endblock %}
    </head>
    <body>
        <header>
            <div class=\"container\">
                <h1 class=\"logo\">{{ include('@Twig/images/symfony-logo.svg') }} Symfony Exception</h1>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/doc\">
                        <span class=\"icon\">{{ include('@Twig/images/icon-book.svg') }}</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Docs
                    </a>
                </div>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/support\">
                        <span class=\"icon\">{{ include('@Twig/images/icon-support.svg') }}</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Support
                    </a>
                </div>
            </div>
        </header>

        {% block body %}{% endblock %}
        {{ include('@Twig/base_js.html.twig') }}
    </body>
</html>
", "TwigBundle::layout.html.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/layout.html.twig");
    }
}
