<?php

/* @Framework/Form/email_widget.html.php */
class __TwigTemplate_22f37305833ba85313cfc5d0a52f86ba81b3cc307093b27288d3353ca226cee1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1b6a2a4b8a05308b388f318c9c0a20e7b83dfee5a71629d6a17a4029122fe9a9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1b6a2a4b8a05308b388f318c9c0a20e7b83dfee5a71629d6a17a4029122fe9a9->enter($__internal_1b6a2a4b8a05308b388f318c9c0a20e7b83dfee5a71629d6a17a4029122fe9a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        $__internal_f73628b4482a5aed1749dc3d4912176eaa088aa394a4bc999e7a5655f9505f53 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f73628b4482a5aed1749dc3d4912176eaa088aa394a4bc999e7a5655f9505f53->enter($__internal_f73628b4482a5aed1749dc3d4912176eaa088aa394a4bc999e7a5655f9505f53_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
";
        
        $__internal_1b6a2a4b8a05308b388f318c9c0a20e7b83dfee5a71629d6a17a4029122fe9a9->leave($__internal_1b6a2a4b8a05308b388f318c9c0a20e7b83dfee5a71629d6a17a4029122fe9a9_prof);

        
        $__internal_f73628b4482a5aed1749dc3d4912176eaa088aa394a4bc999e7a5655f9505f53->leave($__internal_f73628b4482a5aed1749dc3d4912176eaa088aa394a4bc999e7a5655f9505f53_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/email_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
", "@Framework/Form/email_widget.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\email_widget.html.php");
    }
}
