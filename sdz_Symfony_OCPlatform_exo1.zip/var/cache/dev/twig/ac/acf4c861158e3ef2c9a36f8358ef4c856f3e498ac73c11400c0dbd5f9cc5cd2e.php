<?php

/* @Framework/Form/form_errors.html.php */
class __TwigTemplate_1ad4df83b1b81e4a09a6b9c697a8055a9a1e8d1b33ad011f3cd755b5d6c8d9dd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9fea1504a438966634ac9f13e5ee74aed3a2d451d76271b10849d8bbeb816718 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9fea1504a438966634ac9f13e5ee74aed3a2d451d76271b10849d8bbeb816718->enter($__internal_9fea1504a438966634ac9f13e5ee74aed3a2d451d76271b10849d8bbeb816718_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        $__internal_fb6a8940be293a5191f8aedc3beb7bc03b83ebe6b8bfd9fafd029fc55dbaaf06 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fb6a8940be293a5191f8aedc3beb7bc03b83ebe6b8bfd9fafd029fc55dbaaf06->enter($__internal_fb6a8940be293a5191f8aedc3beb7bc03b83ebe6b8bfd9fafd029fc55dbaaf06_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        // line 1
        echo "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
        
        $__internal_9fea1504a438966634ac9f13e5ee74aed3a2d451d76271b10849d8bbeb816718->leave($__internal_9fea1504a438966634ac9f13e5ee74aed3a2d451d76271b10849d8bbeb816718_prof);

        
        $__internal_fb6a8940be293a5191f8aedc3beb7bc03b83ebe6b8bfd9fafd029fc55dbaaf06->leave($__internal_fb6a8940be293a5191f8aedc3beb7bc03b83ebe6b8bfd9fafd029fc55dbaaf06_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_errors.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
", "@Framework/Form/form_errors.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_errors.html.php");
    }
}
