<?php

/* @Framework/Form/form_row.html.php */
class __TwigTemplate_42cc5f9f6d15fc09abd433a1103ef0364872510932ec120e94cb4c6549e82860 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_34e1d78da12f13fd488e50d06d4bfe261a3e3a20bbd6660906e0835e6bbab4b2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_34e1d78da12f13fd488e50d06d4bfe261a3e3a20bbd6660906e0835e6bbab4b2->enter($__internal_34e1d78da12f13fd488e50d06d4bfe261a3e3a20bbd6660906e0835e6bbab4b2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        $__internal_044c41c9c22deb115b6b5bc7c044e386295820965b271671d6123bd235692e28 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_044c41c9c22deb115b6b5bc7c044e386295820965b271671d6123bd235692e28->enter($__internal_044c41c9c22deb115b6b5bc7c044e386295820965b271671d6123bd235692e28_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_34e1d78da12f13fd488e50d06d4bfe261a3e3a20bbd6660906e0835e6bbab4b2->leave($__internal_34e1d78da12f13fd488e50d06d4bfe261a3e3a20bbd6660906e0835e6bbab4b2_prof);

        
        $__internal_044c41c9c22deb115b6b5bc7c044e386295820965b271671d6123bd235692e28->leave($__internal_044c41c9c22deb115b6b5bc7c044e386295820965b271671d6123bd235692e28_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/form_row.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_row.html.php");
    }
}
