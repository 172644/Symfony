<?php

/* TwigBundle:Exception:exception.js.twig */
class __TwigTemplate_3f5a915ca2631f5eedcea60749aebbcdfc45e25a16c5f5456daa9d87e4f14692 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cea13053e31f4177e2675117ff9bfc0e866d4c38e64f627b2bd23bc32c1a41ff = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cea13053e31f4177e2675117ff9bfc0e866d4c38e64f627b2bd23bc32c1a41ff->enter($__internal_cea13053e31f4177e2675117ff9bfc0e866d4c38e64f627b2bd23bc32c1a41ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        $__internal_4c19e85f344e1295e788edd196016d09daca69729fcaec22d1c939957e79a117 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4c19e85f344e1295e788edd196016d09daca69729fcaec22d1c939957e79a117->enter($__internal_4c19e85f344e1295e788edd196016d09daca69729fcaec22d1c939957e79a117_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_include($this->env, $context, "@Twig/Exception/exception.txt.twig", array("exception" => (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 2, $this->getSourceContext()); })())));
        echo "
*/
";
        
        $__internal_cea13053e31f4177e2675117ff9bfc0e866d4c38e64f627b2bd23bc32c1a41ff->leave($__internal_cea13053e31f4177e2675117ff9bfc0e866d4c38e64f627b2bd23bc32c1a41ff_prof);

        
        $__internal_4c19e85f344e1295e788edd196016d09daca69729fcaec22d1c939957e79a117->leave($__internal_4c19e85f344e1295e788edd196016d09daca69729fcaec22d1c939957e79a117_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ include('@Twig/Exception/exception.txt.twig', { exception: exception }) }}
*/
", "TwigBundle:Exception:exception.js.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.js.twig");
    }
}
