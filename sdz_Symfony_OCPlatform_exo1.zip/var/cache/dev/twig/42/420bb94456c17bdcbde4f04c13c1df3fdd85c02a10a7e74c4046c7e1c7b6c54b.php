<?php

/* OCPlatformBundle:Advert:view.html.twig */
class __TwigTemplate_83f1321b884cfdef285dd9c00ceaa0a5c81b06e508c5e020cdac7cdb7857dc98 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("OCPlatformBundle::layout.html.twig", "OCPlatformBundle:Advert:view.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'ocplatform_body' => array($this, 'block_ocplatform_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "OCPlatformBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_044bc4ef1702ce9d791b1a12e498b70e14bd48fd30a34609364832cdadd4ae73 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_044bc4ef1702ce9d791b1a12e498b70e14bd48fd30a34609364832cdadd4ae73->enter($__internal_044bc4ef1702ce9d791b1a12e498b70e14bd48fd30a34609364832cdadd4ae73_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:view.html.twig"));

        $__internal_d9e6b9716094b6b1ef3ea1eda97380ee732123552c4db922b054243155fbb39e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d9e6b9716094b6b1ef3ea1eda97380ee732123552c4db922b054243155fbb39e->enter($__internal_d9e6b9716094b6b1ef3ea1eda97380ee732123552c4db922b054243155fbb39e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:view.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_044bc4ef1702ce9d791b1a12e498b70e14bd48fd30a34609364832cdadd4ae73->leave($__internal_044bc4ef1702ce9d791b1a12e498b70e14bd48fd30a34609364832cdadd4ae73_prof);

        
        $__internal_d9e6b9716094b6b1ef3ea1eda97380ee732123552c4db922b054243155fbb39e->leave($__internal_d9e6b9716094b6b1ef3ea1eda97380ee732123552c4db922b054243155fbb39e_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_d34b3494be86d061a13fa4520f199fd308c35a724737194e41ac2077f82b0f52 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d34b3494be86d061a13fa4520f199fd308c35a724737194e41ac2077f82b0f52->enter($__internal_d34b3494be86d061a13fa4520f199fd308c35a724737194e41ac2077f82b0f52_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_d1ae385eb3ad1065c5b58a361c0f0bd675b8867ad739662dfbfc90acbc1a0971 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d1ae385eb3ad1065c5b58a361c0f0bd675b8867ad739662dfbfc90acbc1a0971->enter($__internal_d1ae385eb3ad1065c5b58a361c0f0bd675b8867ad739662dfbfc90acbc1a0971_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "    Lecture d'une annonce - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
        
        $__internal_d1ae385eb3ad1065c5b58a361c0f0bd675b8867ad739662dfbfc90acbc1a0971->leave($__internal_d1ae385eb3ad1065c5b58a361c0f0bd675b8867ad739662dfbfc90acbc1a0971_prof);

        
        $__internal_d34b3494be86d061a13fa4520f199fd308c35a724737194e41ac2077f82b0f52->leave($__internal_d34b3494be86d061a13fa4520f199fd308c35a724737194e41ac2077f82b0f52_prof);

    }

    // line 7
    public function block_ocplatform_body($context, array $blocks = array())
    {
        $__internal_91ccd2f8cc5447bceb2ae85132898c1808b32210181f2c3e475940c8e397ae63 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_91ccd2f8cc5447bceb2ae85132898c1808b32210181f2c3e475940c8e397ae63->enter($__internal_91ccd2f8cc5447bceb2ae85132898c1808b32210181f2c3e475940c8e397ae63_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        $__internal_090a1bf446e04ae4a77a6edc3c8fc439092ed177f988a268d8370d5bae556253 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_090a1bf446e04ae4a77a6edc3c8fc439092ed177f988a268d8370d5bae556253->enter($__internal_090a1bf446e04ae4a77a6edc3c8fc439092ed177f988a268d8370d5bae556253_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        // line 8
        echo "
    <h2>";
        // line 9
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["advert"]) || array_key_exists("advert", $context) ? $context["advert"] : (function () { throw new Twig_Error_Runtime('Variable "advert" does not exist.', 9, $this->getSourceContext()); })()), "title", array()), "html", null, true);
        echo "</h2>
    <i>Par ";
        // line 10
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["advert"]) || array_key_exists("advert", $context) ? $context["advert"] : (function () { throw new Twig_Error_Runtime('Variable "advert" does not exist.', 10, $this->getSourceContext()); })()), "author", array()), "html", null, true);
        echo ", le ";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["advert"]) || array_key_exists("advert", $context) ? $context["advert"] : (function () { throw new Twig_Error_Runtime('Variable "advert" does not exist.', 10, $this->getSourceContext()); })()), "date", array()), "d/m/Y"), "html", null, true);
        echo "</i>

    <div class=\"well\">
        ";
        // line 13
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["advert"]) || array_key_exists("advert", $context) ? $context["advert"] : (function () { throw new Twig_Error_Runtime('Variable "advert" does not exist.', 13, $this->getSourceContext()); })()), "content", array()), "html", null, true);
        echo "
    </div>

    <p>
        <a href=\"";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("oc_platform_home");
        echo "\" class=\"btn btn-default\">
            <i class=\"glyphicon glyphicon-chevron-left\"></i>
            Retour à la liste
        </a>
        <a href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("oc_platform_edit", array("id" => twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["advert"]) || array_key_exists("advert", $context) ? $context["advert"] : (function () { throw new Twig_Error_Runtime('Variable "advert" does not exist.', 21, $this->getSourceContext()); })()), "id", array()))), "html", null, true);
        echo "\" class=\"btn btn-default\">
            <i class=\"glyphicon glyphicon-edit\"></i>
            Modifier l'annonce
        </a>
        <a href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("oc_platform_delete", array("id" => twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["advert"]) || array_key_exists("advert", $context) ? $context["advert"] : (function () { throw new Twig_Error_Runtime('Variable "advert" does not exist.', 25, $this->getSourceContext()); })()), "id", array()))), "html", null, true);
        echo "\" class=\"btn btn-danger\">
            <i class=\"glyphicon glyphicon-trash\"></i>
            Supprimer l'annonce
        </a>
    </p>

";
        
        $__internal_090a1bf446e04ae4a77a6edc3c8fc439092ed177f988a268d8370d5bae556253->leave($__internal_090a1bf446e04ae4a77a6edc3c8fc439092ed177f988a268d8370d5bae556253_prof);

        
        $__internal_91ccd2f8cc5447bceb2ae85132898c1808b32210181f2c3e475940c8e397ae63->leave($__internal_91ccd2f8cc5447bceb2ae85132898c1808b32210181f2c3e475940c8e397ae63_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Advert:view.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  108 => 25,  101 => 21,  94 => 17,  87 => 13,  79 => 10,  75 => 9,  72 => 8,  63 => 7,  50 => 4,  41 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"OCPlatformBundle::layout.html.twig\" %}

{% block title %}
    Lecture d'une annonce - {{ parent() }}
{% endblock %}

{% block ocplatform_body %}

    <h2>{{ advert.title }}</h2>
    <i>Par {{ advert.author }}, le {{ advert.date|date('d/m/Y') }}</i>

    <div class=\"well\">
        {{ advert.content }}
    </div>

    <p>
        <a href=\"{{ path('oc_platform_home') }}\" class=\"btn btn-default\">
            <i class=\"glyphicon glyphicon-chevron-left\"></i>
            Retour à la liste
        </a>
        <a href=\"{{ path('oc_platform_edit', {'id': advert.id}) }}\" class=\"btn btn-default\">
            <i class=\"glyphicon glyphicon-edit\"></i>
            Modifier l'annonce
        </a>
        <a href=\"{{ path('oc_platform_delete', {'id': advert.id}) }}\" class=\"btn btn-danger\">
            <i class=\"glyphicon glyphicon-trash\"></i>
            Supprimer l'annonce
        </a>
    </p>

{% endblock %}", "OCPlatformBundle:Advert:view.html.twig", "C:\\wamp64\\www\\Symfony\\src\\OC\\PlatformBundle/Resources/views/Advert/view.html.twig");
    }
}
