<?php

/* @Framework/Form/collection_widget.html.php */
class __TwigTemplate_7997d4ca92256366e30876f280e63abc69f4f2d89d60455515d8332072348774 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9acb46f6957f6423218764cb908810bccc888a9a514e7e09fa2e7e63c90cf5b4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9acb46f6957f6423218764cb908810bccc888a9a514e7e09fa2e7e63c90cf5b4->enter($__internal_9acb46f6957f6423218764cb908810bccc888a9a514e7e09fa2e7e63c90cf5b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        $__internal_5a797338f2c36a643cb1788118ac5e2930b8050c684c47df0f58045fd5c5a0b4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5a797338f2c36a643cb1788118ac5e2930b8050c684c47df0f58045fd5c5a0b4->enter($__internal_5a797338f2c36a643cb1788118ac5e2930b8050c684c47df0f58045fd5c5a0b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        // line 1
        echo "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
        
        $__internal_9acb46f6957f6423218764cb908810bccc888a9a514e7e09fa2e7e63c90cf5b4->leave($__internal_9acb46f6957f6423218764cb908810bccc888a9a514e7e09fa2e7e63c90cf5b4_prof);

        
        $__internal_5a797338f2c36a643cb1788118ac5e2930b8050c684c47df0f58045fd5c5a0b4->leave($__internal_5a797338f2c36a643cb1788118ac5e2930b8050c684c47df0f58045fd5c5a0b4_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/collection_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
", "@Framework/Form/collection_widget.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\collection_widget.html.php");
    }
}
