<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_2629511d3060e8dd6b3f829000674919462068b999df3443ec6dcd0d7721537b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_78ed62896d8fed5d0c3dce2fbfe92e42e504a593ba1cd4332ade0d3d31843403 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_78ed62896d8fed5d0c3dce2fbfe92e42e504a593ba1cd4332ade0d3d31843403->enter($__internal_78ed62896d8fed5d0c3dce2fbfe92e42e504a593ba1cd4332ade0d3d31843403_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        $__internal_07f9b920d69f0da5bb4831f461d03a4accb24fd22bf83e3015b6038d3add9233 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_07f9b920d69f0da5bb4831f461d03a4accb24fd22bf83e3015b6038d3add9233->enter($__internal_07f9b920d69f0da5bb4831f461d03a4accb24fd22bf83e3015b6038d3add9233_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_78ed62896d8fed5d0c3dce2fbfe92e42e504a593ba1cd4332ade0d3d31843403->leave($__internal_78ed62896d8fed5d0c3dce2fbfe92e42e504a593ba1cd4332ade0d3d31843403_prof);

        
        $__internal_07f9b920d69f0da5bb4831f461d03a4accb24fd22bf83e3015b6038d3add9233->leave($__internal_07f9b920d69f0da5bb4831f461d03a4accb24fd22bf83e3015b6038d3add9233_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->widget(\$form) ?>
", "@Framework/Form/hidden_row.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\hidden_row.html.php");
    }
}
