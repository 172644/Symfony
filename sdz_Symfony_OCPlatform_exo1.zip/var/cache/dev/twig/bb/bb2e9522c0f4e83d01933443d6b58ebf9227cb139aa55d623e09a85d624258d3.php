<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_ed00ef130b138bbed0536dbf9de0eef92fc5488da921fbd36cc334b0e6105776 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c6e948c40c03cb7bd2bc1e3808296f0d8b4a55b7ca92b178e0a23024382cef98 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c6e948c40c03cb7bd2bc1e3808296f0d8b4a55b7ca92b178e0a23024382cef98->enter($__internal_c6e948c40c03cb7bd2bc1e3808296f0d8b4a55b7ca92b178e0a23024382cef98_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        $__internal_a5fc119cb999bb62ce3b128a14c745af52cf243c00fe0d604334580947df14ce = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a5fc119cb999bb62ce3b128a14c745af52cf243c00fe0d604334580947df14ce->enter($__internal_a5fc119cb999bb62ce3b128a14c745af52cf243c00fe0d604334580947df14ce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_c6e948c40c03cb7bd2bc1e3808296f0d8b4a55b7ca92b178e0a23024382cef98->leave($__internal_c6e948c40c03cb7bd2bc1e3808296f0d8b4a55b7ca92b178e0a23024382cef98_prof);

        
        $__internal_a5fc119cb999bb62ce3b128a14c745af52cf243c00fe0d604334580947df14ce->leave($__internal_a5fc119cb999bb62ce3b128a14c745af52cf243c00fe0d604334580947df14ce_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
", "@Framework/Form/radio_widget.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\radio_widget.html.php");
    }
}
