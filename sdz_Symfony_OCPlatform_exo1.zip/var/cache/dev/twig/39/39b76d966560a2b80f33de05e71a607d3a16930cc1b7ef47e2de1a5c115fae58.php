<?php

/* @Framework/Form/form_end.html.php */
class __TwigTemplate_abdd496a8042e8f1a8c97f4cffbbb32cf4b75ee9186d4257350e72e684ce11af extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_aa7d7a67556407e21d9e79ed2dae5104649ac63309c9718b2f44c9a510a4945b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_aa7d7a67556407e21d9e79ed2dae5104649ac63309c9718b2f44c9a510a4945b->enter($__internal_aa7d7a67556407e21d9e79ed2dae5104649ac63309c9718b2f44c9a510a4945b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        $__internal_60cf2351c4f09e1e70b4df584b37ae462d6ea88000ebf40e12c637adf95ec890 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_60cf2351c4f09e1e70b4df584b37ae462d6ea88000ebf40e12c637adf95ec890->enter($__internal_60cf2351c4f09e1e70b4df584b37ae462d6ea88000ebf40e12c637adf95ec890_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        // line 1
        echo "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
        
        $__internal_aa7d7a67556407e21d9e79ed2dae5104649ac63309c9718b2f44c9a510a4945b->leave($__internal_aa7d7a67556407e21d9e79ed2dae5104649ac63309c9718b2f44c9a510a4945b_prof);

        
        $__internal_60cf2351c4f09e1e70b4df584b37ae462d6ea88000ebf40e12c637adf95ec890->leave($__internal_60cf2351c4f09e1e70b4df584b37ae462d6ea88000ebf40e12c637adf95ec890_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_end.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
", "@Framework/Form/form_end.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_end.html.php");
    }
}
