<?php

/* @Framework/Form/choice_widget_expanded.html.php */
class __TwigTemplate_23a7fe46bc823dedb2d64da45f92751e46521f7eb05a6495410d69c136edf58d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c06a31d56998b2bc8e7bcb2e29467c64a0579b4c24405674eb8800c5c86e3b99 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c06a31d56998b2bc8e7bcb2e29467c64a0579b4c24405674eb8800c5c86e3b99->enter($__internal_c06a31d56998b2bc8e7bcb2e29467c64a0579b4c24405674eb8800c5c86e3b99_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        $__internal_cacd87ec035003b05ca371255c6e077de1c787318f0401efbf4c580db4642904 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cacd87ec035003b05ca371255c6e077de1c787318f0401efbf4c580db4642904->enter($__internal_cacd87ec035003b05ca371255c6e077de1c787318f0401efbf4c580db4642904_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
";
        
        $__internal_c06a31d56998b2bc8e7bcb2e29467c64a0579b4c24405674eb8800c5c86e3b99->leave($__internal_c06a31d56998b2bc8e7bcb2e29467c64a0579b4c24405674eb8800c5c86e3b99_prof);

        
        $__internal_cacd87ec035003b05ca371255c6e077de1c787318f0401efbf4c580db4642904->leave($__internal_cacd87ec035003b05ca371255c6e077de1c787318f0401efbf4c580db4642904_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget_expanded.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
", "@Framework/Form/choice_widget_expanded.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\choice_widget_expanded.html.php");
    }
}
