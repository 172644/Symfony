<?php

/* OCPlatformBundle::layout.html.twig */
class __TwigTemplate_ec2b376a2f555bec5421f91f12fd79202d0cf508bc56fe43ef1e507750144da5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::layout.html.twig", "OCPlatformBundle::layout.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'ocplatform_body' => array($this, 'block_ocplatform_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3eb609b37f87800f40824457f4d9d27ecd2c3a10d474a4439b9566512064d316 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3eb609b37f87800f40824457f4d9d27ecd2c3a10d474a4439b9566512064d316->enter($__internal_3eb609b37f87800f40824457f4d9d27ecd2c3a10d474a4439b9566512064d316_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle::layout.html.twig"));

        $__internal_c49d036e91dd0987adb670d90f30cfc1afb08727411878b3abdd6599595af417 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c49d036e91dd0987adb670d90f30cfc1afb08727411878b3abdd6599595af417->enter($__internal_c49d036e91dd0987adb670d90f30cfc1afb08727411878b3abdd6599595af417_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle::layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3eb609b37f87800f40824457f4d9d27ecd2c3a10d474a4439b9566512064d316->leave($__internal_3eb609b37f87800f40824457f4d9d27ecd2c3a10d474a4439b9566512064d316_prof);

        
        $__internal_c49d036e91dd0987adb670d90f30cfc1afb08727411878b3abdd6599595af417->leave($__internal_c49d036e91dd0987adb670d90f30cfc1afb08727411878b3abdd6599595af417_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_c6817518e14d5e3d5e91a7a216179f86264515aad8f0739765ccd2dadfce1a43 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c6817518e14d5e3d5e91a7a216179f86264515aad8f0739765ccd2dadfce1a43->enter($__internal_c6817518e14d5e3d5e91a7a216179f86264515aad8f0739765ccd2dadfce1a43_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_08c203b07a84e7df983f727a40b94c01ab875c5851aba8a71a3897fdde2abfc2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_08c203b07a84e7df983f727a40b94c01ab875c5851aba8a71a3897fdde2abfc2->enter($__internal_08c203b07a84e7df983f727a40b94c01ab875c5851aba8a71a3897fdde2abfc2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "    Annonces - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
        
        $__internal_08c203b07a84e7df983f727a40b94c01ab875c5851aba8a71a3897fdde2abfc2->leave($__internal_08c203b07a84e7df983f727a40b94c01ab875c5851aba8a71a3897fdde2abfc2_prof);

        
        $__internal_c6817518e14d5e3d5e91a7a216179f86264515aad8f0739765ccd2dadfce1a43->leave($__internal_c6817518e14d5e3d5e91a7a216179f86264515aad8f0739765ccd2dadfce1a43_prof);

    }

    // line 7
    public function block_body($context, array $blocks = array())
    {
        $__internal_cb8b5277d3673d28f332250a266f1d23375a3ec1143f9a1f6c61cd60962fc112 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cb8b5277d3673d28f332250a266f1d23375a3ec1143f9a1f6c61cd60962fc112->enter($__internal_cb8b5277d3673d28f332250a266f1d23375a3ec1143f9a1f6c61cd60962fc112_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_60ebd77bcbba09d5bf097f1851bbb34f3852a0bc9ab72fd6a3d97e21fbfb25d8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_60ebd77bcbba09d5bf097f1851bbb34f3852a0bc9ab72fd6a3d97e21fbfb25d8->enter($__internal_60ebd77bcbba09d5bf097f1851bbb34f3852a0bc9ab72fd6a3d97e21fbfb25d8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 8
        echo "
    ";
        // line 10
        echo "    <h1>Annonces</h1>

    <hr>

    ";
        // line 15
        echo "    ";
        $this->displayBlock('ocplatform_body', $context, $blocks);
        // line 17
        echo "
";
        
        $__internal_60ebd77bcbba09d5bf097f1851bbb34f3852a0bc9ab72fd6a3d97e21fbfb25d8->leave($__internal_60ebd77bcbba09d5bf097f1851bbb34f3852a0bc9ab72fd6a3d97e21fbfb25d8_prof);

        
        $__internal_cb8b5277d3673d28f332250a266f1d23375a3ec1143f9a1f6c61cd60962fc112->leave($__internal_cb8b5277d3673d28f332250a266f1d23375a3ec1143f9a1f6c61cd60962fc112_prof);

    }

    // line 15
    public function block_ocplatform_body($context, array $blocks = array())
    {
        $__internal_e9e6556d2b60143157cc128bb0df333da00abe74727117b68f65636e756d25e1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e9e6556d2b60143157cc128bb0df333da00abe74727117b68f65636e756d25e1->enter($__internal_e9e6556d2b60143157cc128bb0df333da00abe74727117b68f65636e756d25e1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        $__internal_7680596af57b29d513ba9ea433600f8f6b1bc4f73e56a4493c91cedf9fa74233 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7680596af57b29d513ba9ea433600f8f6b1bc4f73e56a4493c91cedf9fa74233->enter($__internal_7680596af57b29d513ba9ea433600f8f6b1bc4f73e56a4493c91cedf9fa74233_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        // line 16
        echo "    ";
        
        $__internal_7680596af57b29d513ba9ea433600f8f6b1bc4f73e56a4493c91cedf9fa74233->leave($__internal_7680596af57b29d513ba9ea433600f8f6b1bc4f73e56a4493c91cedf9fa74233_prof);

        
        $__internal_e9e6556d2b60143157cc128bb0df333da00abe74727117b68f65636e756d25e1->leave($__internal_e9e6556d2b60143157cc128bb0df333da00abe74727117b68f65636e756d25e1_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  105 => 16,  96 => 15,  85 => 17,  82 => 15,  76 => 10,  73 => 8,  64 => 7,  51 => 4,  42 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"::layout.html.twig\" %}

{% block title %}
    Annonces - {{ parent() }}
{% endblock %}

{% block body %}

    {# On définit un sous-titre commun à toutes les pages du bundle, par exemple #}
    <h1>Annonces</h1>

    <hr>

    {# On définit un nouveau bloc, que les vues du bundle pourront remplir #}
    {% block ocplatform_body %}
    {% endblock %}

{% endblock %}", "OCPlatformBundle::layout.html.twig", "C:\\wamp64\\www\\Symfony\\src\\OC\\PlatformBundle/Resources/views/layout.html.twig");
    }
}
