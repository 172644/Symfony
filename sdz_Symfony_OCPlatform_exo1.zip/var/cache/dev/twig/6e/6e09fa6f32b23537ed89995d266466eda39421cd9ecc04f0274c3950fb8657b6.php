<?php

/* @Framework/Form/widget_attributes.html.php */
class __TwigTemplate_82e0698bc0156bb49b49ef7a25c9c415b50addc28a52af970c57c1a15e855c29 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1336380b3b76055def64cfa7ee16c7ba9e1651fdf4ec61ceddf54438c40f688b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1336380b3b76055def64cfa7ee16c7ba9e1651fdf4ec61ceddf54438c40f688b->enter($__internal_1336380b3b76055def64cfa7ee16c7ba9e1651fdf4ec61ceddf54438c40f688b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_attributes.html.php"));

        $__internal_716485b9123490ae042b7928c2798bd08817ae87a3dcdc1f32d51de9b38a0cea = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_716485b9123490ae042b7928c2798bd08817ae87a3dcdc1f32d51de9b38a0cea->enter($__internal_716485b9123490ae042b7928c2798bd08817ae87a3dcdc1f32d51de9b38a0cea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_attributes.html.php"));

        // line 1
        echo "id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"<?php if (\$disabled): ?> disabled=\"disabled\"<?php endif ?>
<?php if (\$required): ?> required=\"required\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
";
        
        $__internal_1336380b3b76055def64cfa7ee16c7ba9e1651fdf4ec61ceddf54438c40f688b->leave($__internal_1336380b3b76055def64cfa7ee16c7ba9e1651fdf4ec61ceddf54438c40f688b_prof);

        
        $__internal_716485b9123490ae042b7928c2798bd08817ae87a3dcdc1f32d51de9b38a0cea->leave($__internal_716485b9123490ae042b7928c2798bd08817ae87a3dcdc1f32d51de9b38a0cea_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/widget_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"<?php if (\$disabled): ?> disabled=\"disabled\"<?php endif ?>
<?php if (\$required): ?> required=\"required\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
", "@Framework/Form/widget_attributes.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\widget_attributes.html.php");
    }
}
