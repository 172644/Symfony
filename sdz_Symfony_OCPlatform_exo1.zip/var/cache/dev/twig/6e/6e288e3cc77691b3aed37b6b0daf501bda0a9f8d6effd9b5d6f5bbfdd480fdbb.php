<?php

/* OCPlatformBundle::layout.html.twig */
class __TwigTemplate_65c35e7ca7b1c3db0b8e9fd7ac2a167209938cb3df68fa4e5681c32f62cb695f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("OCCoreBundle::layout.html.twig", "OCPlatformBundle::layout.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'ocplatform_body' => array($this, 'block_ocplatform_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "OCCoreBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_88620e12d798af65083567616468ecd171ebad19eaf4bc5f63108878ea0a9ded = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_88620e12d798af65083567616468ecd171ebad19eaf4bc5f63108878ea0a9ded->enter($__internal_88620e12d798af65083567616468ecd171ebad19eaf4bc5f63108878ea0a9ded_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle::layout.html.twig"));

        $__internal_17dcf44cfe6f53510ee364599e52bf14a4abbe943f7646e6fafda0c1a914dbf2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_17dcf44cfe6f53510ee364599e52bf14a4abbe943f7646e6fafda0c1a914dbf2->enter($__internal_17dcf44cfe6f53510ee364599e52bf14a4abbe943f7646e6fafda0c1a914dbf2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle::layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_88620e12d798af65083567616468ecd171ebad19eaf4bc5f63108878ea0a9ded->leave($__internal_88620e12d798af65083567616468ecd171ebad19eaf4bc5f63108878ea0a9ded_prof);

        
        $__internal_17dcf44cfe6f53510ee364599e52bf14a4abbe943f7646e6fafda0c1a914dbf2->leave($__internal_17dcf44cfe6f53510ee364599e52bf14a4abbe943f7646e6fafda0c1a914dbf2_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_b19e02ae53671a3946f7b23f3abee0c3f4eb32bf8c5e051f58169a4110b03982 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b19e02ae53671a3946f7b23f3abee0c3f4eb32bf8c5e051f58169a4110b03982->enter($__internal_b19e02ae53671a3946f7b23f3abee0c3f4eb32bf8c5e051f58169a4110b03982_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_6751c48b902551580e2104cdb400f7bf87aa282cf7321ce83308de2c65b2a088 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6751c48b902551580e2104cdb400f7bf87aa282cf7321ce83308de2c65b2a088->enter($__internal_6751c48b902551580e2104cdb400f7bf87aa282cf7321ce83308de2c65b2a088_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "    Annonces - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
        
        $__internal_6751c48b902551580e2104cdb400f7bf87aa282cf7321ce83308de2c65b2a088->leave($__internal_6751c48b902551580e2104cdb400f7bf87aa282cf7321ce83308de2c65b2a088_prof);

        
        $__internal_b19e02ae53671a3946f7b23f3abee0c3f4eb32bf8c5e051f58169a4110b03982->leave($__internal_b19e02ae53671a3946f7b23f3abee0c3f4eb32bf8c5e051f58169a4110b03982_prof);

    }

    // line 7
    public function block_body($context, array $blocks = array())
    {
        $__internal_abe14ff92415f172c3a2bfc36b617166e9c38bc981b20b8413907d2a2449414a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_abe14ff92415f172c3a2bfc36b617166e9c38bc981b20b8413907d2a2449414a->enter($__internal_abe14ff92415f172c3a2bfc36b617166e9c38bc981b20b8413907d2a2449414a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_a9b1b7f3fad4f14b08f8418069f96a4e79924cd038636586f8bd94b335a76e10 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a9b1b7f3fad4f14b08f8418069f96a4e79924cd038636586f8bd94b335a76e10->enter($__internal_a9b1b7f3fad4f14b08f8418069f96a4e79924cd038636586f8bd94b335a76e10_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 8
        echo "
    ";
        // line 10
        echo "    <h1>Annonces</h1>

    <hr>

    ";
        // line 15
        echo "    ";
        $this->displayBlock('ocplatform_body', $context, $blocks);
        // line 17
        echo "
";
        
        $__internal_a9b1b7f3fad4f14b08f8418069f96a4e79924cd038636586f8bd94b335a76e10->leave($__internal_a9b1b7f3fad4f14b08f8418069f96a4e79924cd038636586f8bd94b335a76e10_prof);

        
        $__internal_abe14ff92415f172c3a2bfc36b617166e9c38bc981b20b8413907d2a2449414a->leave($__internal_abe14ff92415f172c3a2bfc36b617166e9c38bc981b20b8413907d2a2449414a_prof);

    }

    // line 15
    public function block_ocplatform_body($context, array $blocks = array())
    {
        $__internal_c7fb620f11c70ad0ce0c0609ffe3931b25af31a28b69d50143c173d1410a26aa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c7fb620f11c70ad0ce0c0609ffe3931b25af31a28b69d50143c173d1410a26aa->enter($__internal_c7fb620f11c70ad0ce0c0609ffe3931b25af31a28b69d50143c173d1410a26aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        $__internal_48247325e093eb8b9a4a43e6f6e9ef96c87d321e54006a3f3e36b66e6048fd1d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_48247325e093eb8b9a4a43e6f6e9ef96c87d321e54006a3f3e36b66e6048fd1d->enter($__internal_48247325e093eb8b9a4a43e6f6e9ef96c87d321e54006a3f3e36b66e6048fd1d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        // line 16
        echo "    ";
        
        $__internal_48247325e093eb8b9a4a43e6f6e9ef96c87d321e54006a3f3e36b66e6048fd1d->leave($__internal_48247325e093eb8b9a4a43e6f6e9ef96c87d321e54006a3f3e36b66e6048fd1d_prof);

        
        $__internal_c7fb620f11c70ad0ce0c0609ffe3931b25af31a28b69d50143c173d1410a26aa->leave($__internal_c7fb620f11c70ad0ce0c0609ffe3931b25af31a28b69d50143c173d1410a26aa_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  105 => 16,  96 => 15,  85 => 17,  82 => 15,  76 => 10,  73 => 8,  64 => 7,  51 => 4,  42 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"OCCoreBundle::layout.html.twig\" %}

{% block title %}
    Annonces - {{ parent() }}
{% endblock %}

{% block body %}

    {# On définit un sous-titre commun à toutes les pages du bundle, par exemple #}
    <h1>Annonces</h1>

    <hr>

    {# On définit un nouveau bloc, que les vues du bundle pourront remplir #}
    {% block ocplatform_body %}
    {% endblock %}

{% endblock %}", "OCPlatformBundle::layout.html.twig", "C:\\wamp64\\www\\Symfony\\src\\OC\\PlatformBundle\\Resources\\views\\layout.html.twig");
    }
}
