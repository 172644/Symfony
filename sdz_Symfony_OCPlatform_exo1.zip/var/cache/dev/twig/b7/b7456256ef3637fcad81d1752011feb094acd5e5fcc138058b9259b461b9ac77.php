<?php

/* TwigBundle:Exception:exception.atom.twig */
class __TwigTemplate_602cba7566b093eaaf7d0c81cde797c180c432c20f6901ecb3ced78c929f5016 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_48f455a897578bb7be4caae1703149e1f47adc554b5197543d272727212cd84a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_48f455a897578bb7be4caae1703149e1f47adc554b5197543d272727212cd84a->enter($__internal_48f455a897578bb7be4caae1703149e1f47adc554b5197543d272727212cd84a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        $__internal_b684b8effff5a90090b5fc38ecc4a62c2870a8b7c97a931c958b22d6e7bc91c3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b684b8effff5a90090b5fc38ecc4a62c2870a8b7c97a931c958b22d6e7bc91c3->enter($__internal_b684b8effff5a90090b5fc38ecc4a62c2870a8b7c97a931c958b22d6e7bc91c3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 1, $this->getSourceContext()); })())));
        echo "
";
        
        $__internal_48f455a897578bb7be4caae1703149e1f47adc554b5197543d272727212cd84a->leave($__internal_48f455a897578bb7be4caae1703149e1f47adc554b5197543d272727212cd84a_prof);

        
        $__internal_b684b8effff5a90090b5fc38ecc4a62c2870a8b7c97a931c958b22d6e7bc91c3->leave($__internal_b684b8effff5a90090b5fc38ecc4a62c2870a8b7c97a931c958b22d6e7bc91c3_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "TwigBundle:Exception:exception.atom.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.atom.twig");
    }
}
