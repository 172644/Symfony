<?php

/* WebProfilerBundle:Collector:router.html.twig */
class __TwigTemplate_4a8a27532cbcc356904eb6937c69f32775a43f8863cfdd64bf8737c1e4505746 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "WebProfilerBundle:Collector:router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_815556c23387d1fdc4eb82351db8900d764381c3d5517c6314673a2e07657451 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_815556c23387d1fdc4eb82351db8900d764381c3d5517c6314673a2e07657451->enter($__internal_815556c23387d1fdc4eb82351db8900d764381c3d5517c6314673a2e07657451_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $__internal_23d5a6078653f0d82f2d1b1774b862d8a0c06d25413de741f616c481e36bb170 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_23d5a6078653f0d82f2d1b1774b862d8a0c06d25413de741f616c481e36bb170->enter($__internal_23d5a6078653f0d82f2d1b1774b862d8a0c06d25413de741f616c481e36bb170_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_815556c23387d1fdc4eb82351db8900d764381c3d5517c6314673a2e07657451->leave($__internal_815556c23387d1fdc4eb82351db8900d764381c3d5517c6314673a2e07657451_prof);

        
        $__internal_23d5a6078653f0d82f2d1b1774b862d8a0c06d25413de741f616c481e36bb170->leave($__internal_23d5a6078653f0d82f2d1b1774b862d8a0c06d25413de741f616c481e36bb170_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_734994b256cb156b2e9a90dc5f4b497f6be7c43c7f48257c7d7e39c8da32b78e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_734994b256cb156b2e9a90dc5f4b497f6be7c43c7f48257c7d7e39c8da32b78e->enter($__internal_734994b256cb156b2e9a90dc5f4b497f6be7c43c7f48257c7d7e39c8da32b78e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_36c0897398ffed4dea05ac673fb770825bc55b474d92fd46d3945ce47d20ff4d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_36c0897398ffed4dea05ac673fb770825bc55b474d92fd46d3945ce47d20ff4d->enter($__internal_36c0897398ffed4dea05ac673fb770825bc55b474d92fd46d3945ce47d20ff4d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_36c0897398ffed4dea05ac673fb770825bc55b474d92fd46d3945ce47d20ff4d->leave($__internal_36c0897398ffed4dea05ac673fb770825bc55b474d92fd46d3945ce47d20ff4d_prof);

        
        $__internal_734994b256cb156b2e9a90dc5f4b497f6be7c43c7f48257c7d7e39c8da32b78e->leave($__internal_734994b256cb156b2e9a90dc5f4b497f6be7c43c7f48257c7d7e39c8da32b78e_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_e7efea04bfb23996ae9962c08bd3a3943e3328b6ec83820f9f2a4ec11bdec3e5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e7efea04bfb23996ae9962c08bd3a3943e3328b6ec83820f9f2a4ec11bdec3e5->enter($__internal_e7efea04bfb23996ae9962c08bd3a3943e3328b6ec83820f9f2a4ec11bdec3e5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_4530ca5afb1c5023cb0d1b0d6e2c5cc63f263b33fe01a4e609ae3ff11f858c80 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4530ca5afb1c5023cb0d1b0d6e2c5cc63f263b33fe01a4e609ae3ff11f858c80->enter($__internal_4530ca5afb1c5023cb0d1b0d6e2c5cc63f263b33fe01a4e609ae3ff11f858c80_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_4530ca5afb1c5023cb0d1b0d6e2c5cc63f263b33fe01a4e609ae3ff11f858c80->leave($__internal_4530ca5afb1c5023cb0d1b0d6e2c5cc63f263b33fe01a4e609ae3ff11f858c80_prof);

        
        $__internal_e7efea04bfb23996ae9962c08bd3a3943e3328b6ec83820f9f2a4ec11bdec3e5->leave($__internal_e7efea04bfb23996ae9962c08bd3a3943e3328b6ec83820f9f2a4ec11bdec3e5_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_5f86eb86f585a8c8ff327567a8506a2223a2ac37f309cc107f77a2b2916df453 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5f86eb86f585a8c8ff327567a8506a2223a2ac37f309cc107f77a2b2916df453->enter($__internal_5f86eb86f585a8c8ff327567a8506a2223a2ac37f309cc107f77a2b2916df453_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_bc9294b89b28f4af5ffbd01f65bf70c715c215eab30b69b58e1f9418093606f4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bc9294b89b28f4af5ffbd01f65bf70c715c215eab30b69b58e1f9418093606f4->enter($__internal_bc9294b89b28f4af5ffbd01f65bf70c715c215eab30b69b58e1f9418093606f4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new Twig_Error_Runtime('Variable "token" does not exist.', 13, $this->getSourceContext()); })()))));
        echo "
";
        
        $__internal_bc9294b89b28f4af5ffbd01f65bf70c715c215eab30b69b58e1f9418093606f4->leave($__internal_bc9294b89b28f4af5ffbd01f65bf70c715c215eab30b69b58e1f9418093606f4_prof);

        
        $__internal_5f86eb86f585a8c8ff327567a8506a2223a2ac37f309cc107f77a2b2916df453->leave($__internal_5f86eb86f585a8c8ff327567a8506a2223a2ac37f309cc107f77a2b2916df453_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Collector:router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "WebProfilerBundle:Collector:router.html.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
