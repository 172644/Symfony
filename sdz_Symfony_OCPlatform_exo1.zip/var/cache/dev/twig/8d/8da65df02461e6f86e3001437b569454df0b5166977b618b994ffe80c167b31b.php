<?php

/* @OCPlatform/Advert/edit.html.twig */
class __TwigTemplate_dd9ab13ab21f756d9753ab8e282e4b7189777a69c2c5f8a56a619e58feb0a663 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("OCPlatformBundle::layout.html.twig", "@OCPlatform/Advert/edit.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'ocplatform_body' => array($this, 'block_ocplatform_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "OCPlatformBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9019ae3e8b541947598033515749787ff4155cdc9546c6f5c4362433283794a2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9019ae3e8b541947598033515749787ff4155cdc9546c6f5c4362433283794a2->enter($__internal_9019ae3e8b541947598033515749787ff4155cdc9546c6f5c4362433283794a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@OCPlatform/Advert/edit.html.twig"));

        $__internal_e0299466795a8ddbdbe167537b676fa65e1eb593bebe915805e253cb215b7543 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e0299466795a8ddbdbe167537b676fa65e1eb593bebe915805e253cb215b7543->enter($__internal_e0299466795a8ddbdbe167537b676fa65e1eb593bebe915805e253cb215b7543_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@OCPlatform/Advert/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9019ae3e8b541947598033515749787ff4155cdc9546c6f5c4362433283794a2->leave($__internal_9019ae3e8b541947598033515749787ff4155cdc9546c6f5c4362433283794a2_prof);

        
        $__internal_e0299466795a8ddbdbe167537b676fa65e1eb593bebe915805e253cb215b7543->leave($__internal_e0299466795a8ddbdbe167537b676fa65e1eb593bebe915805e253cb215b7543_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_130eb15b4514aebd426baa025ac6124e4498ba9219e8bbf527b143c297938668 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_130eb15b4514aebd426baa025ac6124e4498ba9219e8bbf527b143c297938668->enter($__internal_130eb15b4514aebd426baa025ac6124e4498ba9219e8bbf527b143c297938668_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_9054fe40c2f39d920e2114247989cf660b78b425de604d52a3163c146fb59103 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9054fe40c2f39d920e2114247989cf660b78b425de604d52a3163c146fb59103->enter($__internal_9054fe40c2f39d920e2114247989cf660b78b425de604d52a3163c146fb59103_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "    Modifier une annonce - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
        
        $__internal_9054fe40c2f39d920e2114247989cf660b78b425de604d52a3163c146fb59103->leave($__internal_9054fe40c2f39d920e2114247989cf660b78b425de604d52a3163c146fb59103_prof);

        
        $__internal_130eb15b4514aebd426baa025ac6124e4498ba9219e8bbf527b143c297938668->leave($__internal_130eb15b4514aebd426baa025ac6124e4498ba9219e8bbf527b143c297938668_prof);

    }

    // line 7
    public function block_ocplatform_body($context, array $blocks = array())
    {
        $__internal_5351a39ef9a37660bc9e245ea8b1249b8d6007fd10c3736218e8f19650daa4ca = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5351a39ef9a37660bc9e245ea8b1249b8d6007fd10c3736218e8f19650daa4ca->enter($__internal_5351a39ef9a37660bc9e245ea8b1249b8d6007fd10c3736218e8f19650daa4ca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        $__internal_5e8f16a24c126c2f3697ab43e37362ca80c8dc045c14ea89790b6b962c4d3276 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5e8f16a24c126c2f3697ab43e37362ca80c8dc045c14ea89790b6b962c4d3276->enter($__internal_5e8f16a24c126c2f3697ab43e37362ca80c8dc045c14ea89790b6b962c4d3276_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        // line 8
        echo "
    <h2>Modifier une annonce</h2>

    ";
        // line 11
        echo twig_include($this->env, $context, "OCPlatformBundle:Advert:form.html.twig");
        echo "

    <p>
        Vous éditez une annonce déjà existante, merci de ne pas changer
        l'esprit général de l'annonce déjà publiée.
    </p>

    <p>
        <a href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("oc_platform_view", array("id" => twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["advert"]) || array_key_exists("advert", $context) ? $context["advert"] : (function () { throw new Twig_Error_Runtime('Variable "advert" does not exist.', 19, $this->getSourceContext()); })()), "id", array()))), "html", null, true);
        echo "\" class=\"btn btn-default\">
            <i class=\"glyphicon glyphicon-chevron-left\"></i>
            Retour à l'annonce
        </a>
    </p>

";
        
        $__internal_5e8f16a24c126c2f3697ab43e37362ca80c8dc045c14ea89790b6b962c4d3276->leave($__internal_5e8f16a24c126c2f3697ab43e37362ca80c8dc045c14ea89790b6b962c4d3276_prof);

        
        $__internal_5351a39ef9a37660bc9e245ea8b1249b8d6007fd10c3736218e8f19650daa4ca->leave($__internal_5351a39ef9a37660bc9e245ea8b1249b8d6007fd10c3736218e8f19650daa4ca_prof);

    }

    public function getTemplateName()
    {
        return "@OCPlatform/Advert/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 19,  77 => 11,  72 => 8,  63 => 7,  50 => 4,  41 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"OCPlatformBundle::layout.html.twig\" %}

{% block title %}
    Modifier une annonce - {{ parent() }}
{% endblock %}

{% block ocplatform_body %}

    <h2>Modifier une annonce</h2>

    {{ include(\"OCPlatformBundle:Advert:form.html.twig\") }}

    <p>
        Vous éditez une annonce déjà existante, merci de ne pas changer
        l'esprit général de l'annonce déjà publiée.
    </p>

    <p>
        <a href=\"{{ path('oc_platform_view', {'id': advert.id}) }}\" class=\"btn btn-default\">
            <i class=\"glyphicon glyphicon-chevron-left\"></i>
            Retour à l'annonce
        </a>
    </p>

{% endblock %}", "@OCPlatform/Advert/edit.html.twig", "C:\\wamp64\\www\\Symfony\\src\\OC\\PlatformBundle\\Resources\\views\\Advert\\edit.html.twig");
    }
}
