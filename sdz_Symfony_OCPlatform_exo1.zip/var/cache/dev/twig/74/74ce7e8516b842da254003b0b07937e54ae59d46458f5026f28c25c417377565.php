<?php

/* @Framework/Form/datetime_widget.html.php */
class __TwigTemplate_a16b47a9a33593dcba64f24c8cd9094e293b75d25939bc48b215e16dac376d40 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b801fe30bf2f16392b0a90fc85f1cbbbc69e61541a613da9b0254e7e1a02a717 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b801fe30bf2f16392b0a90fc85f1cbbbc69e61541a613da9b0254e7e1a02a717->enter($__internal_b801fe30bf2f16392b0a90fc85f1cbbbc69e61541a613da9b0254e7e1a02a717_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/datetime_widget.html.php"));

        $__internal_42318c36d005f5ea2a9afaece104a7cc1018575413272f4b9ee8015a4a44a85e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_42318c36d005f5ea2a9afaece104a7cc1018575413272f4b9ee8015a4a44a85e->enter($__internal_42318c36d005f5ea2a9afaece104a7cc1018575413272f4b9ee8015a4a44a85e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/datetime_widget.html.php"));

        // line 1
        echo "<?php if (\$widget == 'single_text'): ?>
    <?php echo \$view['form']->block(\$form, 'form_widget_simple'); ?>
<?php else: ?>
    <div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
        <?php echo \$view['form']->widget(\$form['date']).' '.\$view['form']->widget(\$form['time']) ?>
    </div>
<?php endif ?>
";
        
        $__internal_b801fe30bf2f16392b0a90fc85f1cbbbc69e61541a613da9b0254e7e1a02a717->leave($__internal_b801fe30bf2f16392b0a90fc85f1cbbbc69e61541a613da9b0254e7e1a02a717_prof);

        
        $__internal_42318c36d005f5ea2a9afaece104a7cc1018575413272f4b9ee8015a4a44a85e->leave($__internal_42318c36d005f5ea2a9afaece104a7cc1018575413272f4b9ee8015a4a44a85e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/datetime_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$widget == 'single_text'): ?>
    <?php echo \$view['form']->block(\$form, 'form_widget_simple'); ?>
<?php else: ?>
    <div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
        <?php echo \$view['form']->widget(\$form['date']).' '.\$view['form']->widget(\$form['time']) ?>
    </div>
<?php endif ?>
", "@Framework/Form/datetime_widget.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\datetime_widget.html.php");
    }
}
