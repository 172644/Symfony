<?php

/* OCCoreBundle:Default:index.html.twig */
class __TwigTemplate_9e4d3bab49ece98020f93e6cc2f60fb58389b47173707b0e5e09d6acbb82085a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("OCCoreBundle::layout.html.twig", "OCCoreBundle:Default:index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "OCCoreBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f60b654e851b3a87524ee053b096ffac97d83e43824201d9a09ef33ab2581f97 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f60b654e851b3a87524ee053b096ffac97d83e43824201d9a09ef33ab2581f97->enter($__internal_f60b654e851b3a87524ee053b096ffac97d83e43824201d9a09ef33ab2581f97_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCCoreBundle:Default:index.html.twig"));

        $__internal_0e73678fac60f27af9fa28ddc94d354adee51d072b1a5b397bbe38513a57b1f5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0e73678fac60f27af9fa28ddc94d354adee51d072b1a5b397bbe38513a57b1f5->enter($__internal_0e73678fac60f27af9fa28ddc94d354adee51d072b1a5b397bbe38513a57b1f5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCCoreBundle:Default:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f60b654e851b3a87524ee053b096ffac97d83e43824201d9a09ef33ab2581f97->leave($__internal_f60b654e851b3a87524ee053b096ffac97d83e43824201d9a09ef33ab2581f97_prof);

        
        $__internal_0e73678fac60f27af9fa28ddc94d354adee51d072b1a5b397bbe38513a57b1f5->leave($__internal_0e73678fac60f27af9fa28ddc94d354adee51d072b1a5b397bbe38513a57b1f5_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_af4e44886a6e2d865ee45836da688733849d93a365d7bee10ffa4138bb2cdb5a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_af4e44886a6e2d865ee45836da688733849d93a365d7bee10ffa4138bb2cdb5a->enter($__internal_af4e44886a6e2d865ee45836da688733849d93a365d7bee10ffa4138bb2cdb5a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_8de4494fc865a7dfaead3b0d88956ad424f621a6e76e3f11e637da1e64d0cc1c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8de4494fc865a7dfaead3b0d88956ad424f621a6e76e3f11e637da1e64d0cc1c->enter($__internal_8de4494fc865a7dfaead3b0d88956ad424f621a6e76e3f11e637da1e64d0cc1c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "    Index - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
        
        $__internal_8de4494fc865a7dfaead3b0d88956ad424f621a6e76e3f11e637da1e64d0cc1c->leave($__internal_8de4494fc865a7dfaead3b0d88956ad424f621a6e76e3f11e637da1e64d0cc1c_prof);

        
        $__internal_af4e44886a6e2d865ee45836da688733849d93a365d7bee10ffa4138bb2cdb5a->leave($__internal_af4e44886a6e2d865ee45836da688733849d93a365d7bee10ffa4138bb2cdb5a_prof);

    }

    // line 7
    public function block_body($context, array $blocks = array())
    {
        $__internal_f8c5838ecace2270ffc755a5e922b66605e10bcdb1aabc3410471ee760afac82 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f8c5838ecace2270ffc755a5e922b66605e10bcdb1aabc3410471ee760afac82->enter($__internal_f8c5838ecace2270ffc755a5e922b66605e10bcdb1aabc3410471ee760afac82_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_181d85e939603cb9c00433fb02bf8f32cf6f8d67bba629f02336eab8eb87a4f0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_181d85e939603cb9c00433fb02bf8f32cf6f8d67bba629f02336eab8eb87a4f0->enter($__internal_181d85e939603cb9c00433fb02bf8f32cf6f8d67bba629f02336eab8eb87a4f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 8
        echo "
    ";
        // line 10
        echo "    <h1>Annonces</h1>

    <hr>

    <p>
    ";
        // line 16
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 16, $this->getSourceContext()); })()), "session", array()), "flashbag", array()), "get", array(0 => "info"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 17
            echo "        <p>Message flash : ";
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "</p>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 19
        echo "    </p>
";
        
        $__internal_181d85e939603cb9c00433fb02bf8f32cf6f8d67bba629f02336eab8eb87a4f0->leave($__internal_181d85e939603cb9c00433fb02bf8f32cf6f8d67bba629f02336eab8eb87a4f0_prof);

        
        $__internal_f8c5838ecace2270ffc755a5e922b66605e10bcdb1aabc3410471ee760afac82->leave($__internal_f8c5838ecace2270ffc755a5e922b66605e10bcdb1aabc3410471ee760afac82_prof);

    }

    public function getTemplateName()
    {
        return "OCCoreBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  96 => 19,  87 => 17,  82 => 16,  75 => 10,  72 => 8,  63 => 7,  50 => 4,  41 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"OCCoreBundle::layout.html.twig\" %}

{% block title %}
    Index - {{ parent() }}
{% endblock %}

{% block body %}

    {# On définit un sous-titre commun à toutes les pages du bundle, par exemple #}
    <h1>Annonces</h1>

    <hr>

    <p>
    {# On affiche tous les messages flash dont le nom est « info » #}
    {% for message in app.session.flashbag.get('info') %}
        <p>Message flash : {{ message }}</p>
    {% endfor %}
    </p>
{% endblock %}", "OCCoreBundle:Default:index.html.twig", "C:\\wamp64\\www\\Symfony\\src\\OC\\CoreBundle/Resources/views/Default/index.html.twig");
    }
}
