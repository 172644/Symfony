<?php

/* @Twig/Exception/error.css.twig */
class __TwigTemplate_42cadc9f934d0eb6dd7c5e02c8bcb309f39b1e431a4f92fd97400d901cbe9d6f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f2dfed9f06c0597de8283d8ec7240709504def4539e799e0baad3fcf119e9a56 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f2dfed9f06c0597de8283d8ec7240709504def4539e799e0baad3fcf119e9a56->enter($__internal_f2dfed9f06c0597de8283d8ec7240709504def4539e799e0baad3fcf119e9a56_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.css.twig"));

        $__internal_91e4bdb3d7529e69a60d4dc29e388b63afd99375c237b4e3c791cb5c61cb2be4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_91e4bdb3d7529e69a60d4dc29e388b63afd99375c237b4e3c791cb5c61cb2be4->enter($__internal_91e4bdb3d7529e69a60d4dc29e388b63afd99375c237b4e3c791cb5c61cb2be4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) || array_key_exists("status_code", $context) ? $context["status_code"] : (function () { throw new Twig_Error_Runtime('Variable "status_code" does not exist.', 2, $this->getSourceContext()); })()), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) || array_key_exists("status_text", $context) ? $context["status_text"] : (function () { throw new Twig_Error_Runtime('Variable "status_text" does not exist.', 2, $this->getSourceContext()); })()), "css", null, true);
        echo "

*/
";
        
        $__internal_f2dfed9f06c0597de8283d8ec7240709504def4539e799e0baad3fcf119e9a56->leave($__internal_f2dfed9f06c0597de8283d8ec7240709504def4539e799e0baad3fcf119e9a56_prof);

        
        $__internal_91e4bdb3d7529e69a60d4dc29e388b63afd99375c237b4e3c791cb5c61cb2be4->leave($__internal_91e4bdb3d7529e69a60d4dc29e388b63afd99375c237b4e3c791cb5c61cb2be4_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "@Twig/Exception/error.css.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.css.twig");
    }
}
