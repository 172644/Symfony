<?php

/* @Framework/Form/form_widget_simple.html.php */
class __TwigTemplate_1b0b93b3a7b31e4917482d2a60978d137a4950cefef3f9c562fed92d87a84569 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d32c749ba679e06af21d35c966760cebc16d8988fb95b51177cd3aab93d6ee46 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d32c749ba679e06af21d35c966760cebc16d8988fb95b51177cd3aab93d6ee46->enter($__internal_d32c749ba679e06af21d35c966760cebc16d8988fb95b51177cd3aab93d6ee46_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        $__internal_80ed8c095f654e25143ae56260c12f5ecd48c991cd3dbd4f969130b1a0d36a33 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_80ed8c095f654e25143ae56260c12f5ecd48c991cd3dbd4f969130b1a0d36a33->enter($__internal_80ed8c095f654e25143ae56260c12f5ecd48c991cd3dbd4f969130b1a0d36a33_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        // line 1
        echo "<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
";
        
        $__internal_d32c749ba679e06af21d35c966760cebc16d8988fb95b51177cd3aab93d6ee46->leave($__internal_d32c749ba679e06af21d35c966760cebc16d8988fb95b51177cd3aab93d6ee46_prof);

        
        $__internal_80ed8c095f654e25143ae56260c12f5ecd48c991cd3dbd4f969130b1a0d36a33->leave($__internal_80ed8c095f654e25143ae56260c12f5ecd48c991cd3dbd4f969130b1a0d36a33_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_simple.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
", "@Framework/Form/form_widget_simple.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_widget_simple.html.php");
    }
}
