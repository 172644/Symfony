<?php

/* OCPlatformBundle:Advert:index.html.twig */
class __TwigTemplate_930a1ad4de50b1844cee718a63360644a08f144ae79275e1d6ff561c8fc867f5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("OCPlatformBundle::layout.html.twig", "OCPlatformBundle:Advert:index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'ocplatform_body' => array($this, 'block_ocplatform_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "OCPlatformBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b7bfd9d81e8817c0c4ad76f0a21f14cfb07cbdaee48c309394b3d0796e8edc01 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b7bfd9d81e8817c0c4ad76f0a21f14cfb07cbdaee48c309394b3d0796e8edc01->enter($__internal_b7bfd9d81e8817c0c4ad76f0a21f14cfb07cbdaee48c309394b3d0796e8edc01_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:index.html.twig"));

        $__internal_42ebddb36aedd4e138fcbd18a897bc992abb42bed20edc2708ada61752feb32d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_42ebddb36aedd4e138fcbd18a897bc992abb42bed20edc2708ada61752feb32d->enter($__internal_42ebddb36aedd4e138fcbd18a897bc992abb42bed20edc2708ada61752feb32d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b7bfd9d81e8817c0c4ad76f0a21f14cfb07cbdaee48c309394b3d0796e8edc01->leave($__internal_b7bfd9d81e8817c0c4ad76f0a21f14cfb07cbdaee48c309394b3d0796e8edc01_prof);

        
        $__internal_42ebddb36aedd4e138fcbd18a897bc992abb42bed20edc2708ada61752feb32d->leave($__internal_42ebddb36aedd4e138fcbd18a897bc992abb42bed20edc2708ada61752feb32d_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_16e68289cc410c06b02644d9de7613b67b0793ca123f249cb21ef75b54a188d2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_16e68289cc410c06b02644d9de7613b67b0793ca123f249cb21ef75b54a188d2->enter($__internal_16e68289cc410c06b02644d9de7613b67b0793ca123f249cb21ef75b54a188d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_fbfaa4de548c620fa1519909d88b284659a12eeb4cc394751dc3fa5be7e63d18 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fbfaa4de548c620fa1519909d88b284659a12eeb4cc394751dc3fa5be7e63d18->enter($__internal_fbfaa4de548c620fa1519909d88b284659a12eeb4cc394751dc3fa5be7e63d18_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "    Accueil - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
        
        $__internal_fbfaa4de548c620fa1519909d88b284659a12eeb4cc394751dc3fa5be7e63d18->leave($__internal_fbfaa4de548c620fa1519909d88b284659a12eeb4cc394751dc3fa5be7e63d18_prof);

        
        $__internal_16e68289cc410c06b02644d9de7613b67b0793ca123f249cb21ef75b54a188d2->leave($__internal_16e68289cc410c06b02644d9de7613b67b0793ca123f249cb21ef75b54a188d2_prof);

    }

    // line 7
    public function block_ocplatform_body($context, array $blocks = array())
    {
        $__internal_381878d31cd859134d32d0782d8329623626006001045c38a1b95bd0a6c0b7a6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_381878d31cd859134d32d0782d8329623626006001045c38a1b95bd0a6c0b7a6->enter($__internal_381878d31cd859134d32d0782d8329623626006001045c38a1b95bd0a6c0b7a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        $__internal_df8f836a262f7c7d6e193392f624b9a023416131cc332311cba6d7d6cfa7ae91 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_df8f836a262f7c7d6e193392f624b9a023416131cc332311cba6d7d6cfa7ae91->enter($__internal_df8f836a262f7c7d6e193392f624b9a023416131cc332311cba6d7d6cfa7ae91_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        // line 8
        echo "
    <h2>Liste des annonces</h2>

    <ul>
        ";
        // line 12
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["listAdverts"]) || array_key_exists("listAdverts", $context) ? $context["listAdverts"] : (function () { throw new Twig_Error_Runtime('Variable "listAdverts" does not exist.', 12, $this->getSourceContext()); })()));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["advert"]) {
            // line 13
            echo "            <li>
                <a href=\"";
            // line 14
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("oc_platform_view", array("id" => twig_get_attribute($this->env, $this->getSourceContext(), $context["advert"], "id", array()))), "html", null, true);
            echo "\">
                    ";
            // line 15
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["advert"], "title", array()), "html", null, true);
            echo "
                </a>
                par ";
            // line 17
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["advert"], "author", array()), "html", null, true);
            echo ",
                le ";
            // line 18
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["advert"], "date", array()), "d/m/Y"), "html", null, true);
            echo "
            </li>
        ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 21
            echo "            <li>Pas (encore !) d'annonces</li>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['advert'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 23
        echo "    </ul>

";
        
        $__internal_df8f836a262f7c7d6e193392f624b9a023416131cc332311cba6d7d6cfa7ae91->leave($__internal_df8f836a262f7c7d6e193392f624b9a023416131cc332311cba6d7d6cfa7ae91_prof);

        
        $__internal_381878d31cd859134d32d0782d8329623626006001045c38a1b95bd0a6c0b7a6->leave($__internal_381878d31cd859134d32d0782d8329623626006001045c38a1b95bd0a6c0b7a6_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Advert:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  114 => 23,  107 => 21,  99 => 18,  95 => 17,  90 => 15,  86 => 14,  83 => 13,  78 => 12,  72 => 8,  63 => 7,  50 => 4,  41 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"OCPlatformBundle::layout.html.twig\" %}

{% block title %}
    Accueil - {{ parent() }}
{% endblock %}

{% block ocplatform_body %}

    <h2>Liste des annonces</h2>

    <ul>
        {% for advert in listAdverts %}
            <li>
                <a href=\"{{ path('oc_platform_view', {'id': advert.id}) }}\">
                    {{ advert.title }}
                </a>
                par {{ advert.author }},
                le {{ advert.date|date('d/m/Y') }}
            </li>
        {% else %}
            <li>Pas (encore !) d'annonces</li>
        {% endfor %}
    </ul>

{% endblock %}", "OCPlatformBundle:Advert:index.html.twig", "C:\\wamp64\\www\\Symfony\\src\\OC\\PlatformBundle/Resources/views/Advert/index.html.twig");
    }
}
