<?php

/* @Framework/Form/button_attributes.html.php */
class __TwigTemplate_6aafb342be4e2acda52a6879af15452c017da52a6d6a680e04afeadefe6c58a1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_618bdd0e0b73d7024602ae92ed79322b71ae30dd29bcbefaad77bcd655f4c6fc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_618bdd0e0b73d7024602ae92ed79322b71ae30dd29bcbefaad77bcd655f4c6fc->enter($__internal_618bdd0e0b73d7024602ae92ed79322b71ae30dd29bcbefaad77bcd655f4c6fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_attributes.html.php"));

        $__internal_f17cd3909d4920d8e1a3e071027a1ab49e831b411bfde978063600c673763fbd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f17cd3909d4920d8e1a3e071027a1ab49e831b411bfde978063600c673763fbd->enter($__internal_f17cd3909d4920d8e1a3e071027a1ab49e831b411bfde978063600c673763fbd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_attributes.html.php"));

        // line 1
        echo "id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"<?php if (\$disabled): ?> disabled=\"disabled\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
";
        
        $__internal_618bdd0e0b73d7024602ae92ed79322b71ae30dd29bcbefaad77bcd655f4c6fc->leave($__internal_618bdd0e0b73d7024602ae92ed79322b71ae30dd29bcbefaad77bcd655f4c6fc_prof);

        
        $__internal_f17cd3909d4920d8e1a3e071027a1ab49e831b411bfde978063600c673763fbd->leave($__internal_f17cd3909d4920d8e1a3e071027a1ab49e831b411bfde978063600c673763fbd_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"<?php if (\$disabled): ?> disabled=\"disabled\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
", "@Framework/Form/button_attributes.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_attributes.html.php");
    }
}
