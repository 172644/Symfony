<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_4e2aa164d489f324cea90160237690df886b0285174359ace5a26ee512314736 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_34ce127fb6ef46d3db03fd195bd6167ed8c9ce26ae683562af174936f80a7012 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_34ce127fb6ef46d3db03fd195bd6167ed8c9ce26ae683562af174936f80a7012->enter($__internal_34ce127fb6ef46d3db03fd195bd6167ed8c9ce26ae683562af174936f80a7012_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_fb201a7eb41d8a1517333651ac8183f1991b480eb8e881ed52cd08449040407b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fb201a7eb41d8a1517333651ac8183f1991b480eb8e881ed52cd08449040407b->enter($__internal_fb201a7eb41d8a1517333651ac8183f1991b480eb8e881ed52cd08449040407b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_34ce127fb6ef46d3db03fd195bd6167ed8c9ce26ae683562af174936f80a7012->leave($__internal_34ce127fb6ef46d3db03fd195bd6167ed8c9ce26ae683562af174936f80a7012_prof);

        
        $__internal_fb201a7eb41d8a1517333651ac8183f1991b480eb8e881ed52cd08449040407b->leave($__internal_fb201a7eb41d8a1517333651ac8183f1991b480eb8e881ed52cd08449040407b_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_4ca1cdb8e955fbeea6be78b5731d27d856983428dda050d28233143536808ad0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4ca1cdb8e955fbeea6be78b5731d27d856983428dda050d28233143536808ad0->enter($__internal_4ca1cdb8e955fbeea6be78b5731d27d856983428dda050d28233143536808ad0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_6b17754920bd8a6904ae22496100c9ce138b1fd4ba51415db22f829ed2ed9ef6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6b17754920bd8a6904ae22496100c9ce138b1fd4ba51415db22f829ed2ed9ef6->enter($__internal_6b17754920bd8a6904ae22496100c9ce138b1fd4ba51415db22f829ed2ed9ef6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_6b17754920bd8a6904ae22496100c9ce138b1fd4ba51415db22f829ed2ed9ef6->leave($__internal_6b17754920bd8a6904ae22496100c9ce138b1fd4ba51415db22f829ed2ed9ef6_prof);

        
        $__internal_4ca1cdb8e955fbeea6be78b5731d27d856983428dda050d28233143536808ad0->leave($__internal_4ca1cdb8e955fbeea6be78b5731d27d856983428dda050d28233143536808ad0_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_ac315f55004982ece280a29dc0f6d0d81f69521e0c2040081404ceae298663fa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ac315f55004982ece280a29dc0f6d0d81f69521e0c2040081404ceae298663fa->enter($__internal_ac315f55004982ece280a29dc0f6d0d81f69521e0c2040081404ceae298663fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_a00a6144a1d7bb537ff9420d119ae35f4d89bb35ec23efec1ca754367cf965c2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a00a6144a1d7bb537ff9420d119ae35f4d89bb35ec23efec1ca754367cf965c2->enter($__internal_a00a6144a1d7bb537ff9420d119ae35f4d89bb35ec23efec1ca754367cf965c2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_a00a6144a1d7bb537ff9420d119ae35f4d89bb35ec23efec1ca754367cf965c2->leave($__internal_a00a6144a1d7bb537ff9420d119ae35f4d89bb35ec23efec1ca754367cf965c2_prof);

        
        $__internal_ac315f55004982ece280a29dc0f6d0d81f69521e0c2040081404ceae298663fa->leave($__internal_ac315f55004982ece280a29dc0f6d0d81f69521e0c2040081404ceae298663fa_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_2a721ceca96e579f0263baef52bec34ccb4829eb079163b0558e81958e4cea35 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2a721ceca96e579f0263baef52bec34ccb4829eb079163b0558e81958e4cea35->enter($__internal_2a721ceca96e579f0263baef52bec34ccb4829eb079163b0558e81958e4cea35_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_5c9a5a495a47fd2a25f11da38fdef9c55dac0aae1857eabb5960337fa8c55094 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5c9a5a495a47fd2a25f11da38fdef9c55dac0aae1857eabb5960337fa8c55094->enter($__internal_5c9a5a495a47fd2a25f11da38fdef9c55dac0aae1857eabb5960337fa8c55094_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new Twig_Error_Runtime('Variable "token" does not exist.', 13, $this->getSourceContext()); })()))));
        echo "
";
        
        $__internal_5c9a5a495a47fd2a25f11da38fdef9c55dac0aae1857eabb5960337fa8c55094->leave($__internal_5c9a5a495a47fd2a25f11da38fdef9c55dac0aae1857eabb5960337fa8c55094_prof);

        
        $__internal_2a721ceca96e579f0263baef52bec34ccb4829eb079163b0558e81958e4cea35->leave($__internal_2a721ceca96e579f0263baef52bec34ccb4829eb079163b0558e81958e4cea35_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
