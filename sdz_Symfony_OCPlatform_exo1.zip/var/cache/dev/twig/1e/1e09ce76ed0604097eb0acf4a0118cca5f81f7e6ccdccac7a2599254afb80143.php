<?php

/* @Framework/Form/form_rest.html.php */
class __TwigTemplate_efd8c8c6868d3ae42239365c2edbf845905f4d1eedb3df495d6f03b5eedbc783 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_aab6c8816c097de8bab3b82849bdac5541e9b25a4a12a8a0e4cef1313a9d81cb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_aab6c8816c097de8bab3b82849bdac5541e9b25a4a12a8a0e4cef1313a9d81cb->enter($__internal_aab6c8816c097de8bab3b82849bdac5541e9b25a4a12a8a0e4cef1313a9d81cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        $__internal_1b3d88318f2aeb0507e438eb698c84fb33aafd818eaeb301bf78c8a2ac2acad0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1b3d88318f2aeb0507e438eb698c84fb33aafd818eaeb301bf78c8a2ac2acad0->enter($__internal_1b3d88318f2aeb0507e438eb698c84fb33aafd818eaeb301bf78c8a2ac2acad0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
";
        
        $__internal_aab6c8816c097de8bab3b82849bdac5541e9b25a4a12a8a0e4cef1313a9d81cb->leave($__internal_aab6c8816c097de8bab3b82849bdac5541e9b25a4a12a8a0e4cef1313a9d81cb_prof);

        
        $__internal_1b3d88318f2aeb0507e438eb698c84fb33aafd818eaeb301bf78c8a2ac2acad0->leave($__internal_1b3d88318f2aeb0507e438eb698c84fb33aafd818eaeb301bf78c8a2ac2acad0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rest.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
", "@Framework/Form/form_rest.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_rest.html.php");
    }
}
