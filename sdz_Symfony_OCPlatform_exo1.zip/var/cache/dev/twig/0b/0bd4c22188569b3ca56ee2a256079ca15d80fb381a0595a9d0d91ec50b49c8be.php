<?php

/* OCPlatformBundle:Advert:form.html.twig */
class __TwigTemplate_9957abb77de1d5f2f32af989060bbe86c17130fa42b1b15a9d4d15c37e5f7701 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a083f749fb8b5d102a8f3d43bc6212108840daa667a3fb9327d06e858096ebd1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a083f749fb8b5d102a8f3d43bc6212108840daa667a3fb9327d06e858096ebd1->enter($__internal_a083f749fb8b5d102a8f3d43bc6212108840daa667a3fb9327d06e858096ebd1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:form.html.twig"));

        $__internal_247921dbeec0d978ba16f6e334b8adffa743cdd702ced5a70c70fb45443ff651 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_247921dbeec0d978ba16f6e334b8adffa743cdd702ced5a70c70fb45443ff651->enter($__internal_247921dbeec0d978ba16f6e334b8adffa743cdd702ced5a70c70fb45443ff651_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:form.html.twig"));

        // line 1
        echo "<h3>Formulaire d'annonce</h3>

";
        // line 5
        echo "<div class=\"well\">
    Ici se trouvera le formulaire.
</div>";
        
        $__internal_a083f749fb8b5d102a8f3d43bc6212108840daa667a3fb9327d06e858096ebd1->leave($__internal_a083f749fb8b5d102a8f3d43bc6212108840daa667a3fb9327d06e858096ebd1_prof);

        
        $__internal_247921dbeec0d978ba16f6e334b8adffa743cdd702ced5a70c70fb45443ff651->leave($__internal_247921dbeec0d978ba16f6e334b8adffa743cdd702ced5a70c70fb45443ff651_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Advert:form.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  29 => 5,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<h3>Formulaire d'annonce</h3>

{# On laisse vide la vue pour l'instant, on la comblera plus tard
   lorsqu'on saura afficher un formulaire. #}
<div class=\"well\">
    Ici se trouvera le formulaire.
</div>", "OCPlatformBundle:Advert:form.html.twig", "C:\\wamp64\\www\\Symfony\\src\\OC\\PlatformBundle/Resources/views/Advert/form.html.twig");
    }
}
