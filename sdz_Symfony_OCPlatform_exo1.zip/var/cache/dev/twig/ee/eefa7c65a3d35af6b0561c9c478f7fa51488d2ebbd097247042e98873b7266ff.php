<?php

/* ::base.html.twig */
class __TwigTemplate_5da73626c952fe141b5f072afe364778e68a2ed8caf78f84a2a4ac22f14ac4a2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_de4282928ac2f86f826e783162c84b3a8fd582d0c98f82239f8193ff95a10bb4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_de4282928ac2f86f826e783162c84b3a8fd582d0c98f82239f8193ff95a10bb4->enter($__internal_de4282928ac2f86f826e783162c84b3a8fd582d0c98f82239f8193ff95a10bb4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        $__internal_c7bfe006303ed7388edb8121a0932e88a1d095ffead4f5d366c1a7b76e554bb5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c7bfe006303ed7388edb8121a0932e88a1d095ffead4f5d366c1a7b76e554bb5->enter($__internal_c7bfe006303ed7388edb8121a0932e88a1d095ffead4f5d366c1a7b76e554bb5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_de4282928ac2f86f826e783162c84b3a8fd582d0c98f82239f8193ff95a10bb4->leave($__internal_de4282928ac2f86f826e783162c84b3a8fd582d0c98f82239f8193ff95a10bb4_prof);

        
        $__internal_c7bfe006303ed7388edb8121a0932e88a1d095ffead4f5d366c1a7b76e554bb5->leave($__internal_c7bfe006303ed7388edb8121a0932e88a1d095ffead4f5d366c1a7b76e554bb5_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_191c56ef3e1bdd2b569c2bcb0f77d613dfa3bf870eb7c514c867fd82ce14b233 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_191c56ef3e1bdd2b569c2bcb0f77d613dfa3bf870eb7c514c867fd82ce14b233->enter($__internal_191c56ef3e1bdd2b569c2bcb0f77d613dfa3bf870eb7c514c867fd82ce14b233_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_5b97ef9156c63da665e4bfcbc0eef6256b4a865c7b93e2cc8ea6fbe0d6bd52b1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5b97ef9156c63da665e4bfcbc0eef6256b4a865c7b93e2cc8ea6fbe0d6bd52b1->enter($__internal_5b97ef9156c63da665e4bfcbc0eef6256b4a865c7b93e2cc8ea6fbe0d6bd52b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_5b97ef9156c63da665e4bfcbc0eef6256b4a865c7b93e2cc8ea6fbe0d6bd52b1->leave($__internal_5b97ef9156c63da665e4bfcbc0eef6256b4a865c7b93e2cc8ea6fbe0d6bd52b1_prof);

        
        $__internal_191c56ef3e1bdd2b569c2bcb0f77d613dfa3bf870eb7c514c867fd82ce14b233->leave($__internal_191c56ef3e1bdd2b569c2bcb0f77d613dfa3bf870eb7c514c867fd82ce14b233_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_7cd2e32bcb820426cdb1ecf36b4866a3c9cb03194f5fa33e674379f5d8c633ad = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7cd2e32bcb820426cdb1ecf36b4866a3c9cb03194f5fa33e674379f5d8c633ad->enter($__internal_7cd2e32bcb820426cdb1ecf36b4866a3c9cb03194f5fa33e674379f5d8c633ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_3990dffacd22f56ab4271b226814cf9b28822c5bf4b81d94d0f8fdc9133f5228 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3990dffacd22f56ab4271b226814cf9b28822c5bf4b81d94d0f8fdc9133f5228->enter($__internal_3990dffacd22f56ab4271b226814cf9b28822c5bf4b81d94d0f8fdc9133f5228_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_3990dffacd22f56ab4271b226814cf9b28822c5bf4b81d94d0f8fdc9133f5228->leave($__internal_3990dffacd22f56ab4271b226814cf9b28822c5bf4b81d94d0f8fdc9133f5228_prof);

        
        $__internal_7cd2e32bcb820426cdb1ecf36b4866a3c9cb03194f5fa33e674379f5d8c633ad->leave($__internal_7cd2e32bcb820426cdb1ecf36b4866a3c9cb03194f5fa33e674379f5d8c633ad_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_a98e2d55c84dffe638ee4bd7b12e1709fda31a4a7e814c6dd17ef69893deae5a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a98e2d55c84dffe638ee4bd7b12e1709fda31a4a7e814c6dd17ef69893deae5a->enter($__internal_a98e2d55c84dffe638ee4bd7b12e1709fda31a4a7e814c6dd17ef69893deae5a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_0b9968e772fe5ca6a96e896d7d697820398f09e5c46e55b1ad1b4e8d2d917466 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0b9968e772fe5ca6a96e896d7d697820398f09e5c46e55b1ad1b4e8d2d917466->enter($__internal_0b9968e772fe5ca6a96e896d7d697820398f09e5c46e55b1ad1b4e8d2d917466_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_0b9968e772fe5ca6a96e896d7d697820398f09e5c46e55b1ad1b4e8d2d917466->leave($__internal_0b9968e772fe5ca6a96e896d7d697820398f09e5c46e55b1ad1b4e8d2d917466_prof);

        
        $__internal_a98e2d55c84dffe638ee4bd7b12e1709fda31a4a7e814c6dd17ef69893deae5a->leave($__internal_a98e2d55c84dffe638ee4bd7b12e1709fda31a4a7e814c6dd17ef69893deae5a_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_f1d40d646ed49a790ddf194d84bb40a84a0d8bab3f80fbb61d1f404b88235a36 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f1d40d646ed49a790ddf194d84bb40a84a0d8bab3f80fbb61d1f404b88235a36->enter($__internal_f1d40d646ed49a790ddf194d84bb40a84a0d8bab3f80fbb61d1f404b88235a36_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_59fcc53af067e68c8ceb8f54049f3d585d9882e040c29a2c797174f9aa15335f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_59fcc53af067e68c8ceb8f54049f3d585d9882e040c29a2c797174f9aa15335f->enter($__internal_59fcc53af067e68c8ceb8f54049f3d585d9882e040c29a2c797174f9aa15335f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_59fcc53af067e68c8ceb8f54049f3d585d9882e040c29a2c797174f9aa15335f->leave($__internal_59fcc53af067e68c8ceb8f54049f3d585d9882e040c29a2c797174f9aa15335f_prof);

        
        $__internal_f1d40d646ed49a790ddf194d84bb40a84a0d8bab3f80fbb61d1f404b88235a36->leave($__internal_f1d40d646ed49a790ddf194d84bb40a84a0d8bab3f80fbb61d1f404b88235a36_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 11,  100 => 10,  83 => 6,  65 => 5,  53 => 12,  50 => 11,  48 => 10,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "::base.html.twig", "C:\\wamp64\\www\\Symfony\\app/Resources\\views/base.html.twig");
    }
}
