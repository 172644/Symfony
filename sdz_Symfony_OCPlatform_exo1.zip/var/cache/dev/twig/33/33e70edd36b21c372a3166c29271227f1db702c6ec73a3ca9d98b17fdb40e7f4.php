<?php

/* WebProfilerBundle:Collector:exception.html.twig */
class __TwigTemplate_3f8e03ea4059a90a1b241df005537b98520c6fa865f953782ac0dc7755f79014 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "WebProfilerBundle:Collector:exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4ca8d88aa17ae0fb74f3b49214e6608dfbeb8467465f197c10c95e18c308f5aa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4ca8d88aa17ae0fb74f3b49214e6608dfbeb8467465f197c10c95e18c308f5aa->enter($__internal_4ca8d88aa17ae0fb74f3b49214e6608dfbeb8467465f197c10c95e18c308f5aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:exception.html.twig"));

        $__internal_6dd448ff6eec18a657dfb80da2822c0edada6b0464de95ca4ed9e8bb6d7b049b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6dd448ff6eec18a657dfb80da2822c0edada6b0464de95ca4ed9e8bb6d7b049b->enter($__internal_6dd448ff6eec18a657dfb80da2822c0edada6b0464de95ca4ed9e8bb6d7b049b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4ca8d88aa17ae0fb74f3b49214e6608dfbeb8467465f197c10c95e18c308f5aa->leave($__internal_4ca8d88aa17ae0fb74f3b49214e6608dfbeb8467465f197c10c95e18c308f5aa_prof);

        
        $__internal_6dd448ff6eec18a657dfb80da2822c0edada6b0464de95ca4ed9e8bb6d7b049b->leave($__internal_6dd448ff6eec18a657dfb80da2822c0edada6b0464de95ca4ed9e8bb6d7b049b_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_3afdb9031ad7be70012bc16289ce4206fb761fb8230f62bc2d29b62838426bc8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3afdb9031ad7be70012bc16289ce4206fb761fb8230f62bc2d29b62838426bc8->enter($__internal_3afdb9031ad7be70012bc16289ce4206fb761fb8230f62bc2d29b62838426bc8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_970168363bcd62425657e52de21b9dde845c9c3750d576542142e81cd5323acb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_970168363bcd62425657e52de21b9dde845c9c3750d576542142e81cd5323acb->enter($__internal_970168363bcd62425657e52de21b9dde845c9c3750d576542142e81cd5323acb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if (twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 4, $this->getSourceContext()); })()), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new Twig_Error_Runtime('Variable "token" does not exist.', 6, $this->getSourceContext()); })()))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_970168363bcd62425657e52de21b9dde845c9c3750d576542142e81cd5323acb->leave($__internal_970168363bcd62425657e52de21b9dde845c9c3750d576542142e81cd5323acb_prof);

        
        $__internal_3afdb9031ad7be70012bc16289ce4206fb761fb8230f62bc2d29b62838426bc8->leave($__internal_3afdb9031ad7be70012bc16289ce4206fb761fb8230f62bc2d29b62838426bc8_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_e74e7023b546e867204acff0f1df412eab662b9fa2bd8ee08493978da734555f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e74e7023b546e867204acff0f1df412eab662b9fa2bd8ee08493978da734555f->enter($__internal_e74e7023b546e867204acff0f1df412eab662b9fa2bd8ee08493978da734555f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_d75ebde500c6439097347e15f48a49cf0f04c0665dc66f649a3854a6b6e6be83 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d75ebde500c6439097347e15f48a49cf0f04c0665dc66f649a3854a6b6e6be83->enter($__internal_d75ebde500c6439097347e15f48a49cf0f04c0665dc66f649a3854a6b6e6be83_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo ((twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 13, $this->getSourceContext()); })()), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if (twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 16, $this->getSourceContext()); })()), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_d75ebde500c6439097347e15f48a49cf0f04c0665dc66f649a3854a6b6e6be83->leave($__internal_d75ebde500c6439097347e15f48a49cf0f04c0665dc66f649a3854a6b6e6be83_prof);

        
        $__internal_e74e7023b546e867204acff0f1df412eab662b9fa2bd8ee08493978da734555f->leave($__internal_e74e7023b546e867204acff0f1df412eab662b9fa2bd8ee08493978da734555f_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_3c750785fe74f2723d69d251e83573acd33bf37ee7e1ab0048d1acaa5943b7eb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3c750785fe74f2723d69d251e83573acd33bf37ee7e1ab0048d1acaa5943b7eb->enter($__internal_3c750785fe74f2723d69d251e83573acd33bf37ee7e1ab0048d1acaa5943b7eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_f605af3245cbbd5729eb9ac3b926aa4c6021191712154bcfc371172f15359d14 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f605af3245cbbd5729eb9ac3b926aa4c6021191712154bcfc371172f15359d14->enter($__internal_f605af3245cbbd5729eb9ac3b926aa4c6021191712154bcfc371172f15359d14_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 27, $this->getSourceContext()); })()), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new Twig_Error_Runtime('Variable "token" does not exist.', 33, $this->getSourceContext()); })()))));
            echo "
        </div>
    ";
        }
        
        $__internal_f605af3245cbbd5729eb9ac3b926aa4c6021191712154bcfc371172f15359d14->leave($__internal_f605af3245cbbd5729eb9ac3b926aa4c6021191712154bcfc371172f15359d14_prof);

        
        $__internal_3c750785fe74f2723d69d251e83573acd33bf37ee7e1ab0048d1acaa5943b7eb->leave($__internal_3c750785fe74f2723d69d251e83573acd33bf37ee7e1ab0048d1acaa5943b7eb_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Collector:exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "WebProfilerBundle:Collector:exception.html.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Collector/exception.html.twig");
    }
}
