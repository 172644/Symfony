<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_3c1dc4856781cb3a3b4a5ac5ae8c3c8818ecf67a4eaa2899836d7499e33bca49 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c547fd8472d193f47c98f4fe378a3f1f4afcd86f510e4fc519473649146bc30e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c547fd8472d193f47c98f4fe378a3f1f4afcd86f510e4fc519473649146bc30e->enter($__internal_c547fd8472d193f47c98f4fe378a3f1f4afcd86f510e4fc519473649146bc30e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $__internal_1d01cff834faf7ceb7c3b026e6c2074ee1d427616f227dd7befdc2835e411a13 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1d01cff834faf7ceb7c3b026e6c2074ee1d427616f227dd7befdc2835e411a13->enter($__internal_1d01cff834faf7ceb7c3b026e6c2074ee1d427616f227dd7befdc2835e411a13_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c547fd8472d193f47c98f4fe378a3f1f4afcd86f510e4fc519473649146bc30e->leave($__internal_c547fd8472d193f47c98f4fe378a3f1f4afcd86f510e4fc519473649146bc30e_prof);

        
        $__internal_1d01cff834faf7ceb7c3b026e6c2074ee1d427616f227dd7befdc2835e411a13->leave($__internal_1d01cff834faf7ceb7c3b026e6c2074ee1d427616f227dd7befdc2835e411a13_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_a5fbf9d868c96a49e09de143269256ef297359c38068821aaac367d20af13bc5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a5fbf9d868c96a49e09de143269256ef297359c38068821aaac367d20af13bc5->enter($__internal_a5fbf9d868c96a49e09de143269256ef297359c38068821aaac367d20af13bc5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_e779e3ac77d685fdfd202db7f87e48106d0bd032d978799eb4a5cd7c47a2e11d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e779e3ac77d685fdfd202db7f87e48106d0bd032d978799eb4a5cd7c47a2e11d->enter($__internal_e779e3ac77d685fdfd202db7f87e48106d0bd032d978799eb4a5cd7c47a2e11d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_e779e3ac77d685fdfd202db7f87e48106d0bd032d978799eb4a5cd7c47a2e11d->leave($__internal_e779e3ac77d685fdfd202db7f87e48106d0bd032d978799eb4a5cd7c47a2e11d_prof);

        
        $__internal_a5fbf9d868c96a49e09de143269256ef297359c38068821aaac367d20af13bc5->leave($__internal_a5fbf9d868c96a49e09de143269256ef297359c38068821aaac367d20af13bc5_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_876656f1a74e664fa4e54d626ac56f8e8a8a9e88686b5b766fc901cc45f03bc9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_876656f1a74e664fa4e54d626ac56f8e8a8a9e88686b5b766fc901cc45f03bc9->enter($__internal_876656f1a74e664fa4e54d626ac56f8e8a8a9e88686b5b766fc901cc45f03bc9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_e8bb678eff6a8c68c109b77c10fdc9c34d991405e9095652d96d05de0dc1a76e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e8bb678eff6a8c68c109b77c10fdc9c34d991405e9095652d96d05de0dc1a76e->enter($__internal_e8bb678eff6a8c68c109b77c10fdc9c34d991405e9095652d96d05de0dc1a76e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["location"]) || array_key_exists("location", $context) ? $context["location"] : (function () { throw new Twig_Error_Runtime('Variable "location" does not exist.', 8, $this->getSourceContext()); })()), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["location"]) || array_key_exists("location", $context) ? $context["location"] : (function () { throw new Twig_Error_Runtime('Variable "location" does not exist.', 8, $this->getSourceContext()); })()), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_e8bb678eff6a8c68c109b77c10fdc9c34d991405e9095652d96d05de0dc1a76e->leave($__internal_e8bb678eff6a8c68c109b77c10fdc9c34d991405e9095652d96d05de0dc1a76e_prof);

        
        $__internal_876656f1a74e664fa4e54d626ac56f8e8a8a9e88686b5b766fc901cc45f03bc9->leave($__internal_876656f1a74e664fa4e54d626ac56f8e8a8a9e88686b5b766fc901cc45f03bc9_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/toolbar_redirect.html.twig");
    }
}
