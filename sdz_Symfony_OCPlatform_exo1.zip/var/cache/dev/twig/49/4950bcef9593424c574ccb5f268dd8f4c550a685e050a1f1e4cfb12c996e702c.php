<?php

/* @Framework/Form/form_start.html.php */
class __TwigTemplate_c82780c011b03a5b05863fe9eaa0f3fd13466b91baed7dcecd3303699d31068b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9d726671b45c11bd37c9e23f258b5a3ace850f1006fede8ca495638ac9397ca2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9d726671b45c11bd37c9e23f258b5a3ace850f1006fede8ca495638ac9397ca2->enter($__internal_9d726671b45c11bd37c9e23f258b5a3ace850f1006fede8ca495638ac9397ca2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_start.html.php"));

        $__internal_84143529a38908fb2fc6dd9040f6bbb537ed2afb9fe660567397b814c84e2380 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_84143529a38908fb2fc6dd9040f6bbb537ed2afb9fe660567397b814c84e2380->enter($__internal_84143529a38908fb2fc6dd9040f6bbb537ed2afb9fe660567397b814c84e2380_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_start.html.php"));

        // line 1
        echo "<?php \$method = strtoupper(\$method) ?>
<?php \$form_method = \$method === 'GET' || \$method === 'POST' ? \$method : 'POST' ?>
<form name=\"<?php echo \$name ?>\" method=\"<?php echo strtolower(\$form_method) ?>\"<?php if (\$action !== ''): ?> action=\"<?php echo \$action ?>\"<?php endif ?><?php foreach (\$attr as \$k => \$v) { printf(' %s=\"%s\"', \$view->escape(\$k), \$view->escape(\$v)); } ?><?php if (\$multipart): ?> enctype=\"multipart/form-data\"<?php endif ?>>
<?php if (\$form_method !== \$method): ?>
    <input type=\"hidden\" name=\"_method\" value=\"<?php echo \$method ?>\" />
<?php endif ?>
";
        
        $__internal_9d726671b45c11bd37c9e23f258b5a3ace850f1006fede8ca495638ac9397ca2->leave($__internal_9d726671b45c11bd37c9e23f258b5a3ace850f1006fede8ca495638ac9397ca2_prof);

        
        $__internal_84143529a38908fb2fc6dd9040f6bbb537ed2afb9fe660567397b814c84e2380->leave($__internal_84143529a38908fb2fc6dd9040f6bbb537ed2afb9fe660567397b814c84e2380_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_start.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php \$method = strtoupper(\$method) ?>
<?php \$form_method = \$method === 'GET' || \$method === 'POST' ? \$method : 'POST' ?>
<form name=\"<?php echo \$name ?>\" method=\"<?php echo strtolower(\$form_method) ?>\"<?php if (\$action !== ''): ?> action=\"<?php echo \$action ?>\"<?php endif ?><?php foreach (\$attr as \$k => \$v) { printf(' %s=\"%s\"', \$view->escape(\$k), \$view->escape(\$v)); } ?><?php if (\$multipart): ?> enctype=\"multipart/form-data\"<?php endif ?>>
<?php if (\$form_method !== \$method): ?>
    <input type=\"hidden\" name=\"_method\" value=\"<?php echo \$method ?>\" />
<?php endif ?>
", "@Framework/Form/form_start.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_start.html.php");
    }
}
