<?php

/* @Framework/Form/choice_attributes.html.php */
class __TwigTemplate_502c7ee9e59ca49aa2f3c704024ba0141b162872e8aa7c43651ff9169f9d5386 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9fdb6c05530c71f9ad4594e82a40c6b035fa7dac6027425f84ed52d2524b2346 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9fdb6c05530c71f9ad4594e82a40c6b035fa7dac6027425f84ed52d2524b2346->enter($__internal_9fdb6c05530c71f9ad4594e82a40c6b035fa7dac6027425f84ed52d2524b2346_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_attributes.html.php"));

        $__internal_b06598b5db70ce9750fa1687b0e70932e58dc9bb699dfdfe1594adea45ba222c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b06598b5db70ce9750fa1687b0e70932e58dc9bb699dfdfe1594adea45ba222c->enter($__internal_b06598b5db70ce9750fa1687b0e70932e58dc9bb699dfdfe1594adea45ba222c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_attributes.html.php"));

        // line 1
        echo "<?php if (\$disabled): ?>disabled=\"disabled\" <?php endif ?>
<?php foreach (\$choice_attr as \$k => \$v): ?>
<?php if (\$v === true): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (\$v !== false): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
";
        
        $__internal_9fdb6c05530c71f9ad4594e82a40c6b035fa7dac6027425f84ed52d2524b2346->leave($__internal_9fdb6c05530c71f9ad4594e82a40c6b035fa7dac6027425f84ed52d2524b2346_prof);

        
        $__internal_b06598b5db70ce9750fa1687b0e70932e58dc9bb699dfdfe1594adea45ba222c->leave($__internal_b06598b5db70ce9750fa1687b0e70932e58dc9bb699dfdfe1594adea45ba222c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$disabled): ?>disabled=\"disabled\" <?php endif ?>
<?php foreach (\$choice_attr as \$k => \$v): ?>
<?php if (\$v === true): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (\$v !== false): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
", "@Framework/Form/choice_attributes.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\choice_attributes.html.php");
    }
}
