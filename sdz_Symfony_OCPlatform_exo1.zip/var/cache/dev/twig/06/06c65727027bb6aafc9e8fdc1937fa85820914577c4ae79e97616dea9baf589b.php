<?php

/* @Framework/Form/widget_container_attributes.html.php */
class __TwigTemplate_ab94721fa4e8aec8cb2c29a79ff87cb07c6fe533d0aa372af2fc1d68541d9758 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3e2f92240c5cb4aa2d1d4a17277808904470dc501bcad32dc292f5560c6bd77b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3e2f92240c5cb4aa2d1d4a17277808904470dc501bcad32dc292f5560c6bd77b->enter($__internal_3e2f92240c5cb4aa2d1d4a17277808904470dc501bcad32dc292f5560c6bd77b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_container_attributes.html.php"));

        $__internal_44715015a66a0d4f6f6cc09dfbb67e7ed6692d35b3b4bab8ff0ea5bf01d466e2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_44715015a66a0d4f6f6cc09dfbb67e7ed6692d35b3b4bab8ff0ea5bf01d466e2->enter($__internal_44715015a66a0d4f6f6cc09dfbb67e7ed6692d35b3b4bab8ff0ea5bf01d466e2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_container_attributes.html.php"));

        // line 1
        echo "<?php if (!empty(\$id)): ?>id=\"<?php echo \$view->escape(\$id) ?>\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
";
        
        $__internal_3e2f92240c5cb4aa2d1d4a17277808904470dc501bcad32dc292f5560c6bd77b->leave($__internal_3e2f92240c5cb4aa2d1d4a17277808904470dc501bcad32dc292f5560c6bd77b_prof);

        
        $__internal_44715015a66a0d4f6f6cc09dfbb67e7ed6692d35b3b4bab8ff0ea5bf01d466e2->leave($__internal_44715015a66a0d4f6f6cc09dfbb67e7ed6692d35b3b4bab8ff0ea5bf01d466e2_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/widget_container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!empty(\$id)): ?>id=\"<?php echo \$view->escape(\$id) ?>\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
", "@Framework/Form/widget_container_attributes.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\widget_container_attributes.html.php");
    }
}
