<?php

/* @Framework/Form/integer_widget.html.php */
class __TwigTemplate_a61ef476242fba1c23db3a4c091339788f610e7feae8d95dde98134be73a1097 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_02e356a73342c94574388a3d7cd8d81e26009149ff11868214eee949d34dae09 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_02e356a73342c94574388a3d7cd8d81e26009149ff11868214eee949d34dae09->enter($__internal_02e356a73342c94574388a3d7cd8d81e26009149ff11868214eee949d34dae09_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        $__internal_c0664f3261b95e6c6386cf3ba8665d5a80344cd7b4c5fb37557fe25d608a540b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c0664f3261b95e6c6386cf3ba8665d5a80344cd7b4c5fb37557fe25d608a540b->enter($__internal_c0664f3261b95e6c6386cf3ba8665d5a80344cd7b4c5fb37557fe25d608a540b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
";
        
        $__internal_02e356a73342c94574388a3d7cd8d81e26009149ff11868214eee949d34dae09->leave($__internal_02e356a73342c94574388a3d7cd8d81e26009149ff11868214eee949d34dae09_prof);

        
        $__internal_c0664f3261b95e6c6386cf3ba8665d5a80344cd7b4c5fb37557fe25d608a540b->leave($__internal_c0664f3261b95e6c6386cf3ba8665d5a80344cd7b4c5fb37557fe25d608a540b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/integer_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
", "@Framework/Form/integer_widget.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\integer_widget.html.php");
    }
}
