<?php

/* @Twig/Exception/error.rdf.twig */
class __TwigTemplate_96ef30eebae165b98d1dc33b0411e6e4a57d525e1f618802555816e0cb03a528 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fa6ce30b80b0b3fa46e4da2ef6da0b9a5a6b0845deda90fea758158f3610b6d9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fa6ce30b80b0b3fa46e4da2ef6da0b9a5a6b0845deda90fea758158f3610b6d9->enter($__internal_fa6ce30b80b0b3fa46e4da2ef6da0b9a5a6b0845deda90fea758158f3610b6d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        $__internal_db5d75d90e04419fe7f13d2c605de06531d2345262ecdfaf0bef08fdeda88ee9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_db5d75d90e04419fe7f13d2c605de06531d2345262ecdfaf0bef08fdeda88ee9->enter($__internal_db5d75d90e04419fe7f13d2c605de06531d2345262ecdfaf0bef08fdeda88ee9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_fa6ce30b80b0b3fa46e4da2ef6da0b9a5a6b0845deda90fea758158f3610b6d9->leave($__internal_fa6ce30b80b0b3fa46e4da2ef6da0b9a5a6b0845deda90fea758158f3610b6d9_prof);

        
        $__internal_db5d75d90e04419fe7f13d2c605de06531d2345262ecdfaf0bef08fdeda88ee9->leave($__internal_db5d75d90e04419fe7f13d2c605de06531d2345262ecdfaf0bef08fdeda88ee9_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "@Twig/Exception/error.rdf.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.rdf.twig");
    }
}
