<?php

/* @Framework/Form/button_widget.html.php */
class __TwigTemplate_bece110497d07f86c11f5053721cd03243c99072777ded8400eff2b540056f62 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_02c2a1a8ac8087a5890b474f053116d09de510a2301f3d7fd55355a37d667000 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_02c2a1a8ac8087a5890b474f053116d09de510a2301f3d7fd55355a37d667000->enter($__internal_02c2a1a8ac8087a5890b474f053116d09de510a2301f3d7fd55355a37d667000_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_widget.html.php"));

        $__internal_3a80e0dbe8cd53d517f76bb1c884e7ed5b6f9e824afc0109aeb2e40584143320 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3a80e0dbe8cd53d517f76bb1c884e7ed5b6f9e824afc0109aeb2e40584143320->enter($__internal_3a80e0dbe8cd53d517f76bb1c884e7ed5b6f9e824afc0109aeb2e40584143320_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_widget.html.php"));

        // line 1
        echo "<?php if (!\$label) { \$label = isset(\$label_format)
    ? strtr(\$label_format, array('%name%' => \$name, '%id%' => \$id))
    : \$view['form']->humanize(\$name); } ?>
<button type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'button' ?>\" <?php echo \$view['form']->block(\$form, 'button_attributes') ?>><?php echo \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$label, array(), \$translation_domain) : \$label) ?></button>
";
        
        $__internal_02c2a1a8ac8087a5890b474f053116d09de510a2301f3d7fd55355a37d667000->leave($__internal_02c2a1a8ac8087a5890b474f053116d09de510a2301f3d7fd55355a37d667000_prof);

        
        $__internal_3a80e0dbe8cd53d517f76bb1c884e7ed5b6f9e824afc0109aeb2e40584143320->leave($__internal_3a80e0dbe8cd53d517f76bb1c884e7ed5b6f9e824afc0109aeb2e40584143320_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!\$label) { \$label = isset(\$label_format)
    ? strtr(\$label_format, array('%name%' => \$name, '%id%' => \$id))
    : \$view['form']->humanize(\$name); } ?>
<button type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'button' ?>\" <?php echo \$view['form']->block(\$form, 'button_attributes') ?>><?php echo \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$label, array(), \$translation_domain) : \$label) ?></button>
", "@Framework/Form/button_widget.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_widget.html.php");
    }
}
