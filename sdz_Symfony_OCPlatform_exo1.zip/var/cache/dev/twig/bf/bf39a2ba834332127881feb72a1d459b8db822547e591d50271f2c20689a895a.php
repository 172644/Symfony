<?php

/* @Twig/Exception/exception.json.twig */
class __TwigTemplate_f8813f46d7c8d06356fa7be057835a4aeb000e82d4b6954dc85f7afa5a3092df extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a5f207027153120ad91b023857762a26b75ad5d4132fcf6d839b19cb3bb7dbf0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a5f207027153120ad91b023857762a26b75ad5d4132fcf6d839b19cb3bb7dbf0->enter($__internal_a5f207027153120ad91b023857762a26b75ad5d4132fcf6d839b19cb3bb7dbf0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.json.twig"));

        $__internal_9e7d6d385a41de36f7d2bc220e1398812c2ba47501dc0fd9f1f3cf740e2037ca = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9e7d6d385a41de36f7d2bc220e1398812c2ba47501dc0fd9f1f3cf740e2037ca->enter($__internal_9e7d6d385a41de36f7d2bc220e1398812c2ba47501dc0fd9f1f3cf740e2037ca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.json.twig"));

        // line 1
        echo json_encode(array("error" => array("code" => (isset($context["status_code"]) || array_key_exists("status_code", $context) ? $context["status_code"] : (function () { throw new Twig_Error_Runtime('Variable "status_code" does not exist.', 1, $this->getSourceContext()); })()), "message" => (isset($context["status_text"]) || array_key_exists("status_text", $context) ? $context["status_text"] : (function () { throw new Twig_Error_Runtime('Variable "status_text" does not exist.', 1, $this->getSourceContext()); })()), "exception" => twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 1, $this->getSourceContext()); })()), "toarray", array()))));
        echo "
";
        
        $__internal_a5f207027153120ad91b023857762a26b75ad5d4132fcf6d839b19cb3bb7dbf0->leave($__internal_a5f207027153120ad91b023857762a26b75ad5d4132fcf6d839b19cb3bb7dbf0_prof);

        
        $__internal_9e7d6d385a41de36f7d2bc220e1398812c2ba47501dc0fd9f1f3cf740e2037ca->leave($__internal_9e7d6d385a41de36f7d2bc220e1398812c2ba47501dc0fd9f1f3cf740e2037ca_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text, 'exception': exception.toarray } }|json_encode|raw }}
", "@Twig/Exception/exception.json.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.json.twig");
    }
}
