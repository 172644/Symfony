<?php

/* TwigBundle:Exception:exception.rdf.twig */
class __TwigTemplate_54848753cb345a59c694c8f04acbd1afe408232d829c4bdc3334592a26000716 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7cdd7459e6655ccb8f9a6c315d14f1bb65a2da1283ea15f34d3565a1d171d16e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7cdd7459e6655ccb8f9a6c315d14f1bb65a2da1283ea15f34d3565a1d171d16e->enter($__internal_7cdd7459e6655ccb8f9a6c315d14f1bb65a2da1283ea15f34d3565a1d171d16e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        $__internal_c405f11518d5cc8c68aefaf4339d607844703bc34e5e065b16e2db96e7ca0482 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c405f11518d5cc8c68aefaf4339d607844703bc34e5e065b16e2db96e7ca0482->enter($__internal_c405f11518d5cc8c68aefaf4339d607844703bc34e5e065b16e2db96e7ca0482_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 1, $this->getSourceContext()); })())));
        echo "
";
        
        $__internal_7cdd7459e6655ccb8f9a6c315d14f1bb65a2da1283ea15f34d3565a1d171d16e->leave($__internal_7cdd7459e6655ccb8f9a6c315d14f1bb65a2da1283ea15f34d3565a1d171d16e_prof);

        
        $__internal_c405f11518d5cc8c68aefaf4339d607844703bc34e5e065b16e2db96e7ca0482->leave($__internal_c405f11518d5cc8c68aefaf4339d607844703bc34e5e065b16e2db96e7ca0482_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "TwigBundle:Exception:exception.rdf.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.rdf.twig");
    }
}
