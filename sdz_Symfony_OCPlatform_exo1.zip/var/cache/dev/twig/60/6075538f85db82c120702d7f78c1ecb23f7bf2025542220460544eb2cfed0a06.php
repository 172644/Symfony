<?php

/* @Framework/Form/attributes.html.php */
class __TwigTemplate_1c355559eea653aad73c761e1ae3b8c67d1f9ffb82c4ae3387984c3271e223da extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5c776d389c5e3ff8051d93b99d34e208cf6a27422d87b9411922d6cd946c16e1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5c776d389c5e3ff8051d93b99d34e208cf6a27422d87b9411922d6cd946c16e1->enter($__internal_5c776d389c5e3ff8051d93b99d34e208cf6a27422d87b9411922d6cd946c16e1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        $__internal_8a7f2a7a597994181e6b3276d7373101850fce5337b98c7f0f2d4b144f4d040a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8a7f2a7a597994181e6b3276d7373101850fce5337b98c7f0f2d4b144f4d040a->enter($__internal_8a7f2a7a597994181e6b3276d7373101850fce5337b98c7f0f2d4b144f4d040a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        // line 1
        echo "<?php foreach (\$attr as \$k => \$v): ?>
<?php if ('placeholder' === \$k || 'title' === \$k): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$v, array(), \$translation_domain) : \$v)) ?>
<?php elseif (true === \$v): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (false !== \$v): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
";
        
        $__internal_5c776d389c5e3ff8051d93b99d34e208cf6a27422d87b9411922d6cd946c16e1->leave($__internal_5c776d389c5e3ff8051d93b99d34e208cf6a27422d87b9411922d6cd946c16e1_prof);

        
        $__internal_8a7f2a7a597994181e6b3276d7373101850fce5337b98c7f0f2d4b144f4d040a->leave($__internal_8a7f2a7a597994181e6b3276d7373101850fce5337b98c7f0f2d4b144f4d040a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$attr as \$k => \$v): ?>
<?php if ('placeholder' === \$k || 'title' === \$k): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$v, array(), \$translation_domain) : \$v)) ?>
<?php elseif (true === \$v): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (false !== \$v): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
", "@Framework/Form/attributes.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\attributes.html.php");
    }
}
