<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_fae5844376d1f9185f11e45e5758a0e81bdeb0db7d30806c92c9db38707f3eb3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ff034d8ac59596344f5b343102362a3a49e2125b6113729205263c5a52a71a7d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ff034d8ac59596344f5b343102362a3a49e2125b6113729205263c5a52a71a7d->enter($__internal_ff034d8ac59596344f5b343102362a3a49e2125b6113729205263c5a52a71a7d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        $__internal_11bf6962131e24080544e8232dbc49fce8bce044b20dfd1f51d2f214a97d5eca = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_11bf6962131e24080544e8232dbc49fce8bce044b20dfd1f51d2f214a97d5eca->enter($__internal_11bf6962131e24080544e8232dbc49fce8bce044b20dfd1f51d2f214a97d5eca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_ff034d8ac59596344f5b343102362a3a49e2125b6113729205263c5a52a71a7d->leave($__internal_ff034d8ac59596344f5b343102362a3a49e2125b6113729205263c5a52a71a7d_prof);

        
        $__internal_11bf6962131e24080544e8232dbc49fce8bce044b20dfd1f51d2f214a97d5eca->leave($__internal_11bf6962131e24080544e8232dbc49fce8bce044b20dfd1f51d2f214a97d5eca_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/hidden_row.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\hidden_row.html.php");
    }
}
