<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_8c1e35316c08958a082e21b5ae0eb5614bc3c3d9674e586cd0f0bde23516eba6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8279b19e04a89df30662d0dc33cf7a0e6ccbdb9b9adc2934cc38f4ad2c109d55 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8279b19e04a89df30662d0dc33cf7a0e6ccbdb9b9adc2934cc38f4ad2c109d55->enter($__internal_8279b19e04a89df30662d0dc33cf7a0e6ccbdb9b9adc2934cc38f4ad2c109d55_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        $__internal_0b18b747f23305344836b1df2fd0474e6fbf35870e0c0771e3e6e36ead3fa43a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0b18b747f23305344836b1df2fd0474e6fbf35870e0c0771e3e6e36ead3fa43a->enter($__internal_0b18b747f23305344836b1df2fd0474e6fbf35870e0c0771e3e6e36ead3fa43a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_8279b19e04a89df30662d0dc33cf7a0e6ccbdb9b9adc2934cc38f4ad2c109d55->leave($__internal_8279b19e04a89df30662d0dc33cf7a0e6ccbdb9b9adc2934cc38f4ad2c109d55_prof);

        
        $__internal_0b18b747f23305344836b1df2fd0474e6fbf35870e0c0771e3e6e36ead3fa43a->leave($__internal_0b18b747f23305344836b1df2fd0474e6fbf35870e0c0771e3e6e36ead3fa43a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
", "@Framework/Form/search_widget.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\search_widget.html.php");
    }
}
