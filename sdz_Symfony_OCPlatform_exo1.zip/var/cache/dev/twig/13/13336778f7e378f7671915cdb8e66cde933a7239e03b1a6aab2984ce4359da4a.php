<?php

/* OCPlatformBundle:Advert:add.html.twig */
class __TwigTemplate_3f8c96ee624da9157f26e838df7496d454e0be43b25fdc38e767c4eaa02701d6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("OCPlatformBundle::layout.html.twig", "OCPlatformBundle:Advert:add.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "OCPlatformBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_45fb37f86c70ed897057bf6c1484f74c43c3ba951e5f660840c3c7539de8baba = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_45fb37f86c70ed897057bf6c1484f74c43c3ba951e5f660840c3c7539de8baba->enter($__internal_45fb37f86c70ed897057bf6c1484f74c43c3ba951e5f660840c3c7539de8baba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:add.html.twig"));

        $__internal_3bc490cad07629d7fca3da0895a92f5fce6e983e46de01bce175d863a5ac7eb2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3bc490cad07629d7fca3da0895a92f5fce6e983e46de01bce175d863a5ac7eb2->enter($__internal_3bc490cad07629d7fca3da0895a92f5fce6e983e46de01bce175d863a5ac7eb2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:add.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_45fb37f86c70ed897057bf6c1484f74c43c3ba951e5f660840c3c7539de8baba->leave($__internal_45fb37f86c70ed897057bf6c1484f74c43c3ba951e5f660840c3c7539de8baba_prof);

        
        $__internal_3bc490cad07629d7fca3da0895a92f5fce6e983e46de01bce175d863a5ac7eb2->leave($__internal_3bc490cad07629d7fca3da0895a92f5fce6e983e46de01bce175d863a5ac7eb2_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_8abfa363c112f0a83f46384c28519f5127f923692a199033cfe32bc954ed0336 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8abfa363c112f0a83f46384c28519f5127f923692a199033cfe32bc954ed0336->enter($__internal_8abfa363c112f0a83f46384c28519f5127f923692a199033cfe32bc954ed0336_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_efcb1d1d2b39ca00ec90b196ed0b8f5c193571d53ee38cc6f606f078b60e6b8d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_efcb1d1d2b39ca00ec90b196ed0b8f5c193571d53ee38cc6f606f078b60e6b8d->enter($__internal_efcb1d1d2b39ca00ec90b196ed0b8f5c193571d53ee38cc6f606f078b60e6b8d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
    <h2>Ajouter une annonce</h2>

    ";
        // line 7
        echo twig_include($this->env, $context, "OCPlatformBundle:Advert:form.html.twig");
        echo "

    <p>
        Attention : cette annonce sera ajoutée directement
        sur la page d'accueil après validation du formulaire.
    </p>

";
        
        $__internal_efcb1d1d2b39ca00ec90b196ed0b8f5c193571d53ee38cc6f606f078b60e6b8d->leave($__internal_efcb1d1d2b39ca00ec90b196ed0b8f5c193571d53ee38cc6f606f078b60e6b8d_prof);

        
        $__internal_8abfa363c112f0a83f46384c28519f5127f923692a199033cfe32bc954ed0336->leave($__internal_8abfa363c112f0a83f46384c28519f5127f923692a199033cfe32bc954ed0336_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Advert:add.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  54 => 7,  49 => 4,  40 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"OCPlatformBundle::layout.html.twig\" %}

{% block body %}

    <h2>Ajouter une annonce</h2>

    {{ include(\"OCPlatformBundle:Advert:form.html.twig\") }}

    <p>
        Attention : cette annonce sera ajoutée directement
        sur la page d'accueil après validation du formulaire.
    </p>

{% endblock %}", "OCPlatformBundle:Advert:add.html.twig", "C:\\wamp64\\www\\Symfony\\src\\OC\\PlatformBundle/Resources/views/Advert/add.html.twig");
    }
}
