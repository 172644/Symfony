<?php

/* @Twig/Exception/exception.rdf.twig */
class __TwigTemplate_320da65276ea4f102f00cc7a46d963a3cba3293e2278cb75b6d5911d94a17d5d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9689bb2d4e1a6e57601422bcc58fdccc8d36122d1194cecdb12e8be1cf5a206f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9689bb2d4e1a6e57601422bcc58fdccc8d36122d1194cecdb12e8be1cf5a206f->enter($__internal_9689bb2d4e1a6e57601422bcc58fdccc8d36122d1194cecdb12e8be1cf5a206f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.rdf.twig"));

        $__internal_6cc42ad6578c6d8d82151f4327ffcbaa7f5466b66ef8f75c152d6fe277ba92cc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6cc42ad6578c6d8d82151f4327ffcbaa7f5466b66ef8f75c152d6fe277ba92cc->enter($__internal_6cc42ad6578c6d8d82151f4327ffcbaa7f5466b66ef8f75c152d6fe277ba92cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 1, $this->getSourceContext()); })())));
        echo "
";
        
        $__internal_9689bb2d4e1a6e57601422bcc58fdccc8d36122d1194cecdb12e8be1cf5a206f->leave($__internal_9689bb2d4e1a6e57601422bcc58fdccc8d36122d1194cecdb12e8be1cf5a206f_prof);

        
        $__internal_6cc42ad6578c6d8d82151f4327ffcbaa7f5466b66ef8f75c152d6fe277ba92cc->leave($__internal_6cc42ad6578c6d8d82151f4327ffcbaa7f5466b66ef8f75c152d6fe277ba92cc_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "@Twig/Exception/exception.rdf.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.rdf.twig");
    }
}
