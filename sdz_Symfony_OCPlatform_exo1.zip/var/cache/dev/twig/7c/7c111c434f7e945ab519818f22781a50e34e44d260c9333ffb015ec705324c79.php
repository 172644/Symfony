<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_ccfd52c11c778be0a4f9afd94872cdfba48e23f6c5a85559c6f4e737a8990541 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b21e857230f335bfc0d4fd876507b451cf7e1d49e985bd092ada6ce943a97d47 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b21e857230f335bfc0d4fd876507b451cf7e1d49e985bd092ada6ce943a97d47->enter($__internal_b21e857230f335bfc0d4fd876507b451cf7e1d49e985bd092ada6ce943a97d47_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        $__internal_9eaea68276dd60e5e5c108cac23abf9261364cc51b77dc8c4d5a93596658c894 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9eaea68276dd60e5e5c108cac23abf9261364cc51b77dc8c4d5a93596658c894->enter($__internal_9eaea68276dd60e5e5c108cac23abf9261364cc51b77dc8c4d5a93596658c894_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_b21e857230f335bfc0d4fd876507b451cf7e1d49e985bd092ada6ce943a97d47->leave($__internal_b21e857230f335bfc0d4fd876507b451cf7e1d49e985bd092ada6ce943a97d47_prof);

        
        $__internal_9eaea68276dd60e5e5c108cac23abf9261364cc51b77dc8c4d5a93596658c894->leave($__internal_9eaea68276dd60e5e5c108cac23abf9261364cc51b77dc8c4d5a93596658c894_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "TwigBundle:Exception:error.atom.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.atom.twig");
    }
}
