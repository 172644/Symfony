<?php

/* @Twig/Exception/exception.atom.twig */
class __TwigTemplate_4c72b96d0e78c48d0180c8bb45d89c0f51a18dde2f248dcbf92fe9754082bfec extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5f0e39f4569baaa5e193d42947ab1f7b592d31fb9147350d6a1f27bc93b10cf7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5f0e39f4569baaa5e193d42947ab1f7b592d31fb9147350d6a1f27bc93b10cf7->enter($__internal_5f0e39f4569baaa5e193d42947ab1f7b592d31fb9147350d6a1f27bc93b10cf7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.atom.twig"));

        $__internal_99e24572dfc65cc0fa25782d186dac04a9b2808cd7ef8313e72658a57e9d80bd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_99e24572dfc65cc0fa25782d186dac04a9b2808cd7ef8313e72658a57e9d80bd->enter($__internal_99e24572dfc65cc0fa25782d186dac04a9b2808cd7ef8313e72658a57e9d80bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 1, $this->getSourceContext()); })())));
        echo "
";
        
        $__internal_5f0e39f4569baaa5e193d42947ab1f7b592d31fb9147350d6a1f27bc93b10cf7->leave($__internal_5f0e39f4569baaa5e193d42947ab1f7b592d31fb9147350d6a1f27bc93b10cf7_prof);

        
        $__internal_99e24572dfc65cc0fa25782d186dac04a9b2808cd7ef8313e72658a57e9d80bd->leave($__internal_99e24572dfc65cc0fa25782d186dac04a9b2808cd7ef8313e72658a57e9d80bd_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "@Twig/Exception/exception.atom.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.atom.twig");
    }
}
