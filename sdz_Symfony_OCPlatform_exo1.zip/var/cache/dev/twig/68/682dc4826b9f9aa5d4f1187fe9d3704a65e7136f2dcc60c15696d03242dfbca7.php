<?php

/* @OCPlatform/Advert/index.html.twig */
class __TwigTemplate_08b9266ef1dd50fa71b818e28263250701864dfcd292139c57569e979cae6bb6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("OCPlatformBundle::layout.html.twig", "@OCPlatform/Advert/index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'ocplatform_body' => array($this, 'block_ocplatform_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "OCPlatformBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ff674ccd98896ca94d54d206f9eb3ac44e007c298fbfd4413c58f23425a30947 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ff674ccd98896ca94d54d206f9eb3ac44e007c298fbfd4413c58f23425a30947->enter($__internal_ff674ccd98896ca94d54d206f9eb3ac44e007c298fbfd4413c58f23425a30947_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@OCPlatform/Advert/index.html.twig"));

        $__internal_cd2562e3d53f460a4cfa287bab1543a784424be030e4d45675a5fce6eccdb028 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cd2562e3d53f460a4cfa287bab1543a784424be030e4d45675a5fce6eccdb028->enter($__internal_cd2562e3d53f460a4cfa287bab1543a784424be030e4d45675a5fce6eccdb028_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@OCPlatform/Advert/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ff674ccd98896ca94d54d206f9eb3ac44e007c298fbfd4413c58f23425a30947->leave($__internal_ff674ccd98896ca94d54d206f9eb3ac44e007c298fbfd4413c58f23425a30947_prof);

        
        $__internal_cd2562e3d53f460a4cfa287bab1543a784424be030e4d45675a5fce6eccdb028->leave($__internal_cd2562e3d53f460a4cfa287bab1543a784424be030e4d45675a5fce6eccdb028_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_5e657875a0e1a6eb1c6ffe2a567317ef982cdac77b4bb6e96abb3e9d2d9d7d20 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5e657875a0e1a6eb1c6ffe2a567317ef982cdac77b4bb6e96abb3e9d2d9d7d20->enter($__internal_5e657875a0e1a6eb1c6ffe2a567317ef982cdac77b4bb6e96abb3e9d2d9d7d20_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_5583592b12292b516682ef32d6a174571ec2c8157f6c78eeae88a3e13f11d46c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5583592b12292b516682ef32d6a174571ec2c8157f6c78eeae88a3e13f11d46c->enter($__internal_5583592b12292b516682ef32d6a174571ec2c8157f6c78eeae88a3e13f11d46c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "    Accueil - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
        
        $__internal_5583592b12292b516682ef32d6a174571ec2c8157f6c78eeae88a3e13f11d46c->leave($__internal_5583592b12292b516682ef32d6a174571ec2c8157f6c78eeae88a3e13f11d46c_prof);

        
        $__internal_5e657875a0e1a6eb1c6ffe2a567317ef982cdac77b4bb6e96abb3e9d2d9d7d20->leave($__internal_5e657875a0e1a6eb1c6ffe2a567317ef982cdac77b4bb6e96abb3e9d2d9d7d20_prof);

    }

    // line 7
    public function block_ocplatform_body($context, array $blocks = array())
    {
        $__internal_088f370b82609113dcdcc1a492f0263d9cab71cc97f1f6f65cc4dd6a6c0fde4b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_088f370b82609113dcdcc1a492f0263d9cab71cc97f1f6f65cc4dd6a6c0fde4b->enter($__internal_088f370b82609113dcdcc1a492f0263d9cab71cc97f1f6f65cc4dd6a6c0fde4b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        $__internal_b590567051d838e428dced66152cf8c44667fd3e28ccfb46541d070cd376e97b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b590567051d838e428dced66152cf8c44667fd3e28ccfb46541d070cd376e97b->enter($__internal_b590567051d838e428dced66152cf8c44667fd3e28ccfb46541d070cd376e97b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        // line 8
        echo "
    <h2>Liste des annonces</h2>

    <ul>
        ";
        // line 12
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["listAdverts"]) || array_key_exists("listAdverts", $context) ? $context["listAdverts"] : (function () { throw new Twig_Error_Runtime('Variable "listAdverts" does not exist.', 12, $this->getSourceContext()); })()));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["advert"]) {
            // line 13
            echo "            <li>
                <a href=\"";
            // line 14
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("oc_platform_view", array("id" => twig_get_attribute($this->env, $this->getSourceContext(), $context["advert"], "id", array()))), "html", null, true);
            echo "\">
                    ";
            // line 15
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["advert"], "title", array()), "html", null, true);
            echo "
                </a>
                par ";
            // line 17
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["advert"], "author", array()), "html", null, true);
            echo ",
                le ";
            // line 18
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["advert"], "date", array()), "d/m/Y"), "html", null, true);
            echo "
            </li>
        ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 21
            echo "            <li>Pas (encore !) d'annonces</li>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['advert'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 23
        echo "    </ul>

";
        
        $__internal_b590567051d838e428dced66152cf8c44667fd3e28ccfb46541d070cd376e97b->leave($__internal_b590567051d838e428dced66152cf8c44667fd3e28ccfb46541d070cd376e97b_prof);

        
        $__internal_088f370b82609113dcdcc1a492f0263d9cab71cc97f1f6f65cc4dd6a6c0fde4b->leave($__internal_088f370b82609113dcdcc1a492f0263d9cab71cc97f1f6f65cc4dd6a6c0fde4b_prof);

    }

    public function getTemplateName()
    {
        return "@OCPlatform/Advert/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  114 => 23,  107 => 21,  99 => 18,  95 => 17,  90 => 15,  86 => 14,  83 => 13,  78 => 12,  72 => 8,  63 => 7,  50 => 4,  41 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"OCPlatformBundle::layout.html.twig\" %}

{% block title %}
    Accueil - {{ parent() }}
{% endblock %}

{% block ocplatform_body %}

    <h2>Liste des annonces</h2>

    <ul>
        {% for advert in listAdverts %}
            <li>
                <a href=\"{{ path('oc_platform_view', {'id': advert.id}) }}\">
                    {{ advert.title }}
                </a>
                par {{ advert.author }},
                le {{ advert.date|date('d/m/Y') }}
            </li>
        {% else %}
            <li>Pas (encore !) d'annonces</li>
        {% endfor %}
    </ul>

{% endblock %}", "@OCPlatform/Advert/index.html.twig", "C:\\wamp64\\www\\Symfony\\src\\OC\\PlatformBundle\\Resources\\views\\Advert\\index.html.twig");
    }
}
