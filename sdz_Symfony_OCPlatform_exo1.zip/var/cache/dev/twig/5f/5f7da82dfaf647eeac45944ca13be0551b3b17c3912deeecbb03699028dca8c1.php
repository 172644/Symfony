<?php

/* base.html.twig */
class __TwigTemplate_2aa4dfb0fc3ef824b0621678883619d7413f70ce3666b604d0ed05edf271ed29 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7123b376b253eea522fb20e1bdba5dd36421fa8455432761684da689574d4ba9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7123b376b253eea522fb20e1bdba5dd36421fa8455432761684da689574d4ba9->enter($__internal_7123b376b253eea522fb20e1bdba5dd36421fa8455432761684da689574d4ba9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_5241e859877d0f72b4bd4fd90553023a3d6eacb44f4284ede4937e2babd28c23 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5241e859877d0f72b4bd4fd90553023a3d6eacb44f4284ede4937e2babd28c23->enter($__internal_5241e859877d0f72b4bd4fd90553023a3d6eacb44f4284ede4937e2babd28c23_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_7123b376b253eea522fb20e1bdba5dd36421fa8455432761684da689574d4ba9->leave($__internal_7123b376b253eea522fb20e1bdba5dd36421fa8455432761684da689574d4ba9_prof);

        
        $__internal_5241e859877d0f72b4bd4fd90553023a3d6eacb44f4284ede4937e2babd28c23->leave($__internal_5241e859877d0f72b4bd4fd90553023a3d6eacb44f4284ede4937e2babd28c23_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_f8bb0680bd4bc737b254867279894796ce21537bf987e62834de66d1a1e74397 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f8bb0680bd4bc737b254867279894796ce21537bf987e62834de66d1a1e74397->enter($__internal_f8bb0680bd4bc737b254867279894796ce21537bf987e62834de66d1a1e74397_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_f29468fd746c0c94339068b3e309a618d990bf57aece1bed780e63be2f37459c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f29468fd746c0c94339068b3e309a618d990bf57aece1bed780e63be2f37459c->enter($__internal_f29468fd746c0c94339068b3e309a618d990bf57aece1bed780e63be2f37459c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_f29468fd746c0c94339068b3e309a618d990bf57aece1bed780e63be2f37459c->leave($__internal_f29468fd746c0c94339068b3e309a618d990bf57aece1bed780e63be2f37459c_prof);

        
        $__internal_f8bb0680bd4bc737b254867279894796ce21537bf987e62834de66d1a1e74397->leave($__internal_f8bb0680bd4bc737b254867279894796ce21537bf987e62834de66d1a1e74397_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_edb665dd9b6e296334a79e4fd7ad45f825ad1cdafb3e58e86aeaea82ba9deb9e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_edb665dd9b6e296334a79e4fd7ad45f825ad1cdafb3e58e86aeaea82ba9deb9e->enter($__internal_edb665dd9b6e296334a79e4fd7ad45f825ad1cdafb3e58e86aeaea82ba9deb9e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_9a660780249498fa22b78684537cabd0706935107581d0037a6dabc4b6d22877 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9a660780249498fa22b78684537cabd0706935107581d0037a6dabc4b6d22877->enter($__internal_9a660780249498fa22b78684537cabd0706935107581d0037a6dabc4b6d22877_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_9a660780249498fa22b78684537cabd0706935107581d0037a6dabc4b6d22877->leave($__internal_9a660780249498fa22b78684537cabd0706935107581d0037a6dabc4b6d22877_prof);

        
        $__internal_edb665dd9b6e296334a79e4fd7ad45f825ad1cdafb3e58e86aeaea82ba9deb9e->leave($__internal_edb665dd9b6e296334a79e4fd7ad45f825ad1cdafb3e58e86aeaea82ba9deb9e_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_cf3801ea02e72e8b53e02fe74813bb45a77f2e92724a2b4df6be311137f3101d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cf3801ea02e72e8b53e02fe74813bb45a77f2e92724a2b4df6be311137f3101d->enter($__internal_cf3801ea02e72e8b53e02fe74813bb45a77f2e92724a2b4df6be311137f3101d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_593ca037b293c94c0d983e9110e1eaa04fad2185e70be6eed778075361959fdd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_593ca037b293c94c0d983e9110e1eaa04fad2185e70be6eed778075361959fdd->enter($__internal_593ca037b293c94c0d983e9110e1eaa04fad2185e70be6eed778075361959fdd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_593ca037b293c94c0d983e9110e1eaa04fad2185e70be6eed778075361959fdd->leave($__internal_593ca037b293c94c0d983e9110e1eaa04fad2185e70be6eed778075361959fdd_prof);

        
        $__internal_cf3801ea02e72e8b53e02fe74813bb45a77f2e92724a2b4df6be311137f3101d->leave($__internal_cf3801ea02e72e8b53e02fe74813bb45a77f2e92724a2b4df6be311137f3101d_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_9e9307537f52df2bdacc8acbe3a1ba3ebc0cce6c6e3d6386a1ce1644697b9c8f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9e9307537f52df2bdacc8acbe3a1ba3ebc0cce6c6e3d6386a1ce1644697b9c8f->enter($__internal_9e9307537f52df2bdacc8acbe3a1ba3ebc0cce6c6e3d6386a1ce1644697b9c8f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_a1b6b9c27a933f133b9235bf59283de4f37d03c476abae5c7599147f8a76f4fe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a1b6b9c27a933f133b9235bf59283de4f37d03c476abae5c7599147f8a76f4fe->enter($__internal_a1b6b9c27a933f133b9235bf59283de4f37d03c476abae5c7599147f8a76f4fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_a1b6b9c27a933f133b9235bf59283de4f37d03c476abae5c7599147f8a76f4fe->leave($__internal_a1b6b9c27a933f133b9235bf59283de4f37d03c476abae5c7599147f8a76f4fe_prof);

        
        $__internal_9e9307537f52df2bdacc8acbe3a1ba3ebc0cce6c6e3d6386a1ce1644697b9c8f->leave($__internal_9e9307537f52df2bdacc8acbe3a1ba3ebc0cce6c6e3d6386a1ce1644697b9c8f_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 11,  100 => 10,  83 => 6,  65 => 5,  53 => 12,  50 => 11,  48 => 10,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "base.html.twig", "C:\\wamp64\\www\\Symfony\\app\\Resources\\views\\base.html.twig");
    }
}
