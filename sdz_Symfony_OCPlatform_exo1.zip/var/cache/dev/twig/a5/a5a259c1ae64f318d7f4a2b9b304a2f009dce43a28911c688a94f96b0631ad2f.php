<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_bf268b9d72a2c9b0871e1f41f74a545ed7463134ca35c1b87dc5c827188f6dbb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b9fd987cdda03cdc112fe33a4c4d8b18d282063a673cbbf4934dc1648d7e8a8f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b9fd987cdda03cdc112fe33a4c4d8b18d282063a673cbbf4934dc1648d7e8a8f->enter($__internal_b9fd987cdda03cdc112fe33a4c4d8b18d282063a673cbbf4934dc1648d7e8a8f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        $__internal_e0bc6b7f0b8a0d8c0c24d96fdb6b9a3d18e88df6b04bea2a371d3a0b5590cb12 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e0bc6b7f0b8a0d8c0c24d96fdb6b9a3d18e88df6b04bea2a371d3a0b5590cb12->enter($__internal_e0bc6b7f0b8a0d8c0c24d96fdb6b9a3d18e88df6b04bea2a371d3a0b5590cb12_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_b9fd987cdda03cdc112fe33a4c4d8b18d282063a673cbbf4934dc1648d7e8a8f->leave($__internal_b9fd987cdda03cdc112fe33a4c4d8b18d282063a673cbbf4934dc1648d7e8a8f_prof);

        
        $__internal_e0bc6b7f0b8a0d8c0c24d96fdb6b9a3d18e88df6b04bea2a371d3a0b5590cb12->leave($__internal_e0bc6b7f0b8a0d8c0c24d96fdb6b9a3d18e88df6b04bea2a371d3a0b5590cb12_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
", "@Framework/Form/form_enctype.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_enctype.html.php");
    }
}
