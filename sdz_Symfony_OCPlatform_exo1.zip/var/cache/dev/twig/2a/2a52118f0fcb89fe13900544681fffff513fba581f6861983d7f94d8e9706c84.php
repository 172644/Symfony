<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_565f8b34b3be097ef1cf22d08b129c322ef1aefa307f3c720fa2e53fac8cf9c9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fbccecf230a3717bb3adcc9591979ba5a9dc224a3cd628a86e644376a2407feb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fbccecf230a3717bb3adcc9591979ba5a9dc224a3cd628a86e644376a2407feb->enter($__internal_fbccecf230a3717bb3adcc9591979ba5a9dc224a3cd628a86e644376a2407feb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        $__internal_49ce8b9f05792a09c1c1a663d6e9aefde756fd3eec68eba8790bdc07a4828c45 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_49ce8b9f05792a09c1c1a663d6e9aefde756fd3eec68eba8790bdc07a4828c45->enter($__internal_49ce8b9f05792a09c1c1a663d6e9aefde756fd3eec68eba8790bdc07a4828c45_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_fbccecf230a3717bb3adcc9591979ba5a9dc224a3cd628a86e644376a2407feb->leave($__internal_fbccecf230a3717bb3adcc9591979ba5a9dc224a3cd628a86e644376a2407feb_prof);

        
        $__internal_49ce8b9f05792a09c1c1a663d6e9aefde756fd3eec68eba8790bdc07a4828c45->leave($__internal_49ce8b9f05792a09c1c1a663d6e9aefde756fd3eec68eba8790bdc07a4828c45_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "TwigBundle:Exception:error.rdf.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.rdf.twig");
    }
}
