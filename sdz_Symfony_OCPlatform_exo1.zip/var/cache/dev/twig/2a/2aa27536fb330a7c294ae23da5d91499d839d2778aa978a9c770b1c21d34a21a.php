<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_7da79233d9410cfc6d0edb331678ba4906ed0cb96dd278a3d46532d986ca4439 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7718924681f71011fd8619a828aae648a7ccd9ff0eb4325eb6dbc9a5c20cfcf1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7718924681f71011fd8619a828aae648a7ccd9ff0eb4325eb6dbc9a5c20cfcf1->enter($__internal_7718924681f71011fd8619a828aae648a7ccd9ff0eb4325eb6dbc9a5c20cfcf1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        $__internal_14a10e37d9eb97e40a2f8be3a9192921eef86cc8c1b57ba1999d21e2f1e69023 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_14a10e37d9eb97e40a2f8be3a9192921eef86cc8c1b57ba1999d21e2f1e69023->enter($__internal_14a10e37d9eb97e40a2f8be3a9192921eef86cc8c1b57ba1999d21e2f1e69023_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_7718924681f71011fd8619a828aae648a7ccd9ff0eb4325eb6dbc9a5c20cfcf1->leave($__internal_7718924681f71011fd8619a828aae648a7ccd9ff0eb4325eb6dbc9a5c20cfcf1_prof);

        
        $__internal_14a10e37d9eb97e40a2f8be3a9192921eef86cc8c1b57ba1999d21e2f1e69023->leave($__internal_14a10e37d9eb97e40a2f8be3a9192921eef86cc8c1b57ba1999d21e2f1e69023_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
", "@Framework/Form/reset_widget.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\reset_widget.html.php");
    }
}
