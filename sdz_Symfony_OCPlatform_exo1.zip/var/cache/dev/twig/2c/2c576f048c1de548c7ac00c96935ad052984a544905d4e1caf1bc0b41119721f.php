<?php

/* TwigBundle:Exception:exception.css.twig */
class __TwigTemplate_d58536cbe02635734a8daf2f2875baac596b14f44c8f6a0fea4fdc35780d8c4d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_70019a7d92a13132af84cd06ebeddb94c5c7daae92c884c5cd351abdd751016f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_70019a7d92a13132af84cd06ebeddb94c5c7daae92c884c5cd351abdd751016f->enter($__internal_70019a7d92a13132af84cd06ebeddb94c5c7daae92c884c5cd351abdd751016f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.css.twig"));

        $__internal_278101b6abcc7fbf08fa12928ef21660f960909768262b7aa9a7060b6e463df7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_278101b6abcc7fbf08fa12928ef21660f960909768262b7aa9a7060b6e463df7->enter($__internal_278101b6abcc7fbf08fa12928ef21660f960909768262b7aa9a7060b6e463df7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_include($this->env, $context, "@Twig/Exception/exception.txt.twig", array("exception" => (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 2, $this->getSourceContext()); })())));
        echo "
*/
";
        
        $__internal_70019a7d92a13132af84cd06ebeddb94c5c7daae92c884c5cd351abdd751016f->leave($__internal_70019a7d92a13132af84cd06ebeddb94c5c7daae92c884c5cd351abdd751016f_prof);

        
        $__internal_278101b6abcc7fbf08fa12928ef21660f960909768262b7aa9a7060b6e463df7->leave($__internal_278101b6abcc7fbf08fa12928ef21660f960909768262b7aa9a7060b6e463df7_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ include('@Twig/Exception/exception.txt.twig', { exception: exception }) }}
*/
", "TwigBundle:Exception:exception.css.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.css.twig");
    }
}
