<?php

/* @Twig/Exception/error.js.twig */
class __TwigTemplate_9ec028e067a9312809b70d68dfe3b41f3d7b92a1265202a7b422878ccaacbbb0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9211d89731a44eff4365be7cbfe5e310584431506c8f995d6c1ac64ec5334a54 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9211d89731a44eff4365be7cbfe5e310584431506c8f995d6c1ac64ec5334a54->enter($__internal_9211d89731a44eff4365be7cbfe5e310584431506c8f995d6c1ac64ec5334a54_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.js.twig"));

        $__internal_e2525aef068f30dcf3af8d4c4f832d860d35ff1a53d1f57b6e7cf9f90942674e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e2525aef068f30dcf3af8d4c4f832d860d35ff1a53d1f57b6e7cf9f90942674e->enter($__internal_e2525aef068f30dcf3af8d4c4f832d860d35ff1a53d1f57b6e7cf9f90942674e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) || array_key_exists("status_code", $context) ? $context["status_code"] : (function () { throw new Twig_Error_Runtime('Variable "status_code" does not exist.', 2, $this->getSourceContext()); })()), "js", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) || array_key_exists("status_text", $context) ? $context["status_text"] : (function () { throw new Twig_Error_Runtime('Variable "status_text" does not exist.', 2, $this->getSourceContext()); })()), "js", null, true);
        echo "

*/
";
        
        $__internal_9211d89731a44eff4365be7cbfe5e310584431506c8f995d6c1ac64ec5334a54->leave($__internal_9211d89731a44eff4365be7cbfe5e310584431506c8f995d6c1ac64ec5334a54_prof);

        
        $__internal_e2525aef068f30dcf3af8d4c4f832d860d35ff1a53d1f57b6e7cf9f90942674e->leave($__internal_e2525aef068f30dcf3af8d4c4f832d860d35ff1a53d1f57b6e7cf9f90942674e_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "@Twig/Exception/error.js.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.js.twig");
    }
}
