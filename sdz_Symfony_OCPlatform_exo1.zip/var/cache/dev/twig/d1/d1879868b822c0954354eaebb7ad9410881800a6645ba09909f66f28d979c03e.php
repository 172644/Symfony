<?php

/* @Twig/layout.html.twig */
class __TwigTemplate_5b6fbaefe888ca83714e70695384e992cae364893fbffe255244a1fa59e23c44 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_712f3a4630c2cc1fecafb43a1391080c250fc15da80165c8d5ab080988755cd3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_712f3a4630c2cc1fecafb43a1391080c250fc15da80165c8d5ab080988755cd3->enter($__internal_712f3a4630c2cc1fecafb43a1391080c250fc15da80165c8d5ab080988755cd3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/layout.html.twig"));

        $__internal_fcec521a140c255c5537a5a828e1bb4c54a86a517d0e8c792e3a73b9e9b52fe7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fcec521a140c255c5537a5a828e1bb4c54a86a517d0e8c792e3a73b9e9b52fe7->enter($__internal_fcec521a140c255c5537a5a828e1bb4c54a86a517d0e8c792e3a73b9e9b52fe7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getCharset(), "html", null, true);
        echo "\" />
        <meta name=\"robots\" content=\"noindex,nofollow\" />
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\" />
        <title>";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        <link rel=\"icon\" type=\"image/png\" href=\"";
        // line 8
        echo twig_include($this->env, $context, "@Twig/images/favicon.png.base64");
        echo "\">
        <style>";
        // line 9
        echo twig_include($this->env, $context, "@Twig/exception.css.twig");
        echo "</style>
        ";
        // line 10
        $this->displayBlock('head', $context, $blocks);
        // line 11
        echo "    </head>
    <body>
        <header>
            <div class=\"container\">
                <h1 class=\"logo\">";
        // line 15
        echo twig_include($this->env, $context, "@Twig/images/symfony-logo.svg");
        echo " Symfony Exception</h1>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/doc\">
                        <span class=\"icon\">";
        // line 19
        echo twig_include($this->env, $context, "@Twig/images/icon-book.svg");
        echo "</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Docs
                    </a>
                </div>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/support\">
                        <span class=\"icon\">";
        // line 26
        echo twig_include($this->env, $context, "@Twig/images/icon-support.svg");
        echo "</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Support
                    </a>
                </div>
            </div>
        </header>

        ";
        // line 33
        $this->displayBlock('body', $context, $blocks);
        // line 34
        echo "        ";
        echo twig_include($this->env, $context, "@Twig/base_js.html.twig");
        echo "
    </body>
</html>
";
        
        $__internal_712f3a4630c2cc1fecafb43a1391080c250fc15da80165c8d5ab080988755cd3->leave($__internal_712f3a4630c2cc1fecafb43a1391080c250fc15da80165c8d5ab080988755cd3_prof);

        
        $__internal_fcec521a140c255c5537a5a828e1bb4c54a86a517d0e8c792e3a73b9e9b52fe7->leave($__internal_fcec521a140c255c5537a5a828e1bb4c54a86a517d0e8c792e3a73b9e9b52fe7_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_029efdef879ea2f707d5149f1ca8ab7a437f43c78edfd1f10baf1bbd5fbbaf0c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_029efdef879ea2f707d5149f1ca8ab7a437f43c78edfd1f10baf1bbd5fbbaf0c->enter($__internal_029efdef879ea2f707d5149f1ca8ab7a437f43c78edfd1f10baf1bbd5fbbaf0c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_708afe150f581601972606aa4de2d28f40f1768973f1e4f7fd6f6cf9f77269af = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_708afe150f581601972606aa4de2d28f40f1768973f1e4f7fd6f6cf9f77269af->enter($__internal_708afe150f581601972606aa4de2d28f40f1768973f1e4f7fd6f6cf9f77269af_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_708afe150f581601972606aa4de2d28f40f1768973f1e4f7fd6f6cf9f77269af->leave($__internal_708afe150f581601972606aa4de2d28f40f1768973f1e4f7fd6f6cf9f77269af_prof);

        
        $__internal_029efdef879ea2f707d5149f1ca8ab7a437f43c78edfd1f10baf1bbd5fbbaf0c->leave($__internal_029efdef879ea2f707d5149f1ca8ab7a437f43c78edfd1f10baf1bbd5fbbaf0c_prof);

    }

    // line 10
    public function block_head($context, array $blocks = array())
    {
        $__internal_f46c7f75c0ef794a92bb0d6802e34c5ff43fa0adba30916e6bffbfb68b7f83c4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f46c7f75c0ef794a92bb0d6802e34c5ff43fa0adba30916e6bffbfb68b7f83c4->enter($__internal_f46c7f75c0ef794a92bb0d6802e34c5ff43fa0adba30916e6bffbfb68b7f83c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_87a41ac7995d9ab7d05e853948d9daaf54443d70fef251847c3b02a9407ae08e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_87a41ac7995d9ab7d05e853948d9daaf54443d70fef251847c3b02a9407ae08e->enter($__internal_87a41ac7995d9ab7d05e853948d9daaf54443d70fef251847c3b02a9407ae08e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        
        $__internal_87a41ac7995d9ab7d05e853948d9daaf54443d70fef251847c3b02a9407ae08e->leave($__internal_87a41ac7995d9ab7d05e853948d9daaf54443d70fef251847c3b02a9407ae08e_prof);

        
        $__internal_f46c7f75c0ef794a92bb0d6802e34c5ff43fa0adba30916e6bffbfb68b7f83c4->leave($__internal_f46c7f75c0ef794a92bb0d6802e34c5ff43fa0adba30916e6bffbfb68b7f83c4_prof);

    }

    // line 33
    public function block_body($context, array $blocks = array())
    {
        $__internal_bd8f526ec3aad8133a09c83cdfd12b2224a27ca5c5273b96be66d6cbf963f395 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bd8f526ec3aad8133a09c83cdfd12b2224a27ca5c5273b96be66d6cbf963f395->enter($__internal_bd8f526ec3aad8133a09c83cdfd12b2224a27ca5c5273b96be66d6cbf963f395_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_286968677568c5f47182461acd87d35eb2cd7bd77e71e6a21a326717f49e5677 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_286968677568c5f47182461acd87d35eb2cd7bd77e71e6a21a326717f49e5677->enter($__internal_286968677568c5f47182461acd87d35eb2cd7bd77e71e6a21a326717f49e5677_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_286968677568c5f47182461acd87d35eb2cd7bd77e71e6a21a326717f49e5677->leave($__internal_286968677568c5f47182461acd87d35eb2cd7bd77e71e6a21a326717f49e5677_prof);

        
        $__internal_bd8f526ec3aad8133a09c83cdfd12b2224a27ca5c5273b96be66d6cbf963f395->leave($__internal_bd8f526ec3aad8133a09c83cdfd12b2224a27ca5c5273b96be66d6cbf963f395_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  137 => 33,  120 => 10,  103 => 7,  88 => 34,  86 => 33,  76 => 26,  66 => 19,  59 => 15,  53 => 11,  51 => 10,  47 => 9,  43 => 8,  39 => 7,  33 => 4,  28 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"{{ _charset }}\" />
        <meta name=\"robots\" content=\"noindex,nofollow\" />
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\" />
        <title>{% block title %}{% endblock %}</title>
        <link rel=\"icon\" type=\"image/png\" href=\"{{ include('@Twig/images/favicon.png.base64') }}\">
        <style>{{ include('@Twig/exception.css.twig') }}</style>
        {% block head %}{% endblock %}
    </head>
    <body>
        <header>
            <div class=\"container\">
                <h1 class=\"logo\">{{ include('@Twig/images/symfony-logo.svg') }} Symfony Exception</h1>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/doc\">
                        <span class=\"icon\">{{ include('@Twig/images/icon-book.svg') }}</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Docs
                    </a>
                </div>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/support\">
                        <span class=\"icon\">{{ include('@Twig/images/icon-support.svg') }}</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Support
                    </a>
                </div>
            </div>
        </header>

        {% block body %}{% endblock %}
        {{ include('@Twig/base_js.html.twig') }}
    </body>
</html>
", "@Twig/layout.html.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\layout.html.twig");
    }
}
