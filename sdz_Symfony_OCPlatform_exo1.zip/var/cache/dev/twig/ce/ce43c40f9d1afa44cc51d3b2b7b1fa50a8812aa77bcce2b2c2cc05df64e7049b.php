<?php

/* layout.html.twig */
class __TwigTemplate_82849388b453349631b953b059c94d4dc21b74154136e303cbf6045843a5ee92 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cf48c92561abc37e8cd825b574c6a7cc8c38ec13640e92b6f08c6ce2be9958a6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cf48c92561abc37e8cd825b574c6a7cc8c38ec13640e92b6f08c6ce2be9958a6->enter($__internal_cf48c92561abc37e8cd825b574c6a7cc8c38ec13640e92b6f08c6ce2be9958a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "layout.html.twig"));

        $__internal_6b85b48505f37dedc939ae4e2b3d3794bee74a23e58ec385bc9aa958c83ad905 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6b85b48505f37dedc939ae4e2b3d3794bee74a23e58ec385bc9aa958c83ad905->enter($__internal_6b85b48505f37dedc939ae4e2b3d3794bee74a23e58ec385bc9aa958c83ad905_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">

    <title>";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

    ";
        // line 9
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 13
        echo "</head>

<body>
<div class=\"container\">
    <div id=\"header\" class=\"jumbotron\">
        <h1>Ma plateforme d'annonces</h1>
        <p>
            Ce projet est propulsé par Symfony,
            et construit grâce au MOOC OpenClassrooms et SensioLabs.
        </p>
        <p>
            <a class=\"btn btn-primary btn-lg\" href=\"https://openclassrooms.com/courses/developpez-votre-site-web-avec-le-framework-symfony2\">
                Participer au MOOC »
            </a>
        </p>
    </div>

    <div class=\"row\">
        <div id=\"menu\" class=\"col-md-3\">
            <h3>Menu</h3>
            <ul class=\"nav nav-pills nav-stacked\">
                <li><a href=\"";
        // line 34
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("oc_platform_home");
        echo "\">Accueil</a></li>
                <li><a href=\"";
        // line 35
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("oc_platform_add");
        echo "\">Ajouter une annonce</a></li>
            </ul>

            <h4>Dernières annonces</h4>
            ";
        // line 39
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("OCPlatformBundle:Advert:menu", array("limit" => 3)));
        echo "
        </div>
        <div id=\"content\" class=\"col-md-9\">
            ";
        // line 42
        $this->displayBlock('body', $context, $blocks);
        // line 44
        echo "        </div>
    </div>

    <hr>

    <footer>
        <p>The sky's the limit © ";
        // line 50
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y"), "html", null, true);
        echo " and beyond.</p>
    </footer>
</div>

";
        // line 54
        $this->displayBlock('javascripts', $context, $blocks);
        // line 59
        echo "
</body>
</html>";
        
        $__internal_cf48c92561abc37e8cd825b574c6a7cc8c38ec13640e92b6f08c6ce2be9958a6->leave($__internal_cf48c92561abc37e8cd825b574c6a7cc8c38ec13640e92b6f08c6ce2be9958a6_prof);

        
        $__internal_6b85b48505f37dedc939ae4e2b3d3794bee74a23e58ec385bc9aa958c83ad905->leave($__internal_6b85b48505f37dedc939ae4e2b3d3794bee74a23e58ec385bc9aa958c83ad905_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_f9297480bb16c9c4c282444b203b10a18462301d90d30b3e85852fb9dd438bfa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f9297480bb16c9c4c282444b203b10a18462301d90d30b3e85852fb9dd438bfa->enter($__internal_f9297480bb16c9c4c282444b203b10a18462301d90d30b3e85852fb9dd438bfa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_e86f0fc30e8dc71f54febd420550314b11fcca8f7fe74f5b7d69cf08eabbf75a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e86f0fc30e8dc71f54febd420550314b11fcca8f7fe74f5b7d69cf08eabbf75a->enter($__internal_e86f0fc30e8dc71f54febd420550314b11fcca8f7fe74f5b7d69cf08eabbf75a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "OC Plateforme";
        
        $__internal_e86f0fc30e8dc71f54febd420550314b11fcca8f7fe74f5b7d69cf08eabbf75a->leave($__internal_e86f0fc30e8dc71f54febd420550314b11fcca8f7fe74f5b7d69cf08eabbf75a_prof);

        
        $__internal_f9297480bb16c9c4c282444b203b10a18462301d90d30b3e85852fb9dd438bfa->leave($__internal_f9297480bb16c9c4c282444b203b10a18462301d90d30b3e85852fb9dd438bfa_prof);

    }

    // line 9
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_693c17702bdc46207f41b5c5d5dc0dd1eb9b5882ea14fc1154c128ea4fc2958e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_693c17702bdc46207f41b5c5d5dc0dd1eb9b5882ea14fc1154c128ea4fc2958e->enter($__internal_693c17702bdc46207f41b5c5d5dc0dd1eb9b5882ea14fc1154c128ea4fc2958e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_05aa18fb752a3f4b0f1eb56f3c2da8032c00246139fd331ba624e0ee30395337 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_05aa18fb752a3f4b0f1eb56f3c2da8032c00246139fd331ba624e0ee30395337->enter($__internal_05aa18fb752a3f4b0f1eb56f3c2da8032c00246139fd331ba624e0ee30395337_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 10
        echo "        ";
        // line 11
        echo "        <link rel=\"stylesheet\" href=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css\">
    ";
        
        $__internal_05aa18fb752a3f4b0f1eb56f3c2da8032c00246139fd331ba624e0ee30395337->leave($__internal_05aa18fb752a3f4b0f1eb56f3c2da8032c00246139fd331ba624e0ee30395337_prof);

        
        $__internal_693c17702bdc46207f41b5c5d5dc0dd1eb9b5882ea14fc1154c128ea4fc2958e->leave($__internal_693c17702bdc46207f41b5c5d5dc0dd1eb9b5882ea14fc1154c128ea4fc2958e_prof);

    }

    // line 42
    public function block_body($context, array $blocks = array())
    {
        $__internal_46789758ea37486c3fbdd911f2579a4bd05a326a8698dd37eca9bc157bceca1d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_46789758ea37486c3fbdd911f2579a4bd05a326a8698dd37eca9bc157bceca1d->enter($__internal_46789758ea37486c3fbdd911f2579a4bd05a326a8698dd37eca9bc157bceca1d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_f728966c789e4857c672b0bd1a2839892f01e0e0769e71e6875b14fcbc481de4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f728966c789e4857c672b0bd1a2839892f01e0e0769e71e6875b14fcbc481de4->enter($__internal_f728966c789e4857c672b0bd1a2839892f01e0e0769e71e6875b14fcbc481de4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 43
        echo "            ";
        
        $__internal_f728966c789e4857c672b0bd1a2839892f01e0e0769e71e6875b14fcbc481de4->leave($__internal_f728966c789e4857c672b0bd1a2839892f01e0e0769e71e6875b14fcbc481de4_prof);

        
        $__internal_46789758ea37486c3fbdd911f2579a4bd05a326a8698dd37eca9bc157bceca1d->leave($__internal_46789758ea37486c3fbdd911f2579a4bd05a326a8698dd37eca9bc157bceca1d_prof);

    }

    // line 54
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_5024cc1f710fc50f7843f65aecbd72c61579d1617bd32b8dcc7be1e47b546a7d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5024cc1f710fc50f7843f65aecbd72c61579d1617bd32b8dcc7be1e47b546a7d->enter($__internal_5024cc1f710fc50f7843f65aecbd72c61579d1617bd32b8dcc7be1e47b546a7d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_8b0f5fb75670746b0b44bbd4c977fd23d2c2676084bc1a19b373440826f37e54 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8b0f5fb75670746b0b44bbd4c977fd23d2c2676084bc1a19b373440826f37e54->enter($__internal_8b0f5fb75670746b0b44bbd4c977fd23d2c2676084bc1a19b373440826f37e54_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 55
        echo "    ";
        // line 56
        echo "    <script src=\"//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js\"></script>
    <script src=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js\"></script>
";
        
        $__internal_8b0f5fb75670746b0b44bbd4c977fd23d2c2676084bc1a19b373440826f37e54->leave($__internal_8b0f5fb75670746b0b44bbd4c977fd23d2c2676084bc1a19b373440826f37e54_prof);

        
        $__internal_5024cc1f710fc50f7843f65aecbd72c61579d1617bd32b8dcc7be1e47b546a7d->leave($__internal_5024cc1f710fc50f7843f65aecbd72c61579d1617bd32b8dcc7be1e47b546a7d_prof);

    }

    public function getTemplateName()
    {
        return "layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  185 => 56,  183 => 55,  174 => 54,  164 => 43,  155 => 42,  144 => 11,  142 => 10,  133 => 9,  115 => 7,  103 => 59,  101 => 54,  94 => 50,  86 => 44,  84 => 42,  78 => 39,  71 => 35,  67 => 34,  44 => 13,  42 => 9,  37 => 7,  29 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
<head>
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">

    <title>{% block title %}OC Plateforme{% endblock %}</title>

    {% block stylesheets %}
        {# On charge le CSS de bootstrap depuis le site directement #}
        <link rel=\"stylesheet\" href=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css\">
    {% endblock %}
</head>

<body>
<div class=\"container\">
    <div id=\"header\" class=\"jumbotron\">
        <h1>Ma plateforme d'annonces</h1>
        <p>
            Ce projet est propulsé par Symfony,
            et construit grâce au MOOC OpenClassrooms et SensioLabs.
        </p>
        <p>
            <a class=\"btn btn-primary btn-lg\" href=\"https://openclassrooms.com/courses/developpez-votre-site-web-avec-le-framework-symfony2\">
                Participer au MOOC »
            </a>
        </p>
    </div>

    <div class=\"row\">
        <div id=\"menu\" class=\"col-md-3\">
            <h3>Menu</h3>
            <ul class=\"nav nav-pills nav-stacked\">
                <li><a href=\"{{ path('oc_platform_home') }}\">Accueil</a></li>
                <li><a href=\"{{ path('oc_platform_add') }}\">Ajouter une annonce</a></li>
            </ul>

            <h4>Dernières annonces</h4>
            {{ render(controller(\"OCPlatformBundle:Advert:menu\", {'limit': 3})) }}
        </div>
        <div id=\"content\" class=\"col-md-9\">
            {% block body %}
            {% endblock %}
        </div>
    </div>

    <hr>

    <footer>
        <p>The sky's the limit © {{ 'now'|date('Y') }} and beyond.</p>
    </footer>
</div>

{% block javascripts %}
    {# Ajoutez ces lignes JavaScript si vous comptez vous servir des fonctionnalités du bootstrap Twitter #}
    <script src=\"//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js\"></script>
    <script src=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js\"></script>
{% endblock %}

</body>
</html>", "layout.html.twig", "C:\\wamp64\\www\\Symfony\\app\\Resources\\views\\layout.html.twig");
    }
}
