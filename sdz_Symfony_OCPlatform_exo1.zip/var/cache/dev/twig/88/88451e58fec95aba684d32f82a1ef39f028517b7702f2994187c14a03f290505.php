<?php

/* @Framework/Form/choice_widget.html.php */
class __TwigTemplate_ac2e27052e7d59afafd5c29061082757455ce0e245a1953ff678edaa60fd1506 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4eec19570d02f2495c9a8956eb4de58124c5acdd92508b32e6deca22ef6c4158 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4eec19570d02f2495c9a8956eb4de58124c5acdd92508b32e6deca22ef6c4158->enter($__internal_4eec19570d02f2495c9a8956eb4de58124c5acdd92508b32e6deca22ef6c4158_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        $__internal_9c25fb09ed4648e4803efcf5bf2ec1af91381d01e6c2b02fd7aa8c63023c061d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9c25fb09ed4648e4803efcf5bf2ec1af91381d01e6c2b02fd7aa8c63023c061d->enter($__internal_9c25fb09ed4648e4803efcf5bf2ec1af91381d01e6c2b02fd7aa8c63023c061d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        // line 1
        echo "<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
";
        
        $__internal_4eec19570d02f2495c9a8956eb4de58124c5acdd92508b32e6deca22ef6c4158->leave($__internal_4eec19570d02f2495c9a8956eb4de58124c5acdd92508b32e6deca22ef6c4158_prof);

        
        $__internal_9c25fb09ed4648e4803efcf5bf2ec1af91381d01e6c2b02fd7aa8c63023c061d->leave($__internal_9c25fb09ed4648e4803efcf5bf2ec1af91381d01e6c2b02fd7aa8c63023c061d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
", "@Framework/Form/choice_widget.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\choice_widget.html.php");
    }
}
