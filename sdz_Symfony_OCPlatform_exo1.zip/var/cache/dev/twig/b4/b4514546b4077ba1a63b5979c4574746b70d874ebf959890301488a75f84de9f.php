<?php

/* @Twig/Exception/error.atom.twig */
class __TwigTemplate_fc21ad457e738801ae9df96004e8401a0df818f1f4f767597912a4ec0ce11000 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b442467585cdad14e7af819943f125b9498a77517541228d869bbb1f2933bc17 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b442467585cdad14e7af819943f125b9498a77517541228d869bbb1f2933bc17->enter($__internal_b442467585cdad14e7af819943f125b9498a77517541228d869bbb1f2933bc17_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        $__internal_adfa264cc572f3d6f789872e244a934f3878a821eaa3681c6c227748901b1dd0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_adfa264cc572f3d6f789872e244a934f3878a821eaa3681c6c227748901b1dd0->enter($__internal_adfa264cc572f3d6f789872e244a934f3878a821eaa3681c6c227748901b1dd0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_b442467585cdad14e7af819943f125b9498a77517541228d869bbb1f2933bc17->leave($__internal_b442467585cdad14e7af819943f125b9498a77517541228d869bbb1f2933bc17_prof);

        
        $__internal_adfa264cc572f3d6f789872e244a934f3878a821eaa3681c6c227748901b1dd0->leave($__internal_adfa264cc572f3d6f789872e244a934f3878a821eaa3681c6c227748901b1dd0_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "@Twig/Exception/error.atom.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.atom.twig");
    }
}
