<?php

/* @Twig/Exception/traces.xml.twig */
class __TwigTemplate_e82a9f76d73c7cfcd859d12a2f78bdf419b0281dfbc88d1de7f18d1678fe38ca extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9c5aed6106432a9d0003b9122badfa12d72294ebcaedaca2e47327414316bca0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9c5aed6106432a9d0003b9122badfa12d72294ebcaedaca2e47327414316bca0->enter($__internal_9c5aed6106432a9d0003b9122badfa12d72294ebcaedaca2e47327414316bca0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/traces.xml.twig"));

        $__internal_68ac554fe4424e7da136529ba0de4aad500c326fa51620622b79c9c7d6bc3aba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_68ac554fe4424e7da136529ba0de4aad500c326fa51620622b79c9c7d6bc3aba->enter($__internal_68ac554fe4424e7da136529ba0de4aad500c326fa51620622b79c9c7d6bc3aba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/traces.xml.twig"));

        // line 1
        echo "        <traces>
";
        // line 2
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 2, $this->getSourceContext()); })()), "trace", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["trace"]) {
            // line 3
            echo "            <trace>
";
            // line 4
            echo twig_include($this->env, $context, "@Twig/Exception/trace.txt.twig", array("trace" => $context["trace"]), false);
            echo "

            </trace>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['trace'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 8
        echo "        </traces>
";
        
        $__internal_9c5aed6106432a9d0003b9122badfa12d72294ebcaedaca2e47327414316bca0->leave($__internal_9c5aed6106432a9d0003b9122badfa12d72294ebcaedaca2e47327414316bca0_prof);

        
        $__internal_68ac554fe4424e7da136529ba0de4aad500c326fa51620622b79c9c7d6bc3aba->leave($__internal_68ac554fe4424e7da136529ba0de4aad500c326fa51620622b79c9c7d6bc3aba_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/traces.xml.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  45 => 8,  35 => 4,  32 => 3,  28 => 2,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("        <traces>
{% for trace in exception.trace %}
            <trace>
{{ include('@Twig/Exception/trace.txt.twig', { trace: trace }, with_context = false) }}

            </trace>
{% endfor %}
        </traces>
", "@Twig/Exception/traces.xml.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\traces.xml.twig");
    }
}
