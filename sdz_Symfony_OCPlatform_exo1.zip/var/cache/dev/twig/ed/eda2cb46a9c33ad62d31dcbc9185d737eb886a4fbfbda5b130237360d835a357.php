<?php

/* @Framework/Form/time_widget.html.php */
class __TwigTemplate_f2b18c04a30d1d6adac6d191845a98211769b396ec9046cc5dade5e832fe360a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a632b6b349918f5bc346f965683a21ba17a6d3230c909e5a9dbd965e0d1268dc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a632b6b349918f5bc346f965683a21ba17a6d3230c909e5a9dbd965e0d1268dc->enter($__internal_a632b6b349918f5bc346f965683a21ba17a6d3230c909e5a9dbd965e0d1268dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/time_widget.html.php"));

        $__internal_d4eab2348694a75fa0920873a80bf6260bc7315bf7006dbf18ac60cdea1beba5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d4eab2348694a75fa0920873a80bf6260bc7315bf7006dbf18ac60cdea1beba5->enter($__internal_d4eab2348694a75fa0920873a80bf6260bc7315bf7006dbf18ac60cdea1beba5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/time_widget.html.php"));

        // line 1
        echo "<?php if (\$widget == 'single_text'): ?>
    <?php echo \$view['form']->block(\$form, 'form_widget_simple'); ?>
<?php else: ?>
    <?php \$vars = \$widget == 'text' ? array('attr' => array('size' => 1)) : array() ?>
    <div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
        <?php
            // There should be no spaces between the colons and the widgets, that's why
            // this block is written in a single PHP tag
            echo \$view['form']->widget(\$form['hour'], \$vars);

            if (\$with_minutes) {
                echo ':';
                echo \$view['form']->widget(\$form['minute'], \$vars);
            }

            if (\$with_seconds) {
                echo ':';
                echo \$view['form']->widget(\$form['second'], \$vars);
            }
        ?>
    </div>
<?php endif ?>
";
        
        $__internal_a632b6b349918f5bc346f965683a21ba17a6d3230c909e5a9dbd965e0d1268dc->leave($__internal_a632b6b349918f5bc346f965683a21ba17a6d3230c909e5a9dbd965e0d1268dc_prof);

        
        $__internal_d4eab2348694a75fa0920873a80bf6260bc7315bf7006dbf18ac60cdea1beba5->leave($__internal_d4eab2348694a75fa0920873a80bf6260bc7315bf7006dbf18ac60cdea1beba5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/time_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$widget == 'single_text'): ?>
    <?php echo \$view['form']->block(\$form, 'form_widget_simple'); ?>
<?php else: ?>
    <?php \$vars = \$widget == 'text' ? array('attr' => array('size' => 1)) : array() ?>
    <div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
        <?php
            // There should be no spaces between the colons and the widgets, that's why
            // this block is written in a single PHP tag
            echo \$view['form']->widget(\$form['hour'], \$vars);

            if (\$with_minutes) {
                echo ':';
                echo \$view['form']->widget(\$form['minute'], \$vars);
            }

            if (\$with_seconds) {
                echo ':';
                echo \$view['form']->widget(\$form['second'], \$vars);
            }
        ?>
    </div>
<?php endif ?>
", "@Framework/Form/time_widget.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\time_widget.html.php");
    }
}
