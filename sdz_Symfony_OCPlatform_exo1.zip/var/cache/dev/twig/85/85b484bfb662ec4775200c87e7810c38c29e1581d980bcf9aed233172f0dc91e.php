<?php

/* @Framework/FormTable/form_row.html.php */
class __TwigTemplate_a0f3ac387940dd5f6a26c2cab91bdc2b4e80d58af9ce795c53e32542630ec8d3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_564499464a054764646e3b665d4073bf021a860f7e459a7c01611ce6c57a1110 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_564499464a054764646e3b665d4073bf021a860f7e459a7c01611ce6c57a1110->enter($__internal_564499464a054764646e3b665d4073bf021a860f7e459a7c01611ce6c57a1110_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        $__internal_fc9c5a89a77a00e12b362a98a8bcf4f02c19bb4254601c37e9efeb952e459f19 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fc9c5a89a77a00e12b362a98a8bcf4f02c19bb4254601c37e9efeb952e459f19->enter($__internal_fc9c5a89a77a00e12b362a98a8bcf4f02c19bb4254601c37e9efeb952e459f19_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        // line 1
        echo "<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_564499464a054764646e3b665d4073bf021a860f7e459a7c01611ce6c57a1110->leave($__internal_564499464a054764646e3b665d4073bf021a860f7e459a7c01611ce6c57a1110_prof);

        
        $__internal_fc9c5a89a77a00e12b362a98a8bcf4f02c19bb4254601c37e9efeb952e459f19->leave($__internal_fc9c5a89a77a00e12b362a98a8bcf4f02c19bb4254601c37e9efeb952e459f19_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/form_row.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\form_row.html.php");
    }
}
