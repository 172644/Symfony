<?php

/* @Framework/Form/checkbox_widget.html.php */
class __TwigTemplate_807b1e77c5b2e0891d5b949c46d6f2b55c0e3650494e31e49115c7c63f735737 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_12922743b6b6972ef9504af516368465c8847c26f775a339c87601f7f1f73aa9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_12922743b6b6972ef9504af516368465c8847c26f775a339c87601f7f1f73aa9->enter($__internal_12922743b6b6972ef9504af516368465c8847c26f775a339c87601f7f1f73aa9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        $__internal_b3e2b00dc8f1241e3fd5c318fa140ec0d06f592cb0f1436a86899cc406430e43 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b3e2b00dc8f1241e3fd5c318fa140ec0d06f592cb0f1436a86899cc406430e43->enter($__internal_b3e2b00dc8f1241e3fd5c318fa140ec0d06f592cb0f1436a86899cc406430e43_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        // line 1
        echo "<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_12922743b6b6972ef9504af516368465c8847c26f775a339c87601f7f1f73aa9->leave($__internal_12922743b6b6972ef9504af516368465c8847c26f775a339c87601f7f1f73aa9_prof);

        
        $__internal_b3e2b00dc8f1241e3fd5c318fa140ec0d06f592cb0f1436a86899cc406430e43->leave($__internal_b3e2b00dc8f1241e3fd5c318fa140ec0d06f592cb0f1436a86899cc406430e43_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/checkbox_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
", "@Framework/Form/checkbox_widget.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\checkbox_widget.html.php");
    }
}
