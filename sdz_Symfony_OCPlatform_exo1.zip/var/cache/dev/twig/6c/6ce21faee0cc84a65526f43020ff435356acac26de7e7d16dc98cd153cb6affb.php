<?php

/* @Framework/Form/form_rows.html.php */
class __TwigTemplate_b1e9ab5878c304034fb49d71ec0720f71c6d852d6263743c075ee3bb796d1765 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c55d28d198921b10ae20775a581fc072f346ba0fa86a98cb31ac076585e6436f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c55d28d198921b10ae20775a581fc072f346ba0fa86a98cb31ac076585e6436f->enter($__internal_c55d28d198921b10ae20775a581fc072f346ba0fa86a98cb31ac076585e6436f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        $__internal_863f129ccdfa04df4de3cbb1416d8c2e74f77a2938128578215a8937a72659f0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_863f129ccdfa04df4de3cbb1416d8c2e74f77a2938128578215a8937a72659f0->enter($__internal_863f129ccdfa04df4de3cbb1416d8c2e74f77a2938128578215a8937a72659f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
";
        
        $__internal_c55d28d198921b10ae20775a581fc072f346ba0fa86a98cb31ac076585e6436f->leave($__internal_c55d28d198921b10ae20775a581fc072f346ba0fa86a98cb31ac076585e6436f_prof);

        
        $__internal_863f129ccdfa04df4de3cbb1416d8c2e74f77a2938128578215a8937a72659f0->leave($__internal_863f129ccdfa04df4de3cbb1416d8c2e74f77a2938128578215a8937a72659f0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rows.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
", "@Framework/Form/form_rows.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_rows.html.php");
    }
}
