<?php

/* @Framework/Form/submit_widget.html.php */
class __TwigTemplate_d5fae2f00390d755cd8f51603bcf32e2551928f4e8718d2d1c69dcbb33f4782f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_568e17a5d14904c266a86f7371ca8d92d7f3df6ed972f3e0f7b0956276a4dab4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_568e17a5d14904c266a86f7371ca8d92d7f3df6ed972f3e0f7b0956276a4dab4->enter($__internal_568e17a5d14904c266a86f7371ca8d92d7f3df6ed972f3e0f7b0956276a4dab4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        $__internal_83431ecd53286c49c5e4bc6a0164fd7137523a7fc3ce7bd5ab160ffc4d4e5394 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_83431ecd53286c49c5e4bc6a0164fd7137523a7fc3ce7bd5ab160ffc4d4e5394->enter($__internal_83431ecd53286c49c5e4bc6a0164fd7137523a7fc3ce7bd5ab160ffc4d4e5394_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
        
        $__internal_568e17a5d14904c266a86f7371ca8d92d7f3df6ed972f3e0f7b0956276a4dab4->leave($__internal_568e17a5d14904c266a86f7371ca8d92d7f3df6ed972f3e0f7b0956276a4dab4_prof);

        
        $__internal_83431ecd53286c49c5e4bc6a0164fd7137523a7fc3ce7bd5ab160ffc4d4e5394->leave($__internal_83431ecd53286c49c5e4bc6a0164fd7137523a7fc3ce7bd5ab160ffc4d4e5394_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/submit_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'submit')) ?>
", "@Framework/Form/submit_widget.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\submit_widget.html.php");
    }
}
