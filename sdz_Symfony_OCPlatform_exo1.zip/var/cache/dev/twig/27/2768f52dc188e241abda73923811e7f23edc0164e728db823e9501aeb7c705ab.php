<?php

/* @Twig/images/chevron-right.svg */
class __TwigTemplate_a37154393dd07c4e8e1c4c74919ecb9970df5402c8764f6c94c5ccfff76908f7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0eb1b285bcbf87e9806ce977121e1c9cff8e36c0b57981b86b5e60dec8ea5b63 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0eb1b285bcbf87e9806ce977121e1c9cff8e36c0b57981b86b5e60dec8ea5b63->enter($__internal_0eb1b285bcbf87e9806ce977121e1c9cff8e36c0b57981b86b5e60dec8ea5b63_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/chevron-right.svg"));

        $__internal_4288681316384f1ca67b54e96554e068d8916feb45175321718c9c2f8c53616e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4288681316384f1ca67b54e96554e068d8916feb45175321718c9c2f8c53616e->enter($__internal_4288681316384f1ca67b54e96554e068d8916feb45175321718c9c2f8c53616e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/chevron-right.svg"));

        // line 1
        echo "<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"#FFF\" d=\"M1363 877l-742 742q-19 19-45 19t-45-19l-166-166q-19-19-19-45t19-45l531-531-531-531q-19-19-19-45t19-45l166-166q19-19 45-19t45 19l742 742q19 19 19 45t-19 45z\"/></svg>
";
        
        $__internal_0eb1b285bcbf87e9806ce977121e1c9cff8e36c0b57981b86b5e60dec8ea5b63->leave($__internal_0eb1b285bcbf87e9806ce977121e1c9cff8e36c0b57981b86b5e60dec8ea5b63_prof);

        
        $__internal_4288681316384f1ca67b54e96554e068d8916feb45175321718c9c2f8c53616e->leave($__internal_4288681316384f1ca67b54e96554e068d8916feb45175321718c9c2f8c53616e_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/images/chevron-right.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"#FFF\" d=\"M1363 877l-742 742q-19 19-45 19t-45-19l-166-166q-19-19-19-45t19-45l531-531-531-531q-19-19-19-45t19-45l166-166q19-19 45-19t45 19l742 742q19 19 19 45t-19 45z\"/></svg>
", "@Twig/images/chevron-right.svg", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\images\\chevron-right.svg");
    }
}
