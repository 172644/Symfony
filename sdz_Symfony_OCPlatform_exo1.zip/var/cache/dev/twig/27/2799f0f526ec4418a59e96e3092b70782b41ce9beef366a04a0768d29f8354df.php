<?php

/* TwigBundle:Exception:exception.json.twig */
class __TwigTemplate_286928831e27b17bbd974928319b29f794c464d02c0439f21f09f20ebf72df63 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3877ce44b3ed9cbce88d0604559c1019ad14f2823ed431c38077f5c60a84d21e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3877ce44b3ed9cbce88d0604559c1019ad14f2823ed431c38077f5c60a84d21e->enter($__internal_3877ce44b3ed9cbce88d0604559c1019ad14f2823ed431c38077f5c60a84d21e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.json.twig"));

        $__internal_ea15e763eacfcfb2e6ed6ef0daaf04a8b0bfaa8ddbd01e2cca757bd0f42b6df3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ea15e763eacfcfb2e6ed6ef0daaf04a8b0bfaa8ddbd01e2cca757bd0f42b6df3->enter($__internal_ea15e763eacfcfb2e6ed6ef0daaf04a8b0bfaa8ddbd01e2cca757bd0f42b6df3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.json.twig"));

        // line 1
        echo json_encode(array("error" => array("code" => (isset($context["status_code"]) || array_key_exists("status_code", $context) ? $context["status_code"] : (function () { throw new Twig_Error_Runtime('Variable "status_code" does not exist.', 1, $this->getSourceContext()); })()), "message" => (isset($context["status_text"]) || array_key_exists("status_text", $context) ? $context["status_text"] : (function () { throw new Twig_Error_Runtime('Variable "status_text" does not exist.', 1, $this->getSourceContext()); })()), "exception" => twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 1, $this->getSourceContext()); })()), "toarray", array()))));
        echo "
";
        
        $__internal_3877ce44b3ed9cbce88d0604559c1019ad14f2823ed431c38077f5c60a84d21e->leave($__internal_3877ce44b3ed9cbce88d0604559c1019ad14f2823ed431c38077f5c60a84d21e_prof);

        
        $__internal_ea15e763eacfcfb2e6ed6ef0daaf04a8b0bfaa8ddbd01e2cca757bd0f42b6df3->leave($__internal_ea15e763eacfcfb2e6ed6ef0daaf04a8b0bfaa8ddbd01e2cca757bd0f42b6df3_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text, 'exception': exception.toarray } }|json_encode|raw }}
", "TwigBundle:Exception:exception.json.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.json.twig");
    }
}
