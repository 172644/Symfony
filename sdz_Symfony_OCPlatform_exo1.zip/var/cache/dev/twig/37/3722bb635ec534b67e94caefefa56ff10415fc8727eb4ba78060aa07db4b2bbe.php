<?php

/* @WebProfiler/Collector/exception.css.twig */
class __TwigTemplate_06c71b49e14644f76cb4342c216adbf6ad6fd0c65a62d6b0aa2880d55fbdcf5b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8e36ad111e27df15395b4c0e2a4034da008a9ce06def0b299ff0a15ff2e7ce9a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8e36ad111e27df15395b4c0e2a4034da008a9ce06def0b299ff0a15ff2e7ce9a->enter($__internal_8e36ad111e27df15395b4c0e2a4034da008a9ce06def0b299ff0a15ff2e7ce9a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.css.twig"));

        $__internal_822326f1d0e153dd5d49522a7f3f8c9802709bff0f7c2e494873e92e24c09d94 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_822326f1d0e153dd5d49522a7f3f8c9802709bff0f7c2e494873e92e24c09d94->enter($__internal_822326f1d0e153dd5d49522a7f3f8c9802709bff0f7c2e494873e92e24c09d94_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.css.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/exception.css.twig");
        echo "

.container {
    max-width: auto;
    margin: 0;
    padding: 0;
}
.container .container {
    padding: 0;
}

.exception-summary {
    background: #FFF;
    border: 1px solid #E0E0E0;
    box-shadow: 0 0 1px rgba(128, 128, 128, .2);
    margin: 1em 0;
    padding: 10px;
}

.exception-message {
    color: #B0413E;
}

.exception-metadata,
.exception-illustration {
    display: none;
}

.exception-message-wrapper {
    min-height: auto;
}
";
        
        $__internal_8e36ad111e27df15395b4c0e2a4034da008a9ce06def0b299ff0a15ff2e7ce9a->leave($__internal_8e36ad111e27df15395b4c0e2a4034da008a9ce06def0b299ff0a15ff2e7ce9a_prof);

        
        $__internal_822326f1d0e153dd5d49522a7f3f8c9802709bff0f7c2e494873e92e24c09d94->leave($__internal_822326f1d0e153dd5d49522a7f3f8c9802709bff0f7c2e494873e92e24c09d94_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/exception.css.twig') }}

.container {
    max-width: auto;
    margin: 0;
    padding: 0;
}
.container .container {
    padding: 0;
}

.exception-summary {
    background: #FFF;
    border: 1px solid #E0E0E0;
    box-shadow: 0 0 1px rgba(128, 128, 128, .2);
    margin: 1em 0;
    padding: 10px;
}

.exception-message {
    color: #B0413E;
}

.exception-metadata,
.exception-illustration {
    display: none;
}

.exception-message-wrapper {
    min-height: auto;
}
", "@WebProfiler/Collector/exception.css.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\exception.css.twig");
    }
}
