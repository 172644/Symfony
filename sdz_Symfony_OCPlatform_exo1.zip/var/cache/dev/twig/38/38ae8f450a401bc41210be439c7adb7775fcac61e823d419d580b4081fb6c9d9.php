<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_a7c946bd20671b488d0c28d5ae1cb57e6a11a429fe14cc32372c77c97c4582b0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b8f5396211e768e5a849448993cd34c346c16cd0c632beb94c9501773bac41a5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b8f5396211e768e5a849448993cd34c346c16cd0c632beb94c9501773bac41a5->enter($__internal_b8f5396211e768e5a849448993cd34c346c16cd0c632beb94c9501773bac41a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        $__internal_3255bb88f6d57419471ed0d46034a10bf6327eacbe51ab252955f8f7e45965e2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3255bb88f6d57419471ed0d46034a10bf6327eacbe51ab252955f8f7e45965e2->enter($__internal_3255bb88f6d57419471ed0d46034a10bf6327eacbe51ab252955f8f7e45965e2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_b8f5396211e768e5a849448993cd34c346c16cd0c632beb94c9501773bac41a5->leave($__internal_b8f5396211e768e5a849448993cd34c346c16cd0c632beb94c9501773bac41a5_prof);

        
        $__internal_3255bb88f6d57419471ed0d46034a10bf6327eacbe51ab252955f8f7e45965e2->leave($__internal_3255bb88f6d57419471ed0d46034a10bf6327eacbe51ab252955f8f7e45965e2_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_36005877216aebfe0f64fa15e857b8ece8eb0e743d92d80d20f18881b6331fab = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_36005877216aebfe0f64fa15e857b8ece8eb0e743d92d80d20f18881b6331fab->enter($__internal_36005877216aebfe0f64fa15e857b8ece8eb0e743d92d80d20f18881b6331fab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_212996029f4b21c281f18d08d868ce17c231df32604f7e5b2898e9de17534715 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_212996029f4b21c281f18d08d868ce17c231df32604f7e5b2898e9de17534715->enter($__internal_212996029f4b21c281f18d08d868ce17c231df32604f7e5b2898e9de17534715_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_212996029f4b21c281f18d08d868ce17c231df32604f7e5b2898e9de17534715->leave($__internal_212996029f4b21c281f18d08d868ce17c231df32604f7e5b2898e9de17534715_prof);

        
        $__internal_36005877216aebfe0f64fa15e857b8ece8eb0e743d92d80d20f18881b6331fab->leave($__internal_36005877216aebfe0f64fa15e857b8ece8eb0e743d92d80d20f18881b6331fab_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
