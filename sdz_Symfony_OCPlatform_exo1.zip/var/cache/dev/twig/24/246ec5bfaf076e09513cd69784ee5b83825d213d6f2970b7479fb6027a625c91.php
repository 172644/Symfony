<?php

/* OCPlatformBundle:Advert:oldindex.html.twig */
class __TwigTemplate_f1ae0f5586566539675ffba02076a6d307c4bd83b2a32fdcad9127ac858019b4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("OCPlatformBundle::layout.html.twig", "OCPlatformBundle:Advert:oldindex.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "OCPlatformBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4fb47fda426f654d810a915b7493a379a034632c69468ea7e42eb0c0b4dde460 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4fb47fda426f654d810a915b7493a379a034632c69468ea7e42eb0c0b4dde460->enter($__internal_4fb47fda426f654d810a915b7493a379a034632c69468ea7e42eb0c0b4dde460_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:oldindex.html.twig"));

        $__internal_09319b6c29be62d0e9388b199b0e12483150f1ece4824fbc152effc054b51f6c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_09319b6c29be62d0e9388b199b0e12483150f1ece4824fbc152effc054b51f6c->enter($__internal_09319b6c29be62d0e9388b199b0e12483150f1ece4824fbc152effc054b51f6c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:oldindex.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4fb47fda426f654d810a915b7493a379a034632c69468ea7e42eb0c0b4dde460->leave($__internal_4fb47fda426f654d810a915b7493a379a034632c69468ea7e42eb0c0b4dde460_prof);

        
        $__internal_09319b6c29be62d0e9388b199b0e12483150f1ece4824fbc152effc054b51f6c->leave($__internal_09319b6c29be62d0e9388b199b0e12483150f1ece4824fbc152effc054b51f6c_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_e4266d51bd4691a68e1727834e593c0f06c18a05407599b622ef57c06347cb01 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e4266d51bd4691a68e1727834e593c0f06c18a05407599b622ef57c06347cb01->enter($__internal_e4266d51bd4691a68e1727834e593c0f06c18a05407599b622ef57c06347cb01_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_22a26176897f2e708e42b704e539aab3c55c78257c85afcaa940e2252b8ca9a2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_22a26176897f2e708e42b704e539aab3c55c78257c85afcaa940e2252b8ca9a2->enter($__internal_22a26176897f2e708e42b704e539aab3c55c78257c85afcaa940e2252b8ca9a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $this->displayParentBlock("title", $context, $blocks);
        echo " - OldIndex";
        
        $__internal_22a26176897f2e708e42b704e539aab3c55c78257c85afcaa940e2252b8ca9a2->leave($__internal_22a26176897f2e708e42b704e539aab3c55c78257c85afcaa940e2252b8ca9a2_prof);

        
        $__internal_e4266d51bd4691a68e1727834e593c0f06c18a05407599b622ef57c06347cb01->leave($__internal_e4266d51bd4691a68e1727834e593c0f06c18a05407599b622ef57c06347cb01_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_9c579fcce0d1d2a6d4c84750495159a50b7ad351814394423d49041fd5226c86 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9c579fcce0d1d2a6d4c84750495159a50b7ad351814394423d49041fd5226c86->enter($__internal_9c579fcce0d1d2a6d4c84750495159a50b7ad351814394423d49041fd5226c86_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_69189b9110a27f35ed1b8fa4e5e1e9f47b939a238000a9494a0648938d37a1ac = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_69189b9110a27f35ed1b8fa4e5e1e9f47b939a238000a9494a0648938d37a1ac->enter($__internal_69189b9110a27f35ed1b8fa4e5e1e9f47b939a238000a9494a0648938d37a1ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <h1>Hello ";
        echo twig_escape_filter($this->env, (isset($context["nom"]) || array_key_exists("nom", $context) ? $context["nom"] : (function () { throw new Twig_Error_Runtime('Variable "nom" does not exist.', 6, $this->getSourceContext()); })()), "html", null, true);
        echo " !</h1>

    <p>
        Le Hello World est un grand classique en programmation.
        Il signifie énormément, car cela veut dire que vous avez
        réussi à exécuter le programme pour accomplir une tâche simple :
        afficher ce hello world !
    </p>
    <br />
    ";
        // line 15
        if (array_key_exists("advert_id", $context)) {
            // line 16
            echo "        <a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("oc_platform_view", array("id" => (isset($context["advert_id"]) || array_key_exists("advert_id", $context) ? $context["advert_id"] : (function () { throw new Twig_Error_Runtime('Variable "advert_id" does not exist.', 16, $this->getSourceContext()); })()))), "html", null, true);
            echo "\">
            Lien vers l'annonce d'id ";
            // line 17
            echo twig_escape_filter($this->env, (isset($context["advert_id"]) || array_key_exists("advert_id", $context) ? $context["advert_id"] : (function () { throw new Twig_Error_Runtime('Variable "advert_id" does not exist.', 17, $this->getSourceContext()); })()), "html", null, true);
            echo "
        </a>
    ";
        }
        
        $__internal_69189b9110a27f35ed1b8fa4e5e1e9f47b939a238000a9494a0648938d37a1ac->leave($__internal_69189b9110a27f35ed1b8fa4e5e1e9f47b939a238000a9494a0648938d37a1ac_prof);

        
        $__internal_9c579fcce0d1d2a6d4c84750495159a50b7ad351814394423d49041fd5226c86->leave($__internal_9c579fcce0d1d2a6d4c84750495159a50b7ad351814394423d49041fd5226c86_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Advert:oldindex.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  89 => 17,  84 => 16,  82 => 15,  69 => 6,  60 => 5,  41 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"OCPlatformBundle::layout.html.twig\" %}

{% block title %}{{ parent() }} - OldIndex{% endblock %}

{% block body %}
    <h1>Hello {{ nom }} !</h1>

    <p>
        Le Hello World est un grand classique en programmation.
        Il signifie énormément, car cela veut dire que vous avez
        réussi à exécuter le programme pour accomplir une tâche simple :
        afficher ce hello world !
    </p>
    <br />
    {% if advert_id is defined %}
        <a href=\"{{ path('oc_platform_view', { 'id': advert_id }) }}\">
            Lien vers l'annonce d'id {{ advert_id }}
        </a>
    {% endif %}
{% endblock %}", "OCPlatformBundle:Advert:oldindex.html.twig", "C:\\wamp64\\www\\Symfony\\src\\OC\\PlatformBundle/Resources/views/Advert/oldindex.html.twig");
    }
}
