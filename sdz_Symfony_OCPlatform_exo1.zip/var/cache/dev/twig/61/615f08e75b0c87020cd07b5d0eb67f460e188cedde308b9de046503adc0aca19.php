<?php

/* @WebProfiler/Profiler/toolbar_redirect.html.twig */
class __TwigTemplate_fddfe60cf95ba3ffd1f1cfabc401420b15d0eb99d8ed329956a637098dadcb47 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@WebProfiler/Profiler/toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4107ae94645f3f61101e131df1573bc222c81822952a2ff26e373597bd25d6fb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4107ae94645f3f61101e131df1573bc222c81822952a2ff26e373597bd25d6fb->enter($__internal_4107ae94645f3f61101e131df1573bc222c81822952a2ff26e373597bd25d6fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/toolbar_redirect.html.twig"));

        $__internal_118fbc534be2ff122ba6410acb401d045bad07302c220d317c3b55ce32c04799 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_118fbc534be2ff122ba6410acb401d045bad07302c220d317c3b55ce32c04799->enter($__internal_118fbc534be2ff122ba6410acb401d045bad07302c220d317c3b55ce32c04799_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4107ae94645f3f61101e131df1573bc222c81822952a2ff26e373597bd25d6fb->leave($__internal_4107ae94645f3f61101e131df1573bc222c81822952a2ff26e373597bd25d6fb_prof);

        
        $__internal_118fbc534be2ff122ba6410acb401d045bad07302c220d317c3b55ce32c04799->leave($__internal_118fbc534be2ff122ba6410acb401d045bad07302c220d317c3b55ce32c04799_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_75eb3d8d4cd0120e853dd9d0e2e84258f7157e56e45252692a411056670127d3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_75eb3d8d4cd0120e853dd9d0e2e84258f7157e56e45252692a411056670127d3->enter($__internal_75eb3d8d4cd0120e853dd9d0e2e84258f7157e56e45252692a411056670127d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_687f8cb5e952d178be66c673b627dd4b11dfe782ed68658fea1a952fa7665ee0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_687f8cb5e952d178be66c673b627dd4b11dfe782ed68658fea1a952fa7665ee0->enter($__internal_687f8cb5e952d178be66c673b627dd4b11dfe782ed68658fea1a952fa7665ee0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_687f8cb5e952d178be66c673b627dd4b11dfe782ed68658fea1a952fa7665ee0->leave($__internal_687f8cb5e952d178be66c673b627dd4b11dfe782ed68658fea1a952fa7665ee0_prof);

        
        $__internal_75eb3d8d4cd0120e853dd9d0e2e84258f7157e56e45252692a411056670127d3->leave($__internal_75eb3d8d4cd0120e853dd9d0e2e84258f7157e56e45252692a411056670127d3_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_14ad9a0e8a8799082d626137e60fb27f5b81476f3a7a8d57e881adf6e17b6865 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_14ad9a0e8a8799082d626137e60fb27f5b81476f3a7a8d57e881adf6e17b6865->enter($__internal_14ad9a0e8a8799082d626137e60fb27f5b81476f3a7a8d57e881adf6e17b6865_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_1bd4634f6352b665eb52fb5650783fc09a35ac57faa3fed9bb0de2f9e9aeb2e6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1bd4634f6352b665eb52fb5650783fc09a35ac57faa3fed9bb0de2f9e9aeb2e6->enter($__internal_1bd4634f6352b665eb52fb5650783fc09a35ac57faa3fed9bb0de2f9e9aeb2e6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["location"]) || array_key_exists("location", $context) ? $context["location"] : (function () { throw new Twig_Error_Runtime('Variable "location" does not exist.', 8, $this->getSourceContext()); })()), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["location"]) || array_key_exists("location", $context) ? $context["location"] : (function () { throw new Twig_Error_Runtime('Variable "location" does not exist.', 8, $this->getSourceContext()); })()), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_1bd4634f6352b665eb52fb5650783fc09a35ac57faa3fed9bb0de2f9e9aeb2e6->leave($__internal_1bd4634f6352b665eb52fb5650783fc09a35ac57faa3fed9bb0de2f9e9aeb2e6_prof);

        
        $__internal_14ad9a0e8a8799082d626137e60fb27f5b81476f3a7a8d57e881adf6e17b6865->leave($__internal_14ad9a0e8a8799082d626137e60fb27f5b81476f3a7a8d57e881adf6e17b6865_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "@WebProfiler/Profiler/toolbar_redirect.html.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\toolbar_redirect.html.twig");
    }
}
