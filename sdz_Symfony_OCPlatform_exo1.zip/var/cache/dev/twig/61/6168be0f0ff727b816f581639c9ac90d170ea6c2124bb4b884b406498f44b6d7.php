<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_858215bfe5f19350c56d76fb3e0243da7e615f3ffb6afad28b4ee1efdd8c3b31 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9c36741802438de0e0c2f617e81fe8750a86e06dca84cfec8b3e99bb09c1d2c7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9c36741802438de0e0c2f617e81fe8750a86e06dca84cfec8b3e99bb09c1d2c7->enter($__internal_9c36741802438de0e0c2f617e81fe8750a86e06dca84cfec8b3e99bb09c1d2c7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        $__internal_76e48bfa67e651568d9c15b26de409e005163e5011ddf24559077f6dc82bb17b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_76e48bfa67e651568d9c15b26de409e005163e5011ddf24559077f6dc82bb17b->enter($__internal_76e48bfa67e651568d9c15b26de409e005163e5011ddf24559077f6dc82bb17b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_9c36741802438de0e0c2f617e81fe8750a86e06dca84cfec8b3e99bb09c1d2c7->leave($__internal_9c36741802438de0e0c2f617e81fe8750a86e06dca84cfec8b3e99bb09c1d2c7_prof);

        
        $__internal_76e48bfa67e651568d9c15b26de409e005163e5011ddf24559077f6dc82bb17b->leave($__internal_76e48bfa67e651568d9c15b26de409e005163e5011ddf24559077f6dc82bb17b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
", "@Framework/Form/textarea_widget.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\textarea_widget.html.php");
    }
}
