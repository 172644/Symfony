<?php

/* @OCPlatform/Advert/add.html.twig */
class __TwigTemplate_e309c4a3f65e0af4431e0458a1c3eacf38f6905a73802bb3c30e3f2a8fee17e2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("OCPlatformBundle::layout.html.twig", "@OCPlatform/Advert/add.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "OCPlatformBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0a1da8d5339427566dea1380869b2ecf7fd3e1644a03d5635d8ec322d2d0de5c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0a1da8d5339427566dea1380869b2ecf7fd3e1644a03d5635d8ec322d2d0de5c->enter($__internal_0a1da8d5339427566dea1380869b2ecf7fd3e1644a03d5635d8ec322d2d0de5c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@OCPlatform/Advert/add.html.twig"));

        $__internal_34ba505442a655278fc435517b926ca8f35db208c642fbb0f05f9c576cd2f68b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_34ba505442a655278fc435517b926ca8f35db208c642fbb0f05f9c576cd2f68b->enter($__internal_34ba505442a655278fc435517b926ca8f35db208c642fbb0f05f9c576cd2f68b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@OCPlatform/Advert/add.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0a1da8d5339427566dea1380869b2ecf7fd3e1644a03d5635d8ec322d2d0de5c->leave($__internal_0a1da8d5339427566dea1380869b2ecf7fd3e1644a03d5635d8ec322d2d0de5c_prof);

        
        $__internal_34ba505442a655278fc435517b926ca8f35db208c642fbb0f05f9c576cd2f68b->leave($__internal_34ba505442a655278fc435517b926ca8f35db208c642fbb0f05f9c576cd2f68b_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_54163362117b640e533ba1b262eca4f364ec2ec2a679d4f85f980e2b2c4832f3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_54163362117b640e533ba1b262eca4f364ec2ec2a679d4f85f980e2b2c4832f3->enter($__internal_54163362117b640e533ba1b262eca4f364ec2ec2a679d4f85f980e2b2c4832f3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_b1db080511495f809d7f581a2265b1525c960f09bd9e6a0d481a7545f276f358 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b1db080511495f809d7f581a2265b1525c960f09bd9e6a0d481a7545f276f358->enter($__internal_b1db080511495f809d7f581a2265b1525c960f09bd9e6a0d481a7545f276f358_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
    <h2>Ajouter une annonce</h2>

    ";
        // line 7
        echo twig_include($this->env, $context, "OCPlatformBundle:Advert:form.html.twig");
        echo "

    <p>
        Attention : cette annonce sera ajoutée directement
        sur la page d'accueil après validation du formulaire.
    </p>

";
        
        $__internal_b1db080511495f809d7f581a2265b1525c960f09bd9e6a0d481a7545f276f358->leave($__internal_b1db080511495f809d7f581a2265b1525c960f09bd9e6a0d481a7545f276f358_prof);

        
        $__internal_54163362117b640e533ba1b262eca4f364ec2ec2a679d4f85f980e2b2c4832f3->leave($__internal_54163362117b640e533ba1b262eca4f364ec2ec2a679d4f85f980e2b2c4832f3_prof);

    }

    public function getTemplateName()
    {
        return "@OCPlatform/Advert/add.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  54 => 7,  49 => 4,  40 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"OCPlatformBundle::layout.html.twig\" %}

{% block body %}

    <h2>Ajouter une annonce</h2>

    {{ include(\"OCPlatformBundle:Advert:form.html.twig\") }}

    <p>
        Attention : cette annonce sera ajoutée directement
        sur la page d'accueil après validation du formulaire.
    </p>

{% endblock %}", "@OCPlatform/Advert/add.html.twig", "C:\\wamp64\\www\\Symfony\\src\\OC\\PlatformBundle\\Resources\\views\\Advert\\add.html.twig");
    }
}
