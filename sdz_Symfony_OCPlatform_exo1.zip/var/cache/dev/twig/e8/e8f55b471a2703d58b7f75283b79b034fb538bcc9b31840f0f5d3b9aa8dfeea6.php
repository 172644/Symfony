<?php

/* @Framework/FormTable/form_widget_compound.html.php */
class __TwigTemplate_c41acbaef3be9b26351e2ff5951bd9a24eb8bafe5e126d76a304e5850beff30f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319777396a997ac077ff31b102eeb64f5fdc23ecc52563c160163114dac9b801 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_319777396a997ac077ff31b102eeb64f5fdc23ecc52563c160163114dac9b801->enter($__internal_319777396a997ac077ff31b102eeb64f5fdc23ecc52563c160163114dac9b801_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        $__internal_7c1109746c4954d9c638c16eb5a251364d356a34da93b6258934a701bad9bfb2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7c1109746c4954d9c638c16eb5a251364d356a34da93b6258934a701bad9bfb2->enter($__internal_7c1109746c4954d9c638c16eb5a251364d356a34da93b6258934a701bad9bfb2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        // line 1
        echo "<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form) ?>
        </td>
    </tr>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</table>
";
        
        $__internal_319777396a997ac077ff31b102eeb64f5fdc23ecc52563c160163114dac9b801->leave($__internal_319777396a997ac077ff31b102eeb64f5fdc23ecc52563c160163114dac9b801_prof);

        
        $__internal_7c1109746c4954d9c638c16eb5a251364d356a34da93b6258934a701bad9bfb2->leave($__internal_7c1109746c4954d9c638c16eb5a251364d356a34da93b6258934a701bad9bfb2_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form) ?>
        </td>
    </tr>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</table>
", "@Framework/FormTable/form_widget_compound.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\form_widget_compound.html.php");
    }
}
