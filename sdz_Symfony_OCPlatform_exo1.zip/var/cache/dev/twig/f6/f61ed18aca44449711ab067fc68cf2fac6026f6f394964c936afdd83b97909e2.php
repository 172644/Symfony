<?php

/* @Framework/Form/form_widget_compound.html.php */
class __TwigTemplate_be0d60ce707f5e4d64346e23d8b9c94ef9394cfddf208db6c02933c95b47552b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0450b3372da9016a0c977acb2cd628ef1c8cd933e87300a1e56e5095572d941c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0450b3372da9016a0c977acb2cd628ef1c8cd933e87300a1e56e5095572d941c->enter($__internal_0450b3372da9016a0c977acb2cd628ef1c8cd933e87300a1e56e5095572d941c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        $__internal_80030b887f758e331d289c655694a7d2fd551787fe2dfc3ae881067470f1ab84 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_80030b887f758e331d289c655694a7d2fd551787fe2dfc3ae881067470f1ab84->enter($__internal_80030b887f758e331d289c655694a7d2fd551787fe2dfc3ae881067470f1ab84_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
";
        
        $__internal_0450b3372da9016a0c977acb2cd628ef1c8cd933e87300a1e56e5095572d941c->leave($__internal_0450b3372da9016a0c977acb2cd628ef1c8cd933e87300a1e56e5095572d941c_prof);

        
        $__internal_80030b887f758e331d289c655694a7d2fd551787fe2dfc3ae881067470f1ab84->leave($__internal_80030b887f758e331d289c655694a7d2fd551787fe2dfc3ae881067470f1ab84_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
", "@Framework/Form/form_widget_compound.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_widget_compound.html.php");
    }
}
