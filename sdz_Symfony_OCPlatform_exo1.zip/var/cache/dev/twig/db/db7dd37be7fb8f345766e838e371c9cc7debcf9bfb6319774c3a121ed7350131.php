<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_53594537fe4ed789fa21af14d493778572e9fedcee9c676bc5acdc40fabdbcff extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_66c71de8e2eb27f79d46da0866b9ff67256491ecccac8b2201f09ef2580ce1e0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_66c71de8e2eb27f79d46da0866b9ff67256491ecccac8b2201f09ef2580ce1e0->enter($__internal_66c71de8e2eb27f79d46da0866b9ff67256491ecccac8b2201f09ef2580ce1e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        $__internal_fe70ff1588c3b4849c17f88373808e021ded61eaf70b2b976300beec1649b0bb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fe70ff1588c3b4849c17f88373808e021ded61eaf70b2b976300beec1649b0bb->enter($__internal_fe70ff1588c3b4849c17f88373808e021ded61eaf70b2b976300beec1649b0bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_66c71de8e2eb27f79d46da0866b9ff67256491ecccac8b2201f09ef2580ce1e0->leave($__internal_66c71de8e2eb27f79d46da0866b9ff67256491ecccac8b2201f09ef2580ce1e0_prof);

        
        $__internal_fe70ff1588c3b4849c17f88373808e021ded61eaf70b2b976300beec1649b0bb->leave($__internal_fe70ff1588c3b4849c17f88373808e021ded61eaf70b2b976300beec1649b0bb_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_label.html.php");
    }
}
