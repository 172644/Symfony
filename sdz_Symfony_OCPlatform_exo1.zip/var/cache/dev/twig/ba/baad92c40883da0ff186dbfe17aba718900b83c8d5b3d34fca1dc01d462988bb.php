<?php

/* OCPlatformBundle:Advert:view.html.twig */
class __TwigTemplate_838710d8b27a4e8082cc9b02ff42656d087c7faef10e13b85d8fec76713fdb75 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("OCPlatformBundle::layout.html.twig", "OCPlatformBundle:Advert:view.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'ocplatform_body' => array($this, 'block_ocplatform_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "OCPlatformBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f782d902b3c1880a411e6fb310098a8a7560742ba081c752867d29e8cc76dcaa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f782d902b3c1880a411e6fb310098a8a7560742ba081c752867d29e8cc76dcaa->enter($__internal_f782d902b3c1880a411e6fb310098a8a7560742ba081c752867d29e8cc76dcaa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:view.html.twig"));

        $__internal_5c357578c1f55fa6393a0f0acc2f9ae79f9f471a03ded3d8ff33d07fdc709da2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5c357578c1f55fa6393a0f0acc2f9ae79f9f471a03ded3d8ff33d07fdc709da2->enter($__internal_5c357578c1f55fa6393a0f0acc2f9ae79f9f471a03ded3d8ff33d07fdc709da2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:view.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f782d902b3c1880a411e6fb310098a8a7560742ba081c752867d29e8cc76dcaa->leave($__internal_f782d902b3c1880a411e6fb310098a8a7560742ba081c752867d29e8cc76dcaa_prof);

        
        $__internal_5c357578c1f55fa6393a0f0acc2f9ae79f9f471a03ded3d8ff33d07fdc709da2->leave($__internal_5c357578c1f55fa6393a0f0acc2f9ae79f9f471a03ded3d8ff33d07fdc709da2_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_fa0e9e72eeab3c63745d1d3a168b49ede33c2ef32b1883566c8760f5c6552e30 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fa0e9e72eeab3c63745d1d3a168b49ede33c2ef32b1883566c8760f5c6552e30->enter($__internal_fa0e9e72eeab3c63745d1d3a168b49ede33c2ef32b1883566c8760f5c6552e30_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_3a0f5c8e097964f553d04fbfd5d7555bf64fc7367fe275246c2b30212764a795 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3a0f5c8e097964f553d04fbfd5d7555bf64fc7367fe275246c2b30212764a795->enter($__internal_3a0f5c8e097964f553d04fbfd5d7555bf64fc7367fe275246c2b30212764a795_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "    Lecture d'une annonce - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
        
        $__internal_3a0f5c8e097964f553d04fbfd5d7555bf64fc7367fe275246c2b30212764a795->leave($__internal_3a0f5c8e097964f553d04fbfd5d7555bf64fc7367fe275246c2b30212764a795_prof);

        
        $__internal_fa0e9e72eeab3c63745d1d3a168b49ede33c2ef32b1883566c8760f5c6552e30->leave($__internal_fa0e9e72eeab3c63745d1d3a168b49ede33c2ef32b1883566c8760f5c6552e30_prof);

    }

    // line 7
    public function block_ocplatform_body($context, array $blocks = array())
    {
        $__internal_70a94a1319b786a237a94d354923eff11f457122df58174e23217712d4e4d02d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_70a94a1319b786a237a94d354923eff11f457122df58174e23217712d4e4d02d->enter($__internal_70a94a1319b786a237a94d354923eff11f457122df58174e23217712d4e4d02d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        $__internal_ea8e6990ba8cd975125516e11e8147817e9a80ce0e082089862b7effee3c630f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ea8e6990ba8cd975125516e11e8147817e9a80ce0e082089862b7effee3c630f->enter($__internal_ea8e6990ba8cd975125516e11e8147817e9a80ce0e082089862b7effee3c630f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        // line 8
        echo "    ";
        if ( !(null === twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["advert"]) || array_key_exists("advert", $context) ? $context["advert"] : (function () { throw new Twig_Error_Runtime('Variable "advert" does not exist.', 8, $this->getSourceContext()); })()), "image", array()))) {
            // line 9
            echo "        <img src=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["advert"]) || array_key_exists("advert", $context) ? $context["advert"] : (function () { throw new Twig_Error_Runtime('Variable "advert" does not exist.', 9, $this->getSourceContext()); })()), "image", array()), "url", array()), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["advert"]) || array_key_exists("advert", $context) ? $context["advert"] : (function () { throw new Twig_Error_Runtime('Variable "advert" does not exist.', 9, $this->getSourceContext()); })()), "image", array()), "alt", array()), "html", null, true);
            echo "\">
    ";
        }
        // line 11
        echo "    <h2>";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["advert"]) || array_key_exists("advert", $context) ? $context["advert"] : (function () { throw new Twig_Error_Runtime('Variable "advert" does not exist.', 11, $this->getSourceContext()); })()), "title", array()), "html", null, true);
        echo "</h2>
    <i>Par ";
        // line 12
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["advert"]) || array_key_exists("advert", $context) ? $context["advert"] : (function () { throw new Twig_Error_Runtime('Variable "advert" does not exist.', 12, $this->getSourceContext()); })()), "author", array()), "html", null, true);
        echo ", le ";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["advert"]) || array_key_exists("advert", $context) ? $context["advert"] : (function () { throw new Twig_Error_Runtime('Variable "advert" does not exist.', 12, $this->getSourceContext()); })()), "date", array()), "d/m/Y"), "html", null, true);
        echo "</i>

    <div class=\"well\">
        ";
        // line 15
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["advert"]) || array_key_exists("advert", $context) ? $context["advert"] : (function () { throw new Twig_Error_Runtime('Variable "advert" does not exist.', 15, $this->getSourceContext()); })()), "content", array()), "html", null, true);
        echo "
    </div>

    <p>
        <a href=\"";
        // line 19
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("oc_platform_home");
        echo "\" class=\"btn btn-default\">
            <i class=\"glyphicon glyphicon-chevron-left\"></i>
            Retour à la liste
        </a>
        <a href=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("oc_platform_edit", array("id" => twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["advert"]) || array_key_exists("advert", $context) ? $context["advert"] : (function () { throw new Twig_Error_Runtime('Variable "advert" does not exist.', 23, $this->getSourceContext()); })()), "id", array()))), "html", null, true);
        echo "\" class=\"btn btn-default\">
            <i class=\"glyphicon glyphicon-edit\"></i>
            Modifier l'annonce
        </a>
        <a href=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("oc_platform_delete", array("id" => twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["advert"]) || array_key_exists("advert", $context) ? $context["advert"] : (function () { throw new Twig_Error_Runtime('Variable "advert" does not exist.', 27, $this->getSourceContext()); })()), "id", array()))), "html", null, true);
        echo "\" class=\"btn btn-danger\">
            <i class=\"glyphicon glyphicon-trash\"></i>
            Supprimer l'annonce
        </a>
    </p>
    ";
        // line 32
        if ( !twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["advert"]) || array_key_exists("advert", $context) ? $context["advert"] : (function () { throw new Twig_Error_Runtime('Variable "advert" does not exist.', 32, $this->getSourceContext()); })()), "categories", array()), "empty", array())) {
            // line 33
            echo "        <p>
            Cette annonce est parue dans les catégories suivantes :
            ";
            // line 35
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["advert"]) || array_key_exists("advert", $context) ? $context["advert"] : (function () { throw new Twig_Error_Runtime('Variable "advert" does not exist.', 35, $this->getSourceContext()); })()), "categories", array()));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
                // line 36
                echo "                ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["category"], "name", array()), "html", null, true);
                if ( !twig_get_attribute($this->env, $this->getSourceContext(), $context["loop"], "last", array())) {
                    echo ", ";
                }
                // line 37
                echo "            ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 38
            echo "        </p>
    ";
        }
        // line 40
        echo "    ";
        if (array_key_exists("listApplications", $context)) {
            // line 41
            echo "        <ul>
            ";
            // line 42
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["listApplications"]) || array_key_exists("listApplications", $context) ? $context["listApplications"] : (function () { throw new Twig_Error_Runtime('Variable "listApplications" does not exist.', 42, $this->getSourceContext()); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["app"]) {
                // line 43
                echo "                <li>";
                echo twig_escape_filter($this->env, (((((twig_get_attribute($this->env, $this->getSourceContext(), $context["app"], "author", array()) . " - ") . twig_get_attribute($this->env, $this->getSourceContext(), $context["app"], "content", array())) . "(") . twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["app"], "date", array()), "H:i m/d/Y")) . ")"), "html", null, true);
                echo "</li>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['app'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 45
            echo "        </ul>
    ";
        }
        // line 47
        echo "    ";
        if (array_key_exists("listAdvertSkill", $context)) {
            // line 48
            echo "        <ul>
            ";
            // line 49
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["listAdvertSkill"]) || array_key_exists("listAdvertSkill", $context) ? $context["listAdvertSkill"] : (function () { throw new Twig_Error_Runtime('Variable "listAdvertSkill" does not exist.', 49, $this->getSourceContext()); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["advertSkill"]) {
                // line 50
                echo "                <li>";
                echo twig_escape_filter($this->env, ((twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), $context["advertSkill"], "Skill", array()), "name", array()) . " : ") . twig_get_attribute($this->env, $this->getSourceContext(), $context["advertSkill"], "level", array())), "html", null, true);
                echo "</li>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['advertSkill'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 52
            echo "        </ul>
    ";
        }
        // line 54
        echo "    ";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "H:i m/d/Y", twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 54, $this->getSourceContext()); })()), "request", array()), "headers", array()), "get", array(0 => "timezone"), "method")), "html", null, true);
        echo "
    <br />
    ";
        // line 56
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "H:i m/d/Y", "Europe/Paris"), "html", null, true);
        echo "
    <br />
    ";
        // line 58
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "H:i m/d/Y"), "html", null, true);
        echo "
    <br />
    ";
        // line 60
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 60, $this->getSourceContext()); })()), "request", array()), "headers", array()), "get", array(0 => "timezone"), "method"), "html", null, true);
        echo "
    <br />
    ";
        // line 62
        echo twig_escape_filter($this->env, (isset($context["date"]) || array_key_exists("date", $context) ? $context["date"] : (function () { throw new Twig_Error_Runtime('Variable "date" does not exist.', 62, $this->getSourceContext()); })()), "html", null, true);
        echo "


";
        
        $__internal_ea8e6990ba8cd975125516e11e8147817e9a80ce0e082089862b7effee3c630f->leave($__internal_ea8e6990ba8cd975125516e11e8147817e9a80ce0e082089862b7effee3c630f_prof);

        
        $__internal_70a94a1319b786a237a94d354923eff11f457122df58174e23217712d4e4d02d->leave($__internal_70a94a1319b786a237a94d354923eff11f457122df58174e23217712d4e4d02d_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Advert:view.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  239 => 62,  234 => 60,  229 => 58,  224 => 56,  218 => 54,  214 => 52,  205 => 50,  201 => 49,  198 => 48,  195 => 47,  191 => 45,  182 => 43,  178 => 42,  175 => 41,  172 => 40,  168 => 38,  154 => 37,  148 => 36,  131 => 35,  127 => 33,  125 => 32,  117 => 27,  110 => 23,  103 => 19,  96 => 15,  88 => 12,  83 => 11,  75 => 9,  72 => 8,  63 => 7,  50 => 4,  41 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"OCPlatformBundle::layout.html.twig\" %}

{% block title %}
    Lecture d'une annonce - {{ parent() }}
{% endblock %}

{% block ocplatform_body %}
    {% if advert.image is not null %}
        <img src=\"{{ advert.image.url }}\" alt=\"{{ advert.image.alt }}\">
    {% endif %}
    <h2>{{ advert.title }}</h2>
    <i>Par {{ advert.author }}, le {{ advert.date|date('d/m/Y') }}</i>

    <div class=\"well\">
        {{ advert.content }}
    </div>

    <p>
        <a href=\"{{ path('oc_platform_home') }}\" class=\"btn btn-default\">
            <i class=\"glyphicon glyphicon-chevron-left\"></i>
            Retour à la liste
        </a>
        <a href=\"{{ path('oc_platform_edit', {'id': advert.id}) }}\" class=\"btn btn-default\">
            <i class=\"glyphicon glyphicon-edit\"></i>
            Modifier l'annonce
        </a>
        <a href=\"{{ path('oc_platform_delete', {'id': advert.id}) }}\" class=\"btn btn-danger\">
            <i class=\"glyphicon glyphicon-trash\"></i>
            Supprimer l'annonce
        </a>
    </p>
    {% if not advert.categories.empty %}
        <p>
            Cette annonce est parue dans les catégories suivantes :
            {% for category in advert.categories %}
                {{ category.name }}{% if not loop.last %}, {% endif %}
            {% endfor %}
        </p>
    {% endif %}
    {% if listApplications is defined %}
        <ul>
            {% for app in listApplications %}
                <li>{{ app.author ~ \" - \" ~ app.content ~ \"(\" ~ app.date|date(\"H:i m/d/Y\") ~ \")\" }}</li>
            {% endfor %}
        </ul>
    {% endif %}
    {% if listAdvertSkill is defined %}
        <ul>
            {% for advertSkill in listAdvertSkill %}
                <li>{{ advertSkill.Skill.name ~ ' : ' ~ advertSkill.level}}</li>
            {% endfor %}
        </ul>
    {% endif %}
    {{  \"now\"|date(\"H:i m/d/Y\", app.request.headers.get('timezone')) }}
    <br />
    {{  \"now\"|date(\"H:i m/d/Y\", \"Europe/Paris\") }}
    <br />
    {{  \"now\"|date(\"H:i m/d/Y\") }}
    <br />
    {{ app.request.headers.get('timezone') }}
    <br />
    {{ date }}


{% endblock %}", "OCPlatformBundle:Advert:view.html.twig", "C:\\wamp64\\www\\Symfony\\src\\OC\\PlatformBundle\\Resources\\views\\Advert\\view.html.twig");
    }
}
