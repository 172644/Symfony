<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_575c36cb41d269f769d7796b935e173628366b29f83ae45441bad56796df1439 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ee0b889b412c820380e10deea822c00eaaef628e1f94acb11d0d03253fb751c0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ee0b889b412c820380e10deea822c00eaaef628e1f94acb11d0d03253fb751c0->enter($__internal_ee0b889b412c820380e10deea822c00eaaef628e1f94acb11d0d03253fb751c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        $__internal_fb700d27cc77a7d6fa6528d60b7cfc3f238db401a2ff68c17d674fe28bf61530 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fb700d27cc77a7d6fa6528d60b7cfc3f238db401a2ff68c17d674fe28bf61530->enter($__internal_fb700d27cc77a7d6fa6528d60b7cfc3f238db401a2ff68c17d674fe28bf61530_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_ee0b889b412c820380e10deea822c00eaaef628e1f94acb11d0d03253fb751c0->leave($__internal_ee0b889b412c820380e10deea822c00eaaef628e1f94acb11d0d03253fb751c0_prof);

        
        $__internal_fb700d27cc77a7d6fa6528d60b7cfc3f238db401a2ff68c17d674fe28bf61530->leave($__internal_fb700d27cc77a7d6fa6528d60b7cfc3f238db401a2ff68c17d674fe28bf61530_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/button_row.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\button_row.html.php");
    }
}
