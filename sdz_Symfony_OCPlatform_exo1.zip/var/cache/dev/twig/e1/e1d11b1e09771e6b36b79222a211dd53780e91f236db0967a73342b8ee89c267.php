<?php

/* @Twig/Exception/error.json.twig */
class __TwigTemplate_3758b8b8c926463340c97d3be208cad114eaebfb82e61d5742a08f840529a23e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_589340183280f0ad32c8c6b403e0d546d614986b18f9a0d6dac759e7aa050a53 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_589340183280f0ad32c8c6b403e0d546d614986b18f9a0d6dac759e7aa050a53->enter($__internal_589340183280f0ad32c8c6b403e0d546d614986b18f9a0d6dac759e7aa050a53_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.json.twig"));

        $__internal_3de14475020357fa0ffb15c13aaa26b98c24e0d43007f90c8c7d27fc5c908e6f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3de14475020357fa0ffb15c13aaa26b98c24e0d43007f90c8c7d27fc5c908e6f->enter($__internal_3de14475020357fa0ffb15c13aaa26b98c24e0d43007f90c8c7d27fc5c908e6f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.json.twig"));

        // line 1
        echo json_encode(array("error" => array("code" => (isset($context["status_code"]) || array_key_exists("status_code", $context) ? $context["status_code"] : (function () { throw new Twig_Error_Runtime('Variable "status_code" does not exist.', 1, $this->getSourceContext()); })()), "message" => (isset($context["status_text"]) || array_key_exists("status_text", $context) ? $context["status_text"] : (function () { throw new Twig_Error_Runtime('Variable "status_text" does not exist.', 1, $this->getSourceContext()); })()))));
        echo "
";
        
        $__internal_589340183280f0ad32c8c6b403e0d546d614986b18f9a0d6dac759e7aa050a53->leave($__internal_589340183280f0ad32c8c6b403e0d546d614986b18f9a0d6dac759e7aa050a53_prof);

        
        $__internal_3de14475020357fa0ffb15c13aaa26b98c24e0d43007f90c8c7d27fc5c908e6f->leave($__internal_3de14475020357fa0ffb15c13aaa26b98c24e0d43007f90c8c7d27fc5c908e6f_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}
", "@Twig/Exception/error.json.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.json.twig");
    }
}
