<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_8933835b13dfb9957e9993c0fe72b847fcd76fe690ec846d32d16396ea07f185 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bf9c8ca3e9040af4592b4a1c603da87e1540807584e2441e96995161cbc7f12f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bf9c8ca3e9040af4592b4a1c603da87e1540807584e2441e96995161cbc7f12f->enter($__internal_bf9c8ca3e9040af4592b4a1c603da87e1540807584e2441e96995161cbc7f12f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        $__internal_f9dbe5ebeca598f2dadb5717984be69b7856e3344fd1439d2244f8d962498892 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f9dbe5ebeca598f2dadb5717984be69b7856e3344fd1439d2244f8d962498892->enter($__internal_f9dbe5ebeca598f2dadb5717984be69b7856e3344fd1439d2244f8d962498892_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_bf9c8ca3e9040af4592b4a1c603da87e1540807584e2441e96995161cbc7f12f->leave($__internal_bf9c8ca3e9040af4592b4a1c603da87e1540807584e2441e96995161cbc7f12f_prof);

        
        $__internal_f9dbe5ebeca598f2dadb5717984be69b7856e3344fd1439d2244f8d962498892->leave($__internal_f9dbe5ebeca598f2dadb5717984be69b7856e3344fd1439d2244f8d962498892_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/button_row.html.php", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_row.html.php");
    }
}
