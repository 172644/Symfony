<?php

/* ::layout.html.twig */
class __TwigTemplate_30386d0a857e1e56b017ef54a8a56e176e0ba5b5fa4d078ac1b6ae5706957ad9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_32bd5da02356f826fac523e4fd137bc082edb0c52795b18e29b6b23b19425e69 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_32bd5da02356f826fac523e4fd137bc082edb0c52795b18e29b6b23b19425e69->enter($__internal_32bd5da02356f826fac523e4fd137bc082edb0c52795b18e29b6b23b19425e69_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::layout.html.twig"));

        $__internal_d66cedb36debad764f7b013bc28181946c2e4aca09fdf893e1f22070cae42f97 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d66cedb36debad764f7b013bc28181946c2e4aca09fdf893e1f22070cae42f97->enter($__internal_d66cedb36debad764f7b013bc28181946c2e4aca09fdf893e1f22070cae42f97_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">

    <title>";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

    ";
        // line 9
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 13
        echo "</head>

<body>
<div class=\"container\">
    <div id=\"header\" class=\"jumbotron\">
        <h1>Ma plateforme d'annonces</h1>
        <p>
            Ce projet est propulsé par Symfony,
            et construit grâce au MOOC OpenClassrooms et SensioLabs.
        </p>
        <p>
            <a class=\"btn btn-primary btn-lg\" href=\"https://openclassrooms.com/courses/developpez-votre-site-web-avec-le-framework-symfony2\">
                Participer au MOOC »
            </a>
        </p>
    </div>

    <div class=\"row\">
        <div id=\"menu\" class=\"col-md-3\">
            <h3>Menu</h3>
            <ul class=\"nav nav-pills nav-stacked\">
                <li><a href=\"";
        // line 34
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("oc_platform_home");
        echo "\">Accueil</a></li>
                <li><a href=\"";
        // line 35
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("oc_platform_add");
        echo "\">Ajouter une annonce</a></li>
            </ul>

            <h4>Dernières annonces</h4>
            ";
        // line 39
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("OCPlatformBundle:Advert:menu", array("limit" => 3)));
        echo "
        </div>
        <div id=\"content\" class=\"col-md-9\">
            ";
        // line 42
        $this->displayBlock('body', $context, $blocks);
        // line 44
        echo "        </div>
    </div>

    <hr>

    <footer>
        <p>The sky's the limit © ";
        // line 50
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y"), "html", null, true);
        echo " and beyond.</p>
    </footer>
</div>

";
        // line 54
        $this->displayBlock('javascripts', $context, $blocks);
        // line 59
        echo "
</body>
</html>";
        
        $__internal_32bd5da02356f826fac523e4fd137bc082edb0c52795b18e29b6b23b19425e69->leave($__internal_32bd5da02356f826fac523e4fd137bc082edb0c52795b18e29b6b23b19425e69_prof);

        
        $__internal_d66cedb36debad764f7b013bc28181946c2e4aca09fdf893e1f22070cae42f97->leave($__internal_d66cedb36debad764f7b013bc28181946c2e4aca09fdf893e1f22070cae42f97_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_8cb75c6c654df6e5a29da9a8fc47e2361e47e05d26bb6623afa175a2930e7165 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8cb75c6c654df6e5a29da9a8fc47e2361e47e05d26bb6623afa175a2930e7165->enter($__internal_8cb75c6c654df6e5a29da9a8fc47e2361e47e05d26bb6623afa175a2930e7165_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_89d230318d12d0caff1f2a0bfa07be532e2b2c34bb46c62475c6b4187a047fc5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_89d230318d12d0caff1f2a0bfa07be532e2b2c34bb46c62475c6b4187a047fc5->enter($__internal_89d230318d12d0caff1f2a0bfa07be532e2b2c34bb46c62475c6b4187a047fc5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "OC Plateforme";
        
        $__internal_89d230318d12d0caff1f2a0bfa07be532e2b2c34bb46c62475c6b4187a047fc5->leave($__internal_89d230318d12d0caff1f2a0bfa07be532e2b2c34bb46c62475c6b4187a047fc5_prof);

        
        $__internal_8cb75c6c654df6e5a29da9a8fc47e2361e47e05d26bb6623afa175a2930e7165->leave($__internal_8cb75c6c654df6e5a29da9a8fc47e2361e47e05d26bb6623afa175a2930e7165_prof);

    }

    // line 9
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_c712674485b60cdccbdfaefe783347bcc1e72ad11815a61236938779399301b9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c712674485b60cdccbdfaefe783347bcc1e72ad11815a61236938779399301b9->enter($__internal_c712674485b60cdccbdfaefe783347bcc1e72ad11815a61236938779399301b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_3a300f17db387292e0e8f1c7732cbf58c1164bf2d84df48f2b9563f963bdf224 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3a300f17db387292e0e8f1c7732cbf58c1164bf2d84df48f2b9563f963bdf224->enter($__internal_3a300f17db387292e0e8f1c7732cbf58c1164bf2d84df48f2b9563f963bdf224_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 10
        echo "        ";
        // line 11
        echo "        <link rel=\"stylesheet\" href=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css\">
    ";
        
        $__internal_3a300f17db387292e0e8f1c7732cbf58c1164bf2d84df48f2b9563f963bdf224->leave($__internal_3a300f17db387292e0e8f1c7732cbf58c1164bf2d84df48f2b9563f963bdf224_prof);

        
        $__internal_c712674485b60cdccbdfaefe783347bcc1e72ad11815a61236938779399301b9->leave($__internal_c712674485b60cdccbdfaefe783347bcc1e72ad11815a61236938779399301b9_prof);

    }

    // line 42
    public function block_body($context, array $blocks = array())
    {
        $__internal_a335b3de8d2a9a48abba684bfd6abe32a94435969698d5c3bbb33615c86dc703 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a335b3de8d2a9a48abba684bfd6abe32a94435969698d5c3bbb33615c86dc703->enter($__internal_a335b3de8d2a9a48abba684bfd6abe32a94435969698d5c3bbb33615c86dc703_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_3d626252303e25410b8ddd187736f5421eb35aac0f7e1f15ef19a7067a7f9bcb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3d626252303e25410b8ddd187736f5421eb35aac0f7e1f15ef19a7067a7f9bcb->enter($__internal_3d626252303e25410b8ddd187736f5421eb35aac0f7e1f15ef19a7067a7f9bcb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 43
        echo "            ";
        
        $__internal_3d626252303e25410b8ddd187736f5421eb35aac0f7e1f15ef19a7067a7f9bcb->leave($__internal_3d626252303e25410b8ddd187736f5421eb35aac0f7e1f15ef19a7067a7f9bcb_prof);

        
        $__internal_a335b3de8d2a9a48abba684bfd6abe32a94435969698d5c3bbb33615c86dc703->leave($__internal_a335b3de8d2a9a48abba684bfd6abe32a94435969698d5c3bbb33615c86dc703_prof);

    }

    // line 54
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_1cd25df81225d425793f85f1eb5ecccc30f03de061ed8db7e497362a344d15c0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1cd25df81225d425793f85f1eb5ecccc30f03de061ed8db7e497362a344d15c0->enter($__internal_1cd25df81225d425793f85f1eb5ecccc30f03de061ed8db7e497362a344d15c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_6df420394f00186fbae7231f63d279d179810dd7c84396f933e258b661fb4711 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6df420394f00186fbae7231f63d279d179810dd7c84396f933e258b661fb4711->enter($__internal_6df420394f00186fbae7231f63d279d179810dd7c84396f933e258b661fb4711_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 55
        echo "    ";
        // line 56
        echo "    <script src=\"//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js\"></script>
    <script src=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js\"></script>
";
        
        $__internal_6df420394f00186fbae7231f63d279d179810dd7c84396f933e258b661fb4711->leave($__internal_6df420394f00186fbae7231f63d279d179810dd7c84396f933e258b661fb4711_prof);

        
        $__internal_1cd25df81225d425793f85f1eb5ecccc30f03de061ed8db7e497362a344d15c0->leave($__internal_1cd25df81225d425793f85f1eb5ecccc30f03de061ed8db7e497362a344d15c0_prof);

    }

    public function getTemplateName()
    {
        return "::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  185 => 56,  183 => 55,  174 => 54,  164 => 43,  155 => 42,  144 => 11,  142 => 10,  133 => 9,  115 => 7,  103 => 59,  101 => 54,  94 => 50,  86 => 44,  84 => 42,  78 => 39,  71 => 35,  67 => 34,  44 => 13,  42 => 9,  37 => 7,  29 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
<head>
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">

    <title>{% block title %}OC Plateforme{% endblock %}</title>

    {% block stylesheets %}
        {# On charge le CSS de bootstrap depuis le site directement #}
        <link rel=\"stylesheet\" href=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css\">
    {% endblock %}
</head>

<body>
<div class=\"container\">
    <div id=\"header\" class=\"jumbotron\">
        <h1>Ma plateforme d'annonces</h1>
        <p>
            Ce projet est propulsé par Symfony,
            et construit grâce au MOOC OpenClassrooms et SensioLabs.
        </p>
        <p>
            <a class=\"btn btn-primary btn-lg\" href=\"https://openclassrooms.com/courses/developpez-votre-site-web-avec-le-framework-symfony2\">
                Participer au MOOC »
            </a>
        </p>
    </div>

    <div class=\"row\">
        <div id=\"menu\" class=\"col-md-3\">
            <h3>Menu</h3>
            <ul class=\"nav nav-pills nav-stacked\">
                <li><a href=\"{{ path('oc_platform_home') }}\">Accueil</a></li>
                <li><a href=\"{{ path('oc_platform_add') }}\">Ajouter une annonce</a></li>
            </ul>

            <h4>Dernières annonces</h4>
            {{ render(controller(\"OCPlatformBundle:Advert:menu\", {'limit': 3})) }}
        </div>
        <div id=\"content\" class=\"col-md-9\">
            {% block body %}
            {% endblock %}
        </div>
    </div>

    <hr>

    <footer>
        <p>The sky's the limit © {{ 'now'|date('Y') }} and beyond.</p>
    </footer>
</div>

{% block javascripts %}
    {# Ajoutez ces lignes JavaScript si vous comptez vous servir des fonctionnalités du bootstrap Twitter #}
    <script src=\"//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js\"></script>
    <script src=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js\"></script>
{% endblock %}

</body>
</html>", "::layout.html.twig", "C:\\wamp64\\www\\Symfony\\app/Resources\\views/layout.html.twig");
    }
}
