<?php

/* @Twig/Exception/exception.css.twig */
class __TwigTemplate_4262ec5998ace06bc6de4a7d33918e07c718d328a3d6d7883a55a9284d6b3fea extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_acf4bb23d894b2a032e4c2601d81baeb8c8a879875d7acd5a508dfdb846340c4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_acf4bb23d894b2a032e4c2601d81baeb8c8a879875d7acd5a508dfdb846340c4->enter($__internal_acf4bb23d894b2a032e4c2601d81baeb8c8a879875d7acd5a508dfdb846340c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.css.twig"));

        $__internal_73e1e096c562079258214e04aec73057a15943d53804b8a15ed5215178ec4732 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_73e1e096c562079258214e04aec73057a15943d53804b8a15ed5215178ec4732->enter($__internal_73e1e096c562079258214e04aec73057a15943d53804b8a15ed5215178ec4732_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_include($this->env, $context, "@Twig/Exception/exception.txt.twig", array("exception" => (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 2, $this->getSourceContext()); })())));
        echo "
*/
";
        
        $__internal_acf4bb23d894b2a032e4c2601d81baeb8c8a879875d7acd5a508dfdb846340c4->leave($__internal_acf4bb23d894b2a032e4c2601d81baeb8c8a879875d7acd5a508dfdb846340c4_prof);

        
        $__internal_73e1e096c562079258214e04aec73057a15943d53804b8a15ed5215178ec4732->leave($__internal_73e1e096c562079258214e04aec73057a15943d53804b8a15ed5215178ec4732_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ include('@Twig/Exception/exception.txt.twig', { exception: exception }) }}
*/
", "@Twig/Exception/exception.css.twig", "C:\\wamp64\\www\\Symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.css.twig");
    }
}
