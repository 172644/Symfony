<?php

/* @OCPlatform/Advert/form.html.twig */
class __TwigTemplate_f7a0ec734a2c2a41af77697143fabbdc877c021dda42b37bf796782f73e27b5f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h3>Formulaire d'annonce</h3>

";
        // line 5
        echo "<div class=\"well\">
    Ici se trouvera le formulaire.
</div>";
    }

    public function getTemplateName()
    {
        return "@OCPlatform/Advert/form.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 5,  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@OCPlatform/Advert/form.html.twig", "C:\\wamp64\\www\\Symfony\\src\\OC\\PlatformBundle\\Resources\\views\\Advert\\form.html.twig");
    }
}
