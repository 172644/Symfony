<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appProdProjectContainerUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $trimmedPathinfo = rtrim($pathinfo, '/');
        $context = $this->context;
        $request = $this->request;
        $requestMethod = $canonicalMethod = $context->getMethod();
        $scheme = $context->getScheme();

        if ('HEAD' === $requestMethod) {
            $canonicalMethod = 'GET';
        }


        if (0 === strpos($pathinfo, '/platform')) {
            // oc_platform_oldhome
            if ('/platform/old' === $trimmedPathinfo) {
                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'oc_platform_oldhome');
                }

                return array (  '_controller' => 'OC\\PlatformBundle\\Controller\\AdvertController::old_indexAction',  '_route' => 'oc_platform_oldhome',);
            }

            // oc_platform_home
            if (preg_match('#^/platform(?:/(?P<page>\\d*))?$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'oc_platform_home')), array (  '_controller' => 'OC\\PlatformBundle\\Controller\\AdvertController::indexAction',  'page' => 1,));
            }

            // oc_platform_view
            if (0 === strpos($pathinfo, '/platform/advert') && preg_match('#^/platform/advert/(?P<id>\\d+)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'oc_platform_view')), array (  '_controller' => 'OC\\PlatformBundle\\Controller\\AdvertController::viewAction',));
            }

            // oc_platform_add
            if ('/platform/add' === $pathinfo) {
                return array (  '_controller' => 'OC\\PlatformBundle\\Controller\\AdvertController::addAction',  '_route' => 'oc_platform_add',);
            }

            // oc_platform_edit
            if (0 === strpos($pathinfo, '/platform/edit') && preg_match('#^/platform/edit/(?P<id>\\d+)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'oc_platform_edit')), array (  '_controller' => 'OC\\PlatformBundle\\Controller\\AdvertController::editAction',));
            }

            // oc_platform_delete
            if (0 === strpos($pathinfo, '/platform/delete') && preg_match('#^/platform/delete/(?P<id>\\d+)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'oc_platform_delete')), array (  '_controller' => 'OC\\PlatformBundle\\Controller\\AdvertController::deleteAction',));
            }

            if (0 === strpos($pathinfo, '/platform/hello')) {
                // oc_platform_hello
                if ('/platform/hello' === $pathinfo) {
                    return array (  '_controller' => 'OC\\PlatformBundle\\Controller\\AdvertController::helloAction',  '_route' => 'oc_platform_hello',);
                }

                // oc_platform_hello_name
                if (preg_match('#^/platform/hello/(?P<name>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'oc_platform_hello_name')), array (  '_controller' => 'OC\\PlatformBundle\\Controller\\AdvertController::helloAction',));
                }

            }

            // oc_platform_mail
            if (0 === strpos($pathinfo, '/platform/mail') && preg_match('#^/platform/mail/(?P<email>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'oc_platform_mail')), array (  '_controller' => 'OC\\PlatformBundle\\Controller\\AdvertController::sendmailAction',));
            }

            // oc_platform_view_json
            if ('/platform/json' === $pathinfo) {
                return array (  '_controller' => 'OC\\PlatformBundle\\Controller\\AdvertController::jsonAction',  '_route' => 'oc_platform_view_json',);
            }

            if (0 === strpos($pathinfo, '/platform/session')) {
                // oc_platform_session
                if ('/platform/session' === $pathinfo) {
                    return array (  '_controller' => 'OC\\PlatformBundle\\Controller\\AdvertController::sessionAction',  '_route' => 'oc_platform_session',);
                }

                // oc_platform_session_id
                if (preg_match('#^/platform/session/(?P<advert_id>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'oc_platform_session_id')), array (  '_controller' => 'OC\\PlatformBundle\\Controller\\AdvertController::sessionAction',));
                }

            }

        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
