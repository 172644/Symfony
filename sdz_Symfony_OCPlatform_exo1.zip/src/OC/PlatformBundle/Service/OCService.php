<?php

namespace OC\PlatformBundle\Service;

class OCService
{

    public function prepareMail($email, $body, $contentType = null, $charset = null)
    {
        $message = \Swift_Message::newInstance();
        $message->setSubject("Objet");
        $message->setFrom(['172644@supinfo.com' => 'OC Platform']);
        $message->setTo($email);
        /*$message->setBody(
            $this->renderView(
            // app/Resources/views/Emails/registration.html.twig
                'OCPlatformBundle:Advert:oldindex.html.twig',
                array('nom' => $email)
            ),
            'text/html'
        );*/
        $message->setBody($body, $contentType, $charset);

        $headers = $message->getHeaders();
        $headers->addTextHeader('From', 'OCPlatform@namkin.fr');
        //$message->attach(Swift_Attachment::fromPath('my-document.pdf')->setFilename('cool.pdf'));

        return $message;
    }
}

?>