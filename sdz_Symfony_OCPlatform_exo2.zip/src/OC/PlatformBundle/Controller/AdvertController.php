<?php

namespace OC\PlatformBundle\Controller;

use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use OC\PlatformBundle\Entity\Advert;
use OC\PlatformBundle\Entity\Image;
use OC\PlatformBundle\Entity\Application;
use OC\PlatformBundle\Entity\Category;
use OC\PlatformBundle\Entity\AdvertSkill;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;

class AdvertController extends Controller
{
    public function indexAction($page = 1)
    {
        if ($page < 1)
        {
            $session = $request->getSession();
            $session->getFlashBag()->add('info', "'Page \"'.$page.'\" inexistante.'");
            return $this->redirectToRoute('oc_platform_home');
        }
        $nbPerPage = 5;
        $em = $this->getDoctrine()->getManager();
        $listAdverts = $em->getRepository('OCPlatformBundle:Advert')->getAdverts($page, $nbPerPage);

        $nbPages = ceil(count($listAdverts) / $nbPerPage);

        if ($page > $nbPages)
        {
            $session = $request->getSession();
            $session->getFlashBag()->add('info', "'Page \"'.$page.'\" inexistante.'");
            return $this->redirectToRoute('oc_platform_home');
        }

        return $this->render('OCPlatformBundle:Advert:index.html.twig', array(
            'nbPages'     => $nbPages,
            'page'        => $page,
            'listAdverts' => $listAdverts
        ));
    }
    public function purgeAction($day = 90)
    {
        $service = $this->container->get('oc_platform.service.deleteAdvert');
        $mailMsg = $service->purge($day);

        return $this->redirectToRoute('oc_platform_home');
    }

    public function viewAction($id, Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $advert = $em->getRepository('OCPlatformBundle:Advert')->find($id);

        if (null === $advert) {
            //*
            $session = $request->getSession();
            $session->getFlashBag()->add('info', "L'annonce d'id ".$id." n'existe pas.");
            return $this->redirectToRoute('oc_platform_home');//*/

            //throw new NotFoundHttpException("L'annonce d'id ".$id." n'existe pas.");
        }

        $listApplications = $em->getRepository('OCPlatformBundle:Application')->findBy(array('advert' => $advert));
        $listAdvertSkill = $em->getRepository('OCPlatformBundle:AdvertSkill')->findBy(array('advert' => $advert));

        return $this->render('OCPlatformBundle:Advert:view.html.twig', array(
            'advert'            => $advert,
            'listAdvertSkill'  => $listAdvertSkill,
            'listApplications'  => $listApplications,
            'date'              => date_default_timezone_get()
        ));
    }

    public function addAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();

        $advert = new Advert();
        $advert->setTitle('Recherche développeur Symfony.');
        $advert->setAuthor('Alexandre');
        $advert->setContent("Nous recherchons un développeur Symfony débutant sur Lyon. Blabla…");

        //*
        $application1 = new Application();
        $application1->setAuthor('Marine');
        $application1->setContent("J'ai toutes les qualités requises.");
        $application1->setAdvert($advert);

        $application2 = new Application();
        $application2->setAuthor('Pierre');
        $application2->setContent("Je suis très motivé.");
        $application2->setAdvert($advert);


        $em->persist($application1);
        $em->persist($application2);//*/


        // On récupère toutes les compétences possibles
        $listSkills = $em->getRepository('OCPlatformBundle:Skill')->findAll();

        // Pour chaque compétence
        foreach ($listSkills as $skill)
        {
            $advertSkill = new AdvertSkill();
            $advertSkill->setAdvert($advert);
            $advertSkill->setSkill($skill);
            $advertSkill->setLevel('Expert');
            $em->persist($advertSkill);
        }

        $em->persist($advert);
        $em->flush();

        if ($request->isMethod('POST')) {
            $request->getSession()->getFlashBag()->add('notice', 'Annonce bien enregistrée.');
            return $this->redirectToRoute('oc_platform_view', array('id' => $advert->getId()));
        }

        return $this->render('OCPlatformBundle:Advert:add.html.twig', array('advert' => $advert));
    }

    public function editAction($id, Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $advert = $em->getRepository('OCPlatformBundle:Advert')->find($id);

        if (null === $advert)
        {
            $session = $request->getSession();
            $session->getFlashBag()->add('info', "L'annonce d'id ".$id." n'existe pas.");
            return $this->redirectToRoute('oc_platform_home');
        }

        $listCategories = $em->getRepository('OCPlatformBundle:Category')->findAll();
        /*
        foreach ($advert->getCategories() as $category) {
          $advert->removeCategory($category);
        }
        //*/
        //*
        foreach ($listCategories as $category) {
            $advert->addCategory($category);
        }
        //*/

        $em->flush();


        if ($request->isMethod('POST')) {
            $request->getSession()->getFlashBag()->add('notice', 'Annonce bien modifiée.');
            return $this->redirectToRoute('oc_platform_view', array('id' => 5));
        }

        return $this->render('OCPlatformBundle:Advert:edit.html.twig', array(
            'advert' => $advert
        ));
    }

    public function deleteAction($id, Request $request)
    {
        $em = $this->getDoctrine()->getManager();

        $advert = $em->getRepository('OCPlatformBundle:Advert')->find($id);

        if (null === $advert) {
            $session = $request->getSession();
            $session->getFlashBag()->add('info', "L'annonce d'id ".$id." n'existe pas.");
            return $this->redirectToRoute('oc_platform_home');
        }

        // On boucle sur les catégories de l'annonce pour les supprimer
        foreach ($advert->getCategories() as $category) {
            $advert->removeCategory($category);
        }

        $em->flush();

        return $this->render('OCPlatformBundle:Advert:delete.html.twig');
    }

    public function lastAnnonceAction($limit)
    {
        $em = $this->getDoctrine()->getManager();
        $listAdverts = $em->getRepository('OCPlatformBundle:Advert')->findBy(array(), array('date' => 'DESC'), $limit);

        return $this->render('OCPlatformBundle:Advert:menu.html.twig', array(
            'listAdverts' => $listAdverts,
        ));
    }
    public function menuAction()
    {
        $listMenu = array(
            array('url' => $this->generateUrl('oc_platform_home'), 'title' => 'Accueil'),
            array('url' => $this->generateUrl('oc_platform_add'), 'title' => 'Ajouter une annonce'),
            array('url' => $this->generateUrl('oc_platform_oldhome'), 'title' => 'Old Index - [Lien dynamique avec recupération session]'),
            array('url' => $this->generateUrl('oc_platform_view_json'), 'title' => 'GetJson'),
            array('url' => $this->generateUrl('oc_platform_session'), 'title' => 'SetSession'),
            array('url' => $this->generateUrl('oc_platform_hello'), 'title' => 'Hello world')
        );

        return $this->render('OCPlatformBundle:Advert:menu.html.twig', array(
            'listMenu' => $listMenu
        ));
    }








    public function old_indexAction(Request $request)
    {
        $advert_id = 0;
        $session = $request->getSession();
        $advert_id = $session->get('advert_id');

        /*
        $url = $this->generateUrl(
            'oc_platform_view', // 1er argument : le nom de la route
            array('id' => 5)    // 2e argument : les valeurs des paramètres
        );
        return new Response("L'URL de l'annonce d'id 5 est : ".$url);//*/
        return $this->render('OCPlatformBundle:Advert:oldindex.html.twig', array('nom' => "World", 'advert_id' => $advert_id));
    }

    public function sendmailAction($email)
    {
        $service = $this->container->get('oc_platform.service.service');
        /*$message = $this->renderView(
        // app/Resources/views/Emails/registration.html.twig
            'OCPlatformBundle:Advert:oldindex.html.twig',
            array('nom' => $email)
        );*/
        $object = "plop";
        $message = "plop";
        $mailMsg = $service->prepareMail($email, $object, $message, 'text/plain');

        $this->get('mailer')->send($mailMsg);

        return new Response("<body>Hello ".$email." !</body>");
    }

    public function helloAction($name = "World")
    {
        $content = $this->get('templating')->render('OCPlatformBundle:Advert:oldindex.html.twig', array('nom' => $name));

        return new Response($content);
    }

    public function jsonAction(Request $request)
    {
        $advert_id = 0;
        $session = $request->getSession();
        $advert_id = $session->get('advert_id');

        return new JsonResponse(array('session_advert_id' => $advert_id));
    }

    public function sessionAction($advert_id = 0, Request $request)
    {
        $session = $request->getSession();
        $session_advert_id = $session->get('advert_id');

        if($advert_id != 0)
            $session->set('advert_id', $advert_id);

        return $this->redirectToRoute('oc_platform_view_json');
    }
}

?>