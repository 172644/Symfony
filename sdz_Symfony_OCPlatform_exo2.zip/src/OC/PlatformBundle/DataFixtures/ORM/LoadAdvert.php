<?php

namespace OC\PlatformBundle\DataFixtures\ORM;

use Doctrine\Common\DataFixtures\FixtureInterface;
use Doctrine\Common\Persistence\ObjectManager;
use OC\PlatformBundle\Entity\Advert;
use OC\PlatformBundle\Entity\Application;
use OC\PlatformBundle\Entity\AdvertSkill;

class LoadAdvert implements FixtureInterface
{
    // Dans l'argument de la méthode load, l'objet $manager est l'EntityManager
    public function load(ObjectManager $manager)
    {
        /////////////////////////////////////////////////////////////////////////////////////////
        $advert = new Advert();
        $advert->setTitle('Recherche développeur Symfony.');
        $advert->setAuthor('Alexandre');
        $advert->setContent("Nous recherchons un développeur Symfony débutant sur Lyon. Blabla…");

        $application1 = new Application();
        $application1->setAuthor('Marine');
        $application1->setContent("J'ai toutes les qualités requises.");
        $application1->setAdvert($advert);

        $application2 = new Application();
        $application2->setAuthor('Pierre');
        $application2->setContent("Je suis très motivé.");
        $application2->setAdvert($advert);

        $manager->persist($application1);
        $manager->persist($application2);

        $listSkills = $manager->getRepository('OCPlatformBundle:Skill')->findAll();

        foreach ($listSkills as $skill)
        {
            $advertSkill = new AdvertSkill();
            $advertSkill->setAdvert($advert);
            $advertSkill->setSkill($skill);
            $advertSkill->setLevel('Expert');
            $manager->persist($advertSkill);
        }

        $manager->persist($advert);

        /////////////////////////////////////////////////////////////////////////////////////////

        $advert = new Advert();
        $advert->setTitle('Mission de webmaster');
        $advert->setAuthor('Hugo');
        $advert->setContent("Nous recherchons un webmaster capable de maintenir notre site internet. Blabla…");

        $application1 = new Application();
        $application1->setAuthor('Jean');
        $application1->setContent("Je connais les techno web");
        $application1->setAdvert($advert);

        $manager->persist($application1);

        $listSkills = $manager->getRepository('OCPlatformBundle:Skill')->findAll();

        foreach ($listSkills as $skill)
        {
            $advertSkill = new AdvertSkill();
            $advertSkill->setAdvert($advert);
            $advertSkill->setSkill($skill);
            $advertSkill->setLevel('Expert');
            $manager->persist($advertSkill);
        }
        $manager->persist($advert);

        /////////////////////////////////////////////////////////////////////////////////////////

        $advert = new Advert();
        $advert->setTitle('Offre de stage webdesigner');
        $advert->setAuthor('Mathieu');
        $advert->setContent("Nous proposons un poste pour webdesigner. Blabla…");

        $listSkills = $manager->getRepository('OCPlatformBundle:Skill')->findAll();

        foreach ($listSkills as $skill)
        {
            $advertSkill = new AdvertSkill();
            $advertSkill->setAdvert($advert);
            $advertSkill->setSkill($skill);
            $advertSkill->setLevel('Expert');
            $manager->persist($advertSkill);
        }

        $manager->persist($advert);

        /////////////////////////////////////////////////////////////////////////////////////////


        $manager->flush();
    }
}

?>